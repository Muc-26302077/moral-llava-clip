"""Select a BLIP/CluSanT caption fusion strategy on validation only."""

import argparse
import csv
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from generate_blip_private_captions import generate_caption_cache
from materialize_blip_caption_variant import (
    load_caption_postprocessors,
    materialize_variant,
)
from privacy_pipeline.blip_private_caption import (
    COMPACT_STRATEGIES,
    FUSION_STRATEGIES,
    RERANK_STRATEGIES,
    load_blip_config,
)


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (Path(base) / path).resolve()


def run_logged(command, log_path):
    print("\nRunning: {}".format(" ".join(str(value) for value in command)), flush=True)
    lines = []
    with log_path.open("w", encoding="utf-8", newline="\n") as stream:
        process = subprocess.Popen(
            [str(value) for value in command], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            stream.write(line)
            stream.flush()
            lines.append(line.rstrip("\n"))
        return_code = process.wait()
    if return_code:
        raise RuntimeError("Evaluation failed; see {}".format(log_path))
    return lines


def result_path(lines):
    for line in reversed(lines):
        if line.startswith("Results: "):
            return Path(line.split("Results: ", 1)[1].strip()).resolve()
    raise RuntimeError("Evaluator did not report its result directory")


def truncation_counts(report, split_values):
    """Read current top-level reports and tolerate older split-local reports."""
    truncation = split_values.get("truncation", report.get("truncation"))
    if not isinstance(truncation, dict):
        raise ValueError("Evaluation report is missing truncation statistics")
    required = ("original_caption_count", "private_caption_count")
    if any(key not in truncation for key in required):
        raise ValueError("Evaluation report has incomplete truncation statistics")
    return truncation


def summarize(strategy, private_root, report_path):
    report = json.loads(report_path.read_text(encoding="utf-8"))
    values = report["splits"]["validation"]
    preservation = values["value_preservation"]
    utility = values["semantic_utility_gate"]
    conclusion = values["conclusion"]
    truncation = truncation_counts(report, values)
    return {
        "strategy": strategy,
        "images": values["counts"]["images"],
        "pairs": values["counts"]["pairs"],
        "joint_value_preservation_percent": preservation[
            "joint_value_profile_preservation_percent"
        ],
        "joint_value_ci95_low": preservation["bootstrap"]["ci95_low"],
        "joint_value_ci95_high": preservation["bootstrap"]["ci95_high"],
        "image_value_preservation_percent": preservation[
            "image_value_profile_preservation_percent"
        ],
        "text_value_preservation_percent": preservation[
            "text_value_profile_preservation_percent"
        ],
        "cross_modal_relation_preservation_percent": preservation[
            "cross_modal_relation_preservation_percent"
        ],
        "image_to_text_R1_retention_percent": utility[
            "image_to_text_R1_retention_percent"
        ],
        "text_to_image_R1_retention_percent": utility[
            "text_to_image_R1_retention_percent"
        ],
        "joint_R1_retention_percent": utility["joint_R1_retention_percent"],
        "original_truncated_caption_count": truncation[
            "original_caption_count"
        ],
        "private_truncated_caption_count": truncation[
            "private_caption_count"
        ],
        "value_preservation_pass": conclusion["value_preservation_pass"],
        "semantic_utility_pass": conclusion["semantic_utility_pass"],
        "strict_pass": conclusion["strict_pass"],
        "private_root": str(private_root),
        "report_path": str(report_path),
    }


def recommend(rows, target):
    eligible = [
        row for row in rows
        if row["joint_value_preservation_percent"] >= target
        and row["joint_value_ci95_low"] >= target
    ]
    if not eligible:
        return None
    return max(eligible, key=lambda row: row["joint_R1_retention_percent"])["strategy"]


def write_summary(work_root, rows, target, caption_cache):
    payload = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "experiment": (
            "N-best BLIP caption generation, private-text semantic reranking, and "
            "77-token fusion on median-filtered epsilon-20/20 private data"
        ),
        "selection_split": "validation",
        "selection_rule": (
            "Maximize joint R@1 retention among strategies whose joint value point estimate "
            "and 95% unique-image cluster-bootstrap lower bound both meet the target."
        ),
        "target_percent": target,
        "caption_cache": str(caption_cache),
        "recommended_strategy": recommend(rows, target),
        "runs": rows,
    }
    (work_root / "summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (work_root / "summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    notes = [
        "BLIP caption fusion validation sweep",
        "Selection uses validation only. Test must not be used to choose the strategy.",
        "",
    ]
    for row in rows:
        notes.append(
            "{strategy}: value={joint_value_preservation_percent:.4f}% "
            "CI-low={joint_value_ci95_low:.4f}% joint-R1={joint_R1_retention_percent:.4f}% "
            "strict={strict_pass}".format(**row)
        )
    (work_root / "notes.txt").write_text("\n".join(notes) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", default=str(Path(__file__).with_name("privacy_pair_config.json"))
    )
    parser.add_argument(
        "--blip-config", default=str(Path(__file__).with_name("blip_caption_config.json"))
    )
    parser.add_argument("--source-root", required=True,
                        help="Validation-only private root using the frozen image preset.")
    parser.add_argument("--work-root", required=True)
    parser.add_argument("--strategies", nargs="+", choices=FUSION_STRATEGIES)
    parser.add_argument("--target-percent", type=float, default=80.0)
    args = parser.parse_args()

    config_path = Path(args.config).expanduser().resolve()
    blip_config_path, blip_config = load_blip_config(args.blip_config)
    strategies = tuple(args.strategies or blip_config.get("strategies", FUSION_STRATEGIES))
    invalid = sorted(set(strategies) - set(FUSION_STRATEGIES))
    if invalid or not strategies:
        raise ValueError("Invalid/empty fusion strategies: {}".format(invalid))
    source_root = Path(args.source_root).expanduser().resolve()
    work_root = Path(args.work_root).expanduser().resolve()
    if work_root.exists():
        raise FileExistsError("BLIP sweep root already exists: {}".format(work_root))
    work_root.mkdir(parents=True)

    caption_cache = work_root / "blip_private_captions_validation.json"
    print(
        "This experiment asks whether BLIP captions generated only from LDP-private images "
        "improve cross-modal retrieval while preserving the value metric.", flush=True,
    )
    generate_caption_cache(
        source_root, caption_cache, blip_config_path, ("validation",)
    )

    reranker, tokenizer, postprocess_config = load_caption_postprocessors(
        blip_config_path,
        need_reranker=any(value in RERANK_STRATEGIES for value in strategies),
        need_tokenizer=any(value in COMPACT_STRATEGIES for value in strategies),
    )

    base_config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    base_config["dataset_root"] = str(resolve(base_config["dataset_root"], config_path.parent))
    base_config["model_dir"] = str(resolve(base_config["model_dir"], config_path.parent))
    text_config = base_config.get("text_privacy", {})
    if "embedding_model" in text_config:
        text_config["embedding_model"] = str(resolve(
            text_config["embedding_model"], config_path.parent
        ))
    rows = []
    for strategy in strategies:
        print(
            "\n=== strategy={} : measure validation value preservation and bidirectional R@1 ===".format(
                strategy
            ), flush=True,
        )
        root = work_root / strategy
        private_root = root / "private_validation"
        evaluation_root = root / "evaluation_results"
        materialize_variant(
            source_root, caption_cache, private_root, strategy, ("validation",),
            blip_config_path=blip_config_path, reranker=reranker,
            tokenizer=tokenizer, postprocess_config=postprocess_config,
        )
        candidate = json.loads(json.dumps(base_config))
        candidate["output_dir"] = str(private_root)
        candidate["splits"] = ["validation"]
        candidate["evaluation"]["splits"] = ["validation"]
        candidate["evaluation"]["output_dir"] = str(evaluation_root)
        candidate_path = root / "config.json"
        candidate_path.write_text(
            json.dumps(candidate, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        lines = run_logged([
            sys.executable, str(Path(__file__).with_name("evaluate_private_pairs.py")),
            "--config", str(candidate_path), "--private-root", str(private_root),
            "--splits", "validation",
        ], root / "evaluation.log")
        report_path = result_path(lines) / "report.json"
        rows.append(summarize(strategy, private_root, report_path))
        write_summary(work_root, rows, args.target_percent, caption_cache)

    print("\nSweep summary: {}".format(work_root / "summary.json"))
    print("Recommended strategy: {}".format(recommend(rows, args.target_percent)))


if __name__ == "__main__":
    main()
