"""Validate completeness, one-to-one mapping, image reuse and release hygiene."""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from PIL import Image

from privacy_pipeline.manifest_schema import canonical_sha256, file_sha256, load_smid_pairs
from privacy_pipeline.progress import ProgressBar


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def validate(config_path, private_root=None, max_images_per_split=None):
    config_path = Path(config_path).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8-sig"))
    base = config_path.parent
    dataset_root = resolve(cfg["dataset_root"], base)
    private_root = Path(private_root).resolve() if private_root else resolve(cfg["output_dir"], base)
    bundle = load_smid_pairs(
        dataset_root, cfg.get("splits", ["train", "validation", "test"]),
        max_images_per_split=max_images_per_split,
    )
    manifest_path = private_root / "pair_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = manifest.get("pairs")
    if manifest.get("kind") != "smid_private_ldpslicing_clusant" or not isinstance(rows, list):
        raise ValueError("Invalid private pair manifest")
    original_by_id = {row["pair_id"]: row for row in bundle["pairs"]}
    private_by_id = {}
    forbidden_fields = {"original_caption", "original_image_path", "original_image_abs"}
    for row in rows:
        pair_id = row.get("pair_id")
        if not isinstance(pair_id, str) or pair_id in private_by_id:
            raise ValueError("Missing/duplicate private pair_id: {}".format(pair_id))
        leaked = forbidden_fields.intersection(row)
        if leaked:
            raise ValueError("Public manifest leaks original fields: {}".format(sorted(leaked)))
        if not isinstance(row.get("private_caption"), str) or not row["private_caption"].strip():
            raise ValueError("Empty private caption: {}".format(pair_id))
        private_by_id[pair_id] = row
    missing = sorted(set(original_by_id) - set(private_by_id))
    extra = sorted(set(private_by_id) - set(original_by_id))
    if missing or extra:
        raise ValueError("Pair mismatch; missing={}, extra={}".format(missing[:10], extra[:10]))
    if manifest.get("private_pairs_sha256") != canonical_sha256(rows):
        raise ValueError("private_pairs_sha256 mismatch")

    images = defaultdict(set)
    protected_zero = []
    for pair_id, row in private_by_id.items():
        original = original_by_id[pair_id]
        if (row["split"] != original["split"] or
                row["anonymous_image_id"] != original["anonymous_image_id"]):
            raise ValueError("Pair identity mismatch: {}".format(pair_id))
        image_key = "{}:{}".format(row["split"], row["anonymous_image_id"])
        images[image_key].add(row["private_image_path"])
        if int(row["privacy"].get("protected_token_count", 0)) <= 0:
            protected_zero.append(pair_id)
    wrong_reuse = [key for key, paths in images.items() if len(paths) != 1]
    if wrong_reuse:
        raise ValueError("One source image maps to multiple private images: {}".format(wrong_reuse[:10]))
    image_hashes = {}
    unreadable = []
    image_progress = ProgressBar("Validate private images", len(images))
    for index, paths in enumerate(images.values(), 1):
        relative = next(iter(paths))
        path = (private_root / relative).resolve()
        try:
            with Image.open(str(path)) as image:
                image.verify()
            image_hashes[relative] = file_sha256(path)
        except Exception as exc:
            unreadable.append("{}: {}".format(relative, exc))
        image_progress.update(index)
    if unreadable:
        raise ValueError("Unreadable private images: {}".format(unreadable[:10]))
    require_protected = cfg.get("text_privacy", {}).get(
        "require_at_least_one_protected_token_per_pair", True
    )
    if require_protected and protected_zero:
        raise ValueError(
            "{} pairs have no protected text token; dataset is not releasable".format(
                len(protected_zero)
            )
        )

    expected_images = sum(item["unique_images"] for item in bundle["stats"].values())
    report = {
        "status": "valid" if not protected_zero else "valid_with_text_coverage_warning",
        "expected_pairs": len(bundle["pairs"]),
        "actual_pairs": len(rows),
        "expected_unique_images": expected_images,
        "actual_unique_images": len(images),
        "duplicate_pair_id": len(rows) - len(private_by_id),
        "missing_pair_id": len(missing),
        "extra_pair_id": len(extra),
        "empty_private_text": 0,
        "unreadable_image": 0,
        "pairs_without_protected_tokens": len(protected_zero),
        "split_pairs": dict(Counter(row["split"] for row in rows)),
        "private_manifest_sha256": file_sha256(manifest_path),
        "release_hygiene": "No original content/path fields found in public pair rows.",
    }
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(Path(__file__).with_name("privacy_pair_config.json")))
    parser.add_argument("--private-root")
    parser.add_argument("--max-images-per-split", type=int)
    parser.add_argument("--out")
    args = parser.parse_args()
    report = validate(args.config, args.private_root, args.max_images_per_split)
    payload = json.dumps(report, ensure_ascii=False, indent=2)
    print(payload)
    if args.out:
        Path(args.out).write_text(payload, encoding="utf-8")


if __name__ == "__main__":
    main()
