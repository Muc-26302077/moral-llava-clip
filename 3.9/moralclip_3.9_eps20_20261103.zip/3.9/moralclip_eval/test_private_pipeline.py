import json
import io
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from evaluate_private_pairs import (
    bounded_ratio_percent,
    centered_profile_similarity,
    cluster_bootstrap_mean,
    cluster_bootstrap_retention,
    joint_value_preservation,
    retrieval_metrics,
)
from privacy_pipeline.clusant_text_adapter import CluSanTMechanism
from privacy_pipeline.blip_private_caption import (
    fit_fusion_to_token_budget,
    fuse_private_caption,
    select_best_candidate,
)
from privacy_pipeline.image_postprocessing import (
    PRESETS,
    apply_private_image_postprocessing,
    resolve_postprocess_config,
)
from privacy_pipeline.ldp_image_adapter import load_budget
from privacy_pipeline.manifest_schema import load_smid_pairs
from privacy_pipeline.progress import ProgressBar
from postprocess_private_dataset import postprocess_dataset
from materialize_blip_caption_variant import materialize_variant
from run_text_epsilon_sweep import make_config
from run_image_postprocess_sweep import recommend
from run_blip_caption_sweep import recommend as recommend_blip, truncation_counts


class PrivatePipelineTests(unittest.TestCase):
    def test_blip_summary_reads_top_level_truncation(self):
        report = {
            "truncation": {
                "original_caption_count": 44,
                "private_caption_count": 0,
            }
        }
        self.assertEqual(
            truncation_counts(report, {}), report["truncation"]
        )

    def test_private_caption_semantic_reranking(self):
        query = np.asarray([1.0, 0.0], dtype=np.float32)
        candidates = np.asarray([[0.1, 0.9], [0.8, 0.2], [-1.0, 0.0]])
        self.assertEqual(select_best_candidate(query, candidates), 1)

    def test_compact_fusion_honors_token_budget(self):
        class WordTokenizer:
            def __call__(self, text, add_special_tokens=True, truncation=False,
                         max_length=None):
                ids = list(range(len(text.split()) + (2 if add_special_tokens else 0)))
                if truncation and max_length is not None:
                    ids = ids[:max_length]
                return {"input_ids": ids}

            def decode(self, ids, skip_special_tokens=True):
                return "decoded"

        tokenizer = WordTokenizer()
        value = fit_fusion_to_token_budget(
            "private visual scene", "one two three four five six", tokenizer, max_length=7
        )
        self.assertTrue(value.startswith("private visual scene."))
        self.assertLessEqual(
            len(tokenizer(value, add_special_tokens=True)["input_ids"]), 7
        )

    def test_blip_private_caption_fusion_strategies(self):
        clusant = "A private moral description"
        blip = "a person helping another person"
        self.assertEqual(fuse_private_caption(clusant, blip, "clusant"), clusant)
        self.assertEqual(fuse_private_caption(clusant, blip, "blip_only"), blip)
        self.assertTrue(
            fuse_private_caption(clusant, blip, "blip_first").startswith(blip)
        )
        self.assertTrue(
            fuse_private_caption(clusant, blip, "clusant_first").startswith(clusant)
        )
        with self.assertRaises(ValueError):
            fuse_private_caption(clusant, blip, "invalid")

    def test_blip_recommendation_respects_value_gate(self):
        rows = [
            {
                "strategy": "blip_only", "joint_value_preservation_percent": 79.0,
                "joint_value_ci95_low": 78.0, "joint_R1_retention_percent": 95.0,
            },
            {
                "strategy": "blip_first", "joint_value_preservation_percent": 88.0,
                "joint_value_ci95_low": 86.0, "joint_R1_retention_percent": 81.0,
            },
        ]
        self.assertEqual(recommend_blip(rows, 80.0), "blip_first")

    def test_materialize_blip_variant_preserves_pair_and_uses_private_inputs(self):
        from privacy_pipeline.manifest_schema import canonical_sha256, file_sha256

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source"
            output = root / "output"
            image_path = source / "validation" / "images" / "anon.png"
            image_path.parent.mkdir(parents=True)
            Image.new("RGB", (5, 5), "gray").save(image_path)
            rows = [{
                "pair_id": "anon__caption_000",
                "split": "validation",
                "anonymous_image_id": "anon",
                "caption_index": 0,
                "private_image_path": "validation/images/anon.png",
                "private_caption": "CluSanT private text",
                "moral_labels": ["Care"],
                "privacy": {"epsilon_image": 20.0, "epsilon_text": 20.0},
            }]
            manifest = {
                "schema_version": 1,
                "kind": "smid_private_ldpslicing_clusant",
                "pairs_sha256_source": "source-hash",
                "pairs": rows,
                "private_pairs_sha256": canonical_sha256(rows),
            }
            manifest_path = source / "pair_manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            cache_records = [{
                "image_key": "validation:anon",
                "split": "validation",
                "anonymous_image_id": "anon",
                "private_image_path": "validation/images/anon.png",
                "private_image_sha256": file_sha256(image_path),
                "blip_caption": "a gray private image",
            }]
            cache = {
                "schema_version": 1,
                "kind": "blip_captions_from_ldp_private_images",
                "source_private_manifest_sha256": file_sha256(manifest_path),
                "model": {"model_fingerprint": "model-hash"},
                "records": cache_records,
                "records_sha256": canonical_sha256(cache_records),
            }
            cache_path = root / "captions.json"
            cache_path.write_text(json.dumps(cache), encoding="utf-8")
            materialize_variant(
                source, cache_path, output, "blip_first", ("validation",)
            )
            derived = json.loads(
                (output / "pair_manifest.json").read_text(encoding="utf-8")
            )
            row = derived["pairs"][0]
            self.assertEqual(row["pair_id"], rows[0]["pair_id"])
            self.assertTrue(row["private_caption"].startswith("a gray private image"))
            self.assertNotIn("original_caption", row)
            self.assertEqual(
                row["privacy"]["caption_postprocessing"]["strategy"], "blip_first"
            )

    def test_materialize_reranked_compact_variant_selects_candidate(self):
        from privacy_pipeline.manifest_schema import canonical_sha256, file_sha256

        class FakeReranker:
            def select_many(self, private_captions, candidate_groups):
                return [group[-1] for group in candidate_groups], [len(group) - 1 for group in candidate_groups]

        class WordTokenizer:
            def __call__(self, text, add_special_tokens=True, truncation=False,
                         max_length=None):
                ids = list(range(len(text.split()) + 2))
                if truncation and max_length is not None:
                    ids = ids[:max_length]
                return {"input_ids": ids}

            def decode(self, ids, skip_special_tokens=True):
                return "decoded"

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source"
            output = root / "output"
            image_path = source / "validation" / "images" / "anon.png"
            image_path.parent.mkdir(parents=True)
            Image.new("RGB", (5, 5), "gray").save(image_path)
            rows = [{
                "pair_id": "anon__caption_000", "split": "validation",
                "anonymous_image_id": "anon", "caption_index": 0,
                "private_image_path": "validation/images/anon.png",
                "private_caption": "private words one two three four",
                "moral_labels": ["Care"], "privacy": {},
            }]
            manifest = {
                "schema_version": 1, "kind": "smid_private_ldpslicing_clusant",
                "pairs": rows, "private_pairs_sha256": canonical_sha256(rows),
            }
            manifest_path = source / "pair_manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            cache_rows = [{
                "image_key": "validation:anon", "split": "validation",
                "anonymous_image_id": "anon",
                "private_image_path": "validation/images/anon.png",
                "private_image_sha256": file_sha256(image_path),
                "blip_caption": "first visual",
                "blip_candidates": ["first visual", "selected visual"],
            }]
            cache = {
                "schema_version": 1, "kind": "blip_captions_from_ldp_private_images",
                "source_private_manifest_sha256": file_sha256(manifest_path),
                "model": {"model_fingerprint": "model-hash"},
                "records": cache_rows, "records_sha256": canonical_sha256(cache_rows),
            }
            cache_path = root / "captions.json"
            cache_path.write_text(json.dumps(cache), encoding="utf-8")
            materialize_variant(
                source, cache_path, output, "rerank_compact", ("validation",),
                reranker=FakeReranker(), tokenizer=WordTokenizer(),
                postprocess_config={"moralclip_max_length": 7},
            )
            derived = json.loads((output / "pair_manifest.json").read_text(encoding="utf-8"))
            row = derived["pairs"][0]
            self.assertTrue(row["private_caption"].startswith("selected visual."))
            self.assertEqual(
                row["privacy"]["caption_postprocessing"]["selected_candidate_index"], 1
            )
            self.assertLessEqual(len(row["private_caption"].split()) + 2, 7)

    def test_private_image_postprocessing_is_deterministic_and_shape_preserving(self):
        array = np.zeros((9, 9, 3), dtype=np.uint8)
        array[4, 4] = 255
        image = Image.fromarray(array, mode="RGB")
        first = apply_private_image_postprocessing(image, "median3")
        second = apply_private_image_postprocessing(image, PRESETS["median3"])
        self.assertEqual(first.size, image.size)
        self.assertTrue(np.array_equal(np.asarray(first), np.asarray(second)))
        self.assertEqual(int(np.asarray(first)[4, 4, 0]), 0)
        identity = apply_private_image_postprocessing(image, "identity")
        self.assertTrue(np.array_equal(np.asarray(identity), array))

    def test_private_image_postprocessing_rejects_invalid_parameters(self):
        with self.assertRaises(ValueError):
            resolve_postprocess_config({"method": "median", "size": 4})
        with self.assertRaises(ValueError):
            resolve_postprocess_config("does-not-exist")

    def test_postprocess_sweep_recommendation_uses_value_gate_then_r1(self):
        rows = [
            {
                "preset": "unsafe_high_r1", "joint_value_preservation_percent": 79.0,
                "joint_value_ci95_low": 78.0, "joint_R1_retention_percent": 99.0,
            },
            {
                "preset": "eligible_a", "joint_value_preservation_percent": 90.0,
                "joint_value_ci95_low": 88.0, "joint_R1_retention_percent": 70.0,
            },
            {
                "preset": "eligible_b", "joint_value_preservation_percent": 89.0,
                "joint_value_ci95_low": 87.0, "joint_R1_retention_percent": 75.0,
            },
        ]
        self.assertEqual(recommend(rows, 80.0), "eligible_b")

    def test_postprocess_dataset_uses_only_private_rows_and_preserves_ids(self):
        from privacy_pipeline.manifest_schema import canonical_sha256

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "private_source"
            output = root / "private_output"
            image_path = source / "validation" / "images" / "anon.png"
            image_path.parent.mkdir(parents=True)
            Image.new("RGB", (7, 7), "gray").save(image_path)
            rows = [{
                "pair_id": "anon__caption_000",
                "split": "validation",
                "anonymous_image_id": "anon",
                "caption_index": 0,
                "private_image_path": "validation/images/anon.png",
                "private_caption": "private caption",
                "moral_labels": ["Care"],
                "privacy": {
                    "epsilon_image": 20.0,
                    "epsilon_text": 20.0,
                    "protected_token_count": 1,
                },
            }]
            manifest = {
                "schema_version": 1,
                "kind": "smid_private_ldpslicing_clusant",
                "pairs_sha256_source": "source-hash",
                "pair_count": 1,
                "unique_image_count": 1,
                "pairs": rows,
                "private_pairs_sha256": canonical_sha256(rows),
            }
            (source / "pair_manifest.json").write_text(
                json.dumps(manifest), encoding="utf-8"
            )
            postprocess_dataset(source, output, "median3", ("validation",))
            derived = json.loads(
                (output / "pair_manifest.json").read_text(encoding="utf-8")
            )
            self.assertEqual(derived["pairs"][0]["pair_id"], rows[0]["pair_id"])
            self.assertNotIn("original_caption", derived["pairs"][0])
            self.assertEqual(
                derived["pairs"][0]["privacy"]["image_postprocessing"]["preset"],
                "median3",
            )
            self.assertTrue((output / "validation" / "images" / "anon.png").is_file())

    def test_default_config_uses_frozen_twenty_twenty_budgets(self):
        config_path = Path(__file__).with_name("privacy_pair_config.json")
        config = json.loads(config_path.read_text(encoding="utf-8-sig"))
        self.assertEqual(config["image_privacy"]["epsilon"], 20.0)
        self.assertEqual(config["text_privacy"]["epsilon"], 20.0)
        self.assertTrue(config["output_dir"].endswith("_eps20_20"))

        blip = json.loads(
            Path(__file__).with_name("blip_caption_config.json").read_text(encoding="utf-8")
        )
        self.assertGreaterEqual(blip["num_beams"], blip["num_candidates"])
        self.assertGreater(blip["num_candidates"], 1)
        self.assertIn("rerank_compact", blip["strategies"])

    def test_progress_bar_is_visible_in_redirected_logs(self):
        stream = io.StringIO()
        progress = ProgressBar("Private images", 10, stream=stream, log_updates=2)
        for current in range(1, 11):
            progress.update(current)
        output = stream.getvalue()
        self.assertIn("Private images", output)
        self.assertIn("100.00% 10/10", output)
        self.assertGreaterEqual(len(output.splitlines()), 3)

    def test_official_ldp_budget(self):
        epsilon_y, epsilon_c, total, color, key = load_budget(20.0, "411")
        self.assertEqual(len(epsilon_y), 8)
        self.assertEqual(len(epsilon_c), 8)
        self.assertEqual(color, "4:1:1")
        self.assertEqual(key, "20.0")
        self.assertAlmostEqual(total, 20.0, delta=0.05)
        _, _, total_32, color_32, key_32 = load_budget(32.0, "411")
        self.assertEqual(color_32, "4:1:1")
        self.assertEqual(key_32, "32.0")
        self.assertAlmostEqual(total_32, 32.0, delta=0.05)
        with self.assertRaises(ValueError):
            load_budget(10.0, "411")

    def test_manifest_expansion_and_stable_ids(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "test").mkdir()
            Image.new("RGB", (4, 4), "white").save(root / "test" / "a.jpg")
            manifest = [{
                "id": "a", "split": "test", "image_path": "test/a.jpg",
                "captions": ["first caption", "first caption", "second caption"],
                "moral_labels": ["Care"],
            }]
            (root / "test" / "smid_manifest.json").write_text(
                json.dumps(manifest), encoding="utf-8"
            )
            first = load_smid_pairs(root, splits=["test"])
            second = load_smid_pairs(root, splits=["test"])
            self.assertEqual(len(first["pairs"]), 2)
            self.assertEqual(first["stats"]["test"]["duplicate_captions_removed"], 1)
            self.assertEqual(first["pairs_sha256"], second["pairs_sha256"])
            self.assertRegex(first["pairs"][0]["pair_id"], r"^[0-9a-f]{24}__caption_000$")

    def test_clusant_is_stable_for_secret_and_pair(self):
        words = ["care", "kind", "harm", "cruel"]
        embeddings = np.asarray([
            [1.0, 0.0], [0.9, 0.1], [0.0, 1.0], [0.1, 0.9]
        ], dtype=np.float32)
        labels = np.asarray([0, 0, 1, 1], dtype=np.int32)
        mechanism = CluSanTMechanism(
            words, embeddings, labels, epsilon=4.0, selection_policy="all_words"
        )
        secret = b"test-secret-material-do-not-release"
        one, audit_one = mechanism.sanitize("Care and harm.", secret, "pair-1")
        two, audit_two = mechanism.sanitize("Care and harm.", secret, "pair-1")
        self.assertEqual(one, two)
        self.assertEqual(audit_one, audit_two)
        self.assertTrue(one.strip())
        self.assertEqual(audit_one["protected_token_count"], 2)
        self.assertEqual(audit_one["out_of_vocabulary_token_count"], 1)

    def test_retrieval_metrics_perfect(self):
        images = np.eye(2, dtype=np.float32)
        texts = np.asarray([[1.0, 0.0], [1.0, 0.0], [0.0, 1.0]], dtype=np.float32)
        indices = np.asarray([0, 0, 1], dtype=np.int64)
        result = retrieval_metrics(images, texts, indices, chunk_size=1)
        self.assertEqual(result["image_to_text"]["R@1_percent"], 100.0)
        self.assertEqual(result["text_to_image"]["R@1_percent"], 100.0)

    def test_cluster_bootstrap_identity(self):
        original = np.asarray([0.8, 0.7, 0.9])
        private = original.copy()
        result = cluster_bootstrap_retention(
            original, private, ["a", "a", "b"], samples=100, seed=7
        )
        self.assertAlmostEqual(result["ci95_low"], 100.0)
        self.assertAlmostEqual(result["ci95_high"], 100.0)

    def test_centered_profile_similarity_is_bounded(self):
        first = np.asarray([[3.0, 2.0, 1.0], [1.0, 4.0, 2.0]])
        identical = centered_profile_similarity(first, first)
        reversed_profile = centered_profile_similarity(first[:1], first[:1, ::-1])
        np.testing.assert_allclose(identical, [1.0, 1.0])
        self.assertGreaterEqual(float(reversed_profile[0]), 0.0)
        self.assertLessEqual(float(reversed_profile[0]), 1.0)

    def test_joint_value_preservation_and_bootstrap_are_bounded(self):
        image = np.asarray([1.0, 0.81, 0.64])
        text = np.asarray([1.0, 0.64, 0.81])
        relation = np.asarray([1.0, 1.0, 1.0])
        joint = joint_value_preservation(image, text, relation)
        self.assertTrue(np.all((joint >= 0.0) & (joint <= 1.0)))
        result = cluster_bootstrap_mean(joint, ["a", "a", "b"], samples=100, seed=7)
        self.assertGreaterEqual(result["ci95_low"], 0.0)
        self.assertLessEqual(result["ci95_high"], 100.0)

    def test_bounded_ratio_cannot_exceed_one_hundred(self):
        self.assertEqual(bounded_ratio_percent(2.0, 1.0), 100.0)
        self.assertEqual(bounded_ratio_percent(0.5, 1.0), 50.0)
        with self.assertRaises(ValueError):
            bounded_ratio_percent(1.0, 0.0)

    def test_sweep_config_is_isolated_and_uses_requested_epsilon(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base_path = root / "project" / "privacy_pair_config.json"
            base_path.parent.mkdir()
            cfg = {
                "dataset_root": "../data",
                "model_dir": "../model",
                "output_dir": "../unused",
                "image_privacy": {"epsilon": 20.0},
                "text_privacy": {
                    "epsilon": 8.0,
                    "embedding_model": "../embedding",
                },
                "evaluation": {"output_dir": "unused_results"},
            }
            private_root = root / "run" / "private"
            evaluation_root = root / "run" / "results"
            output_path = root / "configs" / "epsilon_20.json"
            make_config(
                base_path, cfg, 20.0, private_root, evaluation_root, output_path,
                selected_split="validation",
                image_epsilon=32.0,
            )
            prepared = json.loads(output_path.read_text(encoding="utf-8"))
            self.assertEqual(prepared["text_privacy"]["epsilon"], 20.0)
            self.assertEqual(prepared["image_privacy"]["epsilon"], 32.0)
            self.assertEqual(prepared["splits"], ["validation"])
            self.assertEqual(Path(prepared["output_dir"]), private_root.resolve())
            self.assertEqual(
                Path(prepared["evaluation"]["output_dir"]), evaluation_root.resolve()
            )
            self.assertEqual(cfg["text_privacy"]["epsilon"], 8.0)
            self.assertEqual(cfg["image_privacy"]["epsilon"], 20.0)


if __name__ == "__main__":
    unittest.main()
