import unittest

import numpy as np

from privacy_attacks.clip_mia import (
    best_balanced_threshold,
    calibrated_feature_attack,
    calibrated_scalar_attack,
    select_strongest_attack,
    stratified_cluster_bootstrap_difference,
)


class MembershipInferenceTests(unittest.TestCase):
    def test_scalar_attack_calibrates_without_test_peeking(self):
        labels = np.asarray([0, 0, 1, 1])
        calibration = np.asarray([0.1, 0.2, 0.8, 0.9])
        test = np.asarray([0.15, 0.25, 0.75, 0.85])
        attack = calibrated_scalar_attack(labels, calibration, labels, test)
        self.assertEqual(attack["test"]["balanced_ASR_percent"], 100.0)
        self.assertEqual(attack["test"]["AUC"], 1.0)

    def test_scalar_attack_can_learn_reversed_direction(self):
        labels = np.asarray([0, 0, 1, 1])
        scores = np.asarray([0.9, 0.8, 0.2, 0.1])
        attack = calibrated_scalar_attack(labels, scores, labels, scores)
        self.assertEqual(attack["score_direction"], "lower_is_member")
        self.assertEqual(attack["test"]["balanced_ASR_percent"], 100.0)

    def test_feature_attack_is_adaptive(self):
        labels = np.asarray([0, 0, 0, 1, 1, 1])
        features = np.asarray([
            [0.1, 0.9], [0.2, 0.8], [0.3, 0.7],
            [0.7, 0.3], [0.8, 0.2], [0.9, 0.1],
        ])
        attack = calibrated_feature_attack(labels, features, labels, features)
        self.assertGreaterEqual(attack["test"]["balanced_ASR_percent"], 99.0)

    def test_threshold_is_calibration_optimum(self):
        labels = np.asarray([0, 0, 1, 1])
        threshold = best_balanced_threshold(labels, np.asarray([0.1, 0.2, 0.8, 0.9]))
        self.assertGreater(threshold, 0.2)
        self.assertLess(threshold, 0.8)

    def test_selection_uses_calibration_not_test(self):
        attacks = {
            "a": {"calibration": {"AUC": 0.9, "balanced_ASR_percent": 80.0}},
            "b": {"calibration": {"AUC": 0.8, "balanced_ASR_percent": 100.0}},
        }
        self.assertEqual(select_strongest_attack(attacks), "a")

    def test_cluster_bootstrap_returns_paired_difference(self):
        labels = np.asarray([0, 0, 1, 1])
        clusters = np.asarray(["n0", "n1", "m0", "m1"], dtype=object)
        original = np.asarray([0.1, 0.2, 0.8, 0.9])
        private = np.asarray([0.4, 0.6, 0.45, 0.55])
        value = stratified_cluster_bootstrap_difference(
            labels, clusters, original, 0.5, private, 0.5,
            samples=50, seed=7,
        )
        self.assertIn("ci95_low", value["balanced_ASR_percent"])
        self.assertGreater(value["balanced_ASR_percent"]["mean"], 0.0)


if __name__ == "__main__":
    unittest.main()

