"""Plot bounded value preservation and utility for a text-epsilon sweep."""

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    payload = json.loads(Path(args.summary).read_text(encoding="utf-8"))
    rows = sorted(payload["runs"], key=lambda row: row["epsilon_text"])
    if not rows:
        raise ValueError("Sweep summary contains no runs")
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    epsilon = [row["epsilon_text"] for row in rows]
    target = 80.0

    value = [row["joint_value_preservation_percent"] for row in rows]
    low = [row["joint_value_ci95_low"] for row in rows]
    high = [row["joint_value_ci95_high"] for row in rows]
    errors = [[max(0.0, score - lower) for score, lower in zip(value, low)],
              [max(0.0, upper - score) for score, upper in zip(value, high)]]
    fig, axis = plt.subplots(figsize=(7.2, 4.5))
    axis.errorbar(epsilon, value, yerr=errors, marker="o", capsize=4, linewidth=2)
    axis.axhline(target, color="tab:red", linestyle="--", label="80% target")
    axis.set(xlabel="CluSanT text epsilon", ylabel="Joint value preservation (%)",
             title="Bounded value preservation across privacy budgets", ylim=(0, 105))
    axis.grid(alpha=0.25)
    axis.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "Figure_1.png", dpi=200)
    plt.close(fig)

    fig, axis = plt.subplots(figsize=(7.2, 4.5))
    axis.plot(epsilon, [row["image_to_text_R1_retention_percent"] for row in rows],
              marker="o", label="Image→text R@1 retention")
    axis.plot(epsilon, [row["text_to_image_R1_retention_percent"] for row in rows],
              marker="s", label="Text→image R@1 retention")
    axis.plot(epsilon, [row["joint_R1_retention_percent"] for row in rows],
              marker="^", linewidth=2.5, label="Joint R@1 retention")
    axis.axhline(target, color="tab:red", linestyle="--", label="80% target")
    axis.set(xlabel="CluSanT text epsilon", ylabel="Retrieval utility retention (%)",
             title="Semantic utility across privacy budgets", ylim=(0, 105))
    axis.grid(alpha=0.25)
    axis.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "Figure_2.png", dpi=200)
    plt.close(fig)

    print("Figure 1: {}".format(output_dir / "Figure_1.png"))
    print("Figure 2: {}".format(output_dir / "Figure_2.png"))


if __name__ == "__main__":
    main()
