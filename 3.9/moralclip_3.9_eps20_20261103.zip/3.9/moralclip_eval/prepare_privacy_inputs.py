"""Export SMID captions into a stable, auditable CADP bridge bundle."""

import argparse
import hashlib
import json
from pathlib import Path


def canonical_sha256(value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def resolve_manifest(dataset_root, split):
    split_manifest = dataset_root / split / "smid_manifest.json"
    return split_manifest if split_manifest.is_file() else dataset_root / "smid_manifest.json"


def build_bundle(dataset_root, split):
    dataset_root = dataset_root.resolve()
    manifest_path = resolve_manifest(dataset_root, split)
    if not manifest_path.is_file():
        raise FileNotFoundError(f"SMID manifest not found: {manifest_path}")
    raw = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, list):
        raise ValueError("SMID manifest must be a JSON list")

    records = []
    seen_ids = set()
    image_count = 0
    duplicate_captions_removed = 0
    for item in raw:
        if item.get("split") != split:
            continue
        image_rel = item.get("image_path")
        image_id = item.get("id")
        labels = item.get("moral_labels")
        captions = item.get("captions") or [item.get("caption")]
        if not isinstance(image_rel, str) or not isinstance(image_id, str):
            raise ValueError(f"Invalid image record: {item}")
        if not isinstance(labels, list) or not labels or not all(isinstance(x, str) and x for x in labels):
            raise ValueError(f"Invalid moral_labels for {image_id}")
        if not isinstance(captions, list) or not all(isinstance(x, str) and x.strip() for x in captions):
            raise ValueError(f"Invalid captions for {image_id}")
        image_path = (dataset_root / image_rel).resolve()
        if not image_path.is_file() or not image_path.is_relative_to(dataset_root):
            raise FileNotFoundError(f"Image missing or outside dataset root: {image_path}")

        normalized = [x.strip() for x in captions]
        unique_captions = list(dict.fromkeys(normalized))
        duplicate_captions_removed += len(normalized) - len(unique_captions)
        image_count += 1
        for caption_index, text in enumerate(unique_captions):
            sample_id = f"{split}:{image_id}:{caption_index}"
            if sample_id in seen_ids:
                raise ValueError(f"Duplicate sample_id: {sample_id}")
            seen_ids.add(sample_id)
            records.append({
                "row_id": len(records),
                "sample_id": sample_id,
                "split": split,
                "image_id": image_id,
                "image_path": image_rel.replace("\\", "/"),
                "caption_index": caption_index,
                "text": text,
                "moral_labels": labels,
            })
    if not records:
        raise ValueError(f"No records found for split={split}")

    bundle = {
        "schema_version": 1,
        "kind": "smid_cadp_bridge_input",
        "split": split,
        "source_manifest": str(manifest_path.relative_to(dataset_root)).replace("\\", "/"),
        "image_count": image_count,
        "record_count": len(records),
        "duplicate_captions_removed": duplicate_captions_removed,
        "records": records,
    }
    bundle["records_sha256"] = canonical_sha256(records)
    return bundle


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", required=True)
    parser.add_argument("--split", choices=["train", "validation", "test"], required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    bundle = build_bundle(Path(args.dataset_root), args.split)
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: bundle[k] for k in (
        "split", "image_count", "record_count", "duplicate_captions_removed", "records_sha256"
    )}, ensure_ascii=False, indent=2))
    print(f"Wrote: {out}")


if __name__ == "__main__":
    main()
