"""Evaluate O/O, P/O, O/P and P/P with one frozen MoralCLIP model."""

import argparse
import csv
import json
import math
import platform
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np

from evaluate import load_model
from privacy_pipeline.manifest_schema import file_sha256, load_smid_pairs
from privacy_pipeline.progress import ProgressBar


CONDITIONS = {
    "O_O": ("original", "original"),
    "P_O": ("private", "original"),
    "O_P": ("original", "private"),
    "P_P": ("private", "private"),
}


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def js_similarity(p, q):
    p = np.asarray(p, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    midpoint = 0.5 * (p + q)
    tiny = np.finfo(np.float64).tiny
    divergence = 0.5 * np.sum(p * np.log(np.maximum(p, tiny) / np.maximum(midpoint, tiny)), axis=-1)
    divergence += 0.5 * np.sum(q * np.log(np.maximum(q, tiny) / np.maximum(midpoint, tiny)), axis=-1)
    return np.clip(1.0 - divergence / math.log(2.0), 0.0, 1.0)


def softmax(values):
    shifted = values - np.max(values, axis=-1, keepdims=True)
    exp_values = np.exp(shifted)
    return exp_values / exp_values.sum(axis=-1, keepdims=True)


def retention_percent(private_score, original_score):
    if not np.isfinite(original_score) or original_score <= 0:
        raise ValueError("Original consistency must be positive and finite")
    return float(100.0 * private_score / original_score)


def centered_profile_similarity(first, second):
    """Return a bounded similarity for relative value-label score profiles.

    Centering removes a modality-wide score offset.  Mapping cosine similarity
    from [-1, 1] to [0, 1] makes the result interpretable as a bounded
    preservation score without dividing by a possibly tiny O/O baseline.
    """
    first = np.asarray(first, dtype=np.float64)
    second = np.asarray(second, dtype=np.float64)
    if first.shape != second.shape or first.ndim != 2:
        raise ValueError("Value profiles must be two-dimensional with equal shapes")
    first = first - first.mean(axis=-1, keepdims=True)
    second = second - second.mean(axis=-1, keepdims=True)
    first_norm = np.linalg.norm(first, axis=-1)
    second_norm = np.linalg.norm(second, axis=-1)
    denominator = first_norm * second_norm
    cosine = np.zeros(len(first), dtype=np.float64)
    valid = denominator > np.finfo(np.float64).eps
    cosine[valid] = np.sum(first[valid] * second[valid], axis=-1) / denominator[valid]
    similarity = np.clip(0.5 * (cosine + 1.0), 0.0, 1.0)
    similarity[~valid] = 0.0
    return similarity


def joint_value_preservation(image_scores, text_scores, relation_scores):
    """Combine the three necessary preservation components per pair."""
    components = np.stack([image_scores, text_scores, relation_scores], axis=-1)
    if not np.isfinite(components).all():
        raise ValueError("Non-finite value preservation component")
    if np.any(components < 0.0) or np.any(components > 1.0):
        raise ValueError("Value preservation components must be in [0, 1]")
    return np.prod(components, axis=-1) ** (1.0 / 3.0)


def bounded_ratio_percent(private_score, original_score):
    """Return a [0, 100] utility retention ratio."""
    if not np.isfinite(original_score) or original_score <= 0:
        raise ValueError("Original utility must be positive and finite")
    return float(100.0 * np.clip(private_score / original_score, 0.0, 1.0))


def load_joined_pairs(dataset_root, private_root, splits, max_images_per_split=None):
    source = load_smid_pairs(
        dataset_root, splits=splits, max_images_per_split=max_images_per_split
    )
    manifest_path = private_root / "pair_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    private_rows = manifest.get("pairs")
    if manifest.get("kind") != "smid_private_ldpslicing_clusant" or not isinstance(private_rows, list):
        raise ValueError("Invalid private pair manifest")
    by_id = {}
    for row in private_rows:
        pair_id = row.get("pair_id")
        if not isinstance(pair_id, str) or pair_id in by_id:
            raise ValueError("Invalid or duplicate private pair_id: {}".format(pair_id))
        by_id[pair_id] = row
    expected = {row["pair_id"] for row in source["pairs"]}
    missing = sorted(expected - set(by_id))
    extra_in_selected = sorted(
        pair_id for pair_id, row in by_id.items()
        if row.get("split") in splits and pair_id not in expected
    )
    if missing or extra_in_selected:
        raise ValueError("Private pair mismatch; missing={}, extra={}".format(missing[:10], extra_in_selected[:10]))
    joined = []
    for original in source["pairs"]:
        private = by_id[original["pair_id"]]
        private_image = (private_root / private["private_image_path"]).resolve()
        if not private_image.is_file():
            raise FileNotFoundError("Private image missing: {}".format(private_image))
        private_text = private.get("private_caption")
        if not isinstance(private_text, str) or not private_text.strip():
            raise ValueError("Private caption empty: {}".format(original["pair_id"]))
        joined.append({
            **original,
            "private_image_abs": str(private_image),
            "private_caption": private_text.strip(),
        })
    return source, manifest_path, joined


def _feature_tensor(value, torch):
    return value if isinstance(value, torch.Tensor) else value.pooler_output


def encode_images(paths, model, processor, device, batch_size, label="Encode images"):
    import torch
    from PIL import Image
    features = []
    progress = ProgressBar(label, len(paths))
    with torch.inference_mode():
        for start in range(0, len(paths), batch_size):
            batch = []
            for path in paths[start:start + batch_size]:
                with Image.open(path) as image:
                    batch.append(image.convert("RGB"))
            inputs = processor(images=batch, return_tensors="pt").to(device)
            values = _feature_tensor(model.get_image_features(**inputs), torch).float()
            features.append(torch.nn.functional.normalize(values, dim=-1).cpu().numpy())
            progress.update(min(start + batch_size, len(paths)))
    return np.concatenate(features)


def encode_texts(texts, model, processor, device, batch_size, label="Encode texts"):
    import torch
    features = []
    max_length = model.config.text_config.max_position_embeddings
    token_ids = processor.tokenizer(texts, truncation=False, padding=False)["input_ids"]
    truncated = int(sum(len(ids) > max_length for ids in token_ids))
    progress = ProgressBar(label, len(texts))
    with torch.inference_mode():
        for start in range(0, len(texts), batch_size):
            inputs = processor(
                text=texts[start:start + batch_size], return_tensors="pt", padding=True,
                truncation=True, max_length=max_length,
            ).to(device)
            values = _feature_tensor(model.get_text_features(**inputs), torch).float()
            features.append(torch.nn.functional.normalize(values, dim=-1).cpu().numpy())
            progress.update(min(start + batch_size, len(texts)))
    return np.concatenate(features), truncated


def build_label_features(prompt_map, model, processor, device, batch_size):
    labels = list(prompt_map)
    prompts = []
    slices = []
    for label in labels:
        values = prompt_map[label]
        if not isinstance(values, list) or not values:
            raise ValueError("Empty value prompt list for {}".format(label))
        start = len(prompts)
        prompts.extend(values)
        slices.append((start, len(prompts)))
    features, _ = encode_texts(
        prompts, model, processor, device, batch_size, label="Encode value prompts"
    )
    means = []
    for start, end in slices:
        mean = features[start:end].mean(axis=0)
        means.append(mean / np.linalg.norm(mean))
    return labels, np.stack(means)


def retrieval_metrics(image_features, text_features, row_image_indices, chunk_size):
    image_ranks = []
    text_ranks = []
    rows_by_image = defaultdict(list)
    for row_index, image_index in enumerate(row_image_indices.tolist()):
        rows_by_image[image_index].append(row_index)
    for start in range(0, len(image_features), chunk_size):
        scores = image_features[start:start + chunk_size] @ text_features.T
        for local_index in range(len(scores)):
            image_index = start + local_index
            positives = rows_by_image[image_index]
            best = float(np.max(scores[local_index, positives]))
            negative_mask = np.ones(len(text_features), dtype=bool)
            negative_mask[positives] = False
            rank = 1 + int(np.sum(scores[local_index, negative_mask] >= best - 1e-6))
            image_ranks.append(rank)
    for start in range(0, len(text_features), chunk_size):
        scores = text_features[start:start + chunk_size] @ image_features.T
        positives = row_image_indices[start:start + chunk_size]
        best = scores[np.arange(len(scores)), positives]
        negative = scores >= best[:, None] - 1e-6
        negative[np.arange(len(scores)), positives] = False
        text_ranks.extend((1 + negative.sum(axis=1)).tolist())

    def summarize(ranks, query_count, gallery_count):
        ranks = np.asarray(ranks, dtype=np.int64)
        return {
            "R@1_percent": float(100.0 * np.mean(ranks <= 1)),
            "R@5_percent": float(100.0 * np.mean(ranks <= 5)),
            "R@10_percent": float(100.0 * np.mean(ranks <= 10)),
            "median_rank": float(np.median(ranks)),
            "MRR": float(np.mean(1.0 / ranks)),
            "query_count": query_count,
            "gallery_count": gallery_count,
            "tie_policy": "conservative: negatives within 1e-6 rank before positives",
        }
    return {
        "image_to_text": summarize(image_ranks, len(image_features), len(text_features)),
        "text_to_image": summarize(text_ranks, len(text_features), len(image_features)),
    }


def condition_metrics(image_features, text_features, row_image_indices, image_probs,
                      text_probs, labels, true_labels, chunk_size):
    row_image_features = image_features[row_image_indices]
    row_image_probs = image_probs[row_image_indices]
    value_scores = js_similarity(row_image_probs, text_probs)
    paired_cosine = np.sum(row_image_features * text_features, axis=1)
    image_pred = np.argmax(row_image_probs, axis=1)
    text_pred = np.argmax(text_probs, axis=1)
    label_to_index = {label: index for index, label in enumerate(labels)}
    true_indices = [{label_to_index[label] for label in values} for values in true_labels]
    image_hit = [int(pred in truth) for pred, truth in zip(image_pred, true_indices)]
    text_hit = [int(pred in truth) for pred, truth in zip(text_pred, true_indices)]
    return {
        "summary": {
            "cross_modal_value_consistency_percent": float(100.0 * value_scores.mean()),
            "cross_modal_top1_agreement_percent": float(100.0 * np.mean(image_pred == text_pred)),
            "image_ground_truth_top1_hit_percent": float(100.0 * np.mean(image_hit)),
            "text_ground_truth_top1_hit_percent": float(100.0 * np.mean(text_hit)),
            "paired_cosine_mean": float(paired_cosine.mean()),
            "paired_cosine_median": float(np.median(paired_cosine)),
            "paired_cosine_p05": float(np.quantile(paired_cosine, 0.05)),
            "paired_cosine_p95": float(np.quantile(paired_cosine, 0.95)),
            "retrieval": retrieval_metrics(
                image_features, text_features, row_image_indices, chunk_size
            ),
        },
        "value_scores": value_scores,
        "paired_cosine": paired_cosine,
        "image_pred": image_pred,
        "text_pred": text_pred,
    }


def cluster_bootstrap_retention(original_scores, private_scores, image_keys, samples, seed):
    groups = defaultdict(list)
    for index, key in enumerate(image_keys):
        groups[key].append(index)
    keys = sorted(groups)
    rng = np.random.default_rng(int(seed))
    estimates = []
    for _ in range(int(samples)):
        chosen = rng.choice(keys, size=len(keys), replace=True)
        indices = np.concatenate([np.asarray(groups[key], dtype=np.int64) for key in chosen])
        estimates.append(retention_percent(private_scores[indices].mean(), original_scores[indices].mean()))
    low, high = np.quantile(estimates, [0.025, 0.975])
    return {
        "method": "unique-image cluster bootstrap",
        "samples": int(samples),
        "ci95_low": float(low),
        "ci95_high": float(high),
    }


def cluster_bootstrap_mean(scores, image_keys, samples, seed):
    """Bootstrap a bounded per-pair score by unique image clusters."""
    scores = np.asarray(scores, dtype=np.float64)
    if len(scores) != len(image_keys) or not len(scores):
        raise ValueError("Scores and image keys must be non-empty and aligned")
    if not np.isfinite(scores).all() or np.any(scores < 0.0) or np.any(scores > 1.0):
        raise ValueError("Bootstrap scores must be finite and in [0, 1]")
    groups = defaultdict(list)
    for index, key in enumerate(image_keys):
        groups[key].append(index)
    keys = sorted(groups)
    rng = np.random.default_rng(int(seed))
    estimates = []
    for _ in range(int(samples)):
        chosen = rng.choice(keys, size=len(keys), replace=True)
        indices = np.concatenate([np.asarray(groups[key], dtype=np.int64) for key in chosen])
        estimates.append(float(100.0 * scores[indices].mean()))
    low, high = np.quantile(estimates, [0.025, 0.975])
    return {
        "method": "unique-image cluster bootstrap over bounded per-pair scores",
        "samples": int(samples),
        "ci95_low": float(low),
        "ci95_high": float(high),
    }


def evaluate_split(records, original_image_features, private_image_features,
                   original_text_features, private_text_features, image_indices,
                   label_features, labels, logit_scale, chunk_size, bootstrap_samples,
                   bootstrap_seed, target):
    source_indices = np.asarray([record["global_index"] for record in records], dtype=np.int64)
    global_images = [int(image_indices[index]) for index in source_indices]
    unique_global_images = list(dict.fromkeys(global_images))
    local_image_map = {global_index: local for local, global_index in enumerate(unique_global_images)}
    row_image_indices = np.asarray([local_image_map[index] for index in global_images], dtype=np.int64)
    oi = original_image_features[unique_global_images]
    pi = private_image_features[unique_global_images]
    ot = original_text_features[source_indices]
    pt = private_text_features[source_indices]
    image_profiles = {"original": oi @ label_features.T, "private": pi @ label_features.T}
    text_profiles = {"original": ot @ label_features.T, "private": pt @ label_features.T}
    image_probabilities = {
        name: softmax(logit_scale * values) for name, values in image_profiles.items()
    }
    text_probabilities = {
        name: softmax(logit_scale * values) for name, values in text_profiles.items()
    }
    image_features = {"original": oi, "private": pi}
    text_features = {"original": ot, "private": pt}
    true_labels = [record["moral_labels"] for record in records]
    raw_conditions = {}
    for name, (image_kind, text_kind) in CONDITIONS.items():
        print("Evaluating condition {}".format(name), flush=True)
        raw_conditions[name] = condition_metrics(
            image_features[image_kind], text_features[text_kind], row_image_indices,
            image_probabilities[image_kind], text_probabilities[text_kind], labels,
            true_labels, chunk_size,
        )
    baseline = raw_conditions["O_O"]
    image_keys = ["{}:{}".format(record["split"], record["image_id"]) for record in records]
    legacy_ratio_diagnostic = {}
    for name in ("P_O", "O_P", "P_P"):
        score = raw_conditions[name]
        baseline_score = baseline["summary"]["cross_modal_value_consistency_percent"]
        point = (
            retention_percent(
                score["summary"]["cross_modal_value_consistency_percent"], baseline_score
            )
            if np.isfinite(baseline_score) and baseline_score > 0 else None
        )
        legacy_ratio_diagnostic[name] = {
            "cross_modal_value_consistency_retention_percent": point,
            "warning": (
                "Diagnostic only; this unbounded small-denominator ratio has no confidence "
                "interval and is never used for pass/fail."
            ),
        }

    row_oi_profiles = image_profiles["original"][row_image_indices]
    row_pi_profiles = image_profiles["private"][row_image_indices]
    image_value_scores = centered_profile_similarity(row_oi_profiles, row_pi_profiles)
    text_value_scores = centered_profile_similarity(
        text_profiles["original"], text_profiles["private"]
    )
    original_cross_modal_scores = centered_profile_similarity(
        row_oi_profiles, text_profiles["original"]
    )
    private_cross_modal_scores = centered_profile_similarity(
        row_pi_profiles, text_profiles["private"]
    )
    relation_scores = np.clip(
        1.0 - np.abs(original_cross_modal_scores - private_cross_modal_scores), 0.0, 1.0
    )
    joint_scores = joint_value_preservation(
        image_value_scores, text_value_scores, relation_scores
    )
    joint_bootstrap = cluster_bootstrap_mean(
        joint_scores, image_keys, bootstrap_samples, bootstrap_seed
    )

    baseline_retrieval = raw_conditions["O_O"]["summary"]["retrieval"]
    private_retrieval = raw_conditions["P_P"]["summary"]["retrieval"]
    image_r1_retention = bounded_ratio_percent(
        private_retrieval["image_to_text"]["R@1_percent"],
        baseline_retrieval["image_to_text"]["R@1_percent"],
    )
    text_r1_retention = bounded_ratio_percent(
        private_retrieval["text_to_image"]["R@1_percent"],
        baseline_retrieval["text_to_image"]["R@1_percent"],
    )
    retrieval_r1_retention = float(math.sqrt(image_r1_retention * text_r1_retention))
    point = float(100.0 * joint_scores.mean())
    value_pass = point > target and joint_bootstrap["ci95_low"] > target
    utility_pass = retrieval_r1_retention > target
    text_cosine = np.sum(ot * pt, axis=1)
    conditions = {name: value["summary"] for name, value in raw_conditions.items()}
    per_pair = []
    for index, record in enumerate(records):
        per_pair.append({
            "pair_id": record["pair_id"],
            "split": record["split"],
            "anonymous_image_id": record["anonymous_image_id"],
            "O_O_value_consistency": float(raw_conditions["O_O"]["value_scores"][index]),
            "P_O_value_consistency": float(raw_conditions["P_O"]["value_scores"][index]),
            "O_P_value_consistency": float(raw_conditions["O_P"]["value_scores"][index]),
            "P_P_value_consistency": float(raw_conditions["P_P"]["value_scores"][index]),
            "image_value_profile_preservation": float(image_value_scores[index]),
            "text_value_profile_preservation": float(text_value_scores[index]),
            "cross_modal_relation_preservation": float(relation_scores[index]),
            "joint_value_preservation": float(joint_scores[index]),
            "original_private_text_cosine": float(text_cosine[index]),
        })
    return {
        "counts": {"images": len(unique_global_images), "pairs": len(records)},
        "conditions": conditions,
        "value_preservation": {
            "primary_metric": "joint_value_profile_preservation_percent",
            "joint_value_profile_preservation_percent": point,
            "image_value_profile_preservation_percent": float(100.0 * image_value_scores.mean()),
            "text_value_profile_preservation_percent": float(100.0 * text_value_scores.mean()),
            "cross_modal_relation_preservation_percent": float(100.0 * relation_scores.mean()),
            "original_cross_modal_profile_similarity_percent": float(
                100.0 * original_cross_modal_scores.mean()
            ),
            "private_cross_modal_profile_similarity_percent": float(
                100.0 * private_cross_modal_scores.mean()
            ),
            "bootstrap": joint_bootstrap,
            "target_percent": target,
            "point_estimate_above_target": point > target,
            "ci95_lower_bound_above_target": joint_bootstrap["ci95_low"] > target,
        },
        "semantic_utility_gate": {
            "image_to_text_R1_retention_percent": image_r1_retention,
            "text_to_image_R1_retention_percent": text_r1_retention,
            "joint_R1_retention_percent": retrieval_r1_retention,
            "target_percent": target,
            "above_target": utility_pass,
        },
        "conclusion": {
            "value_preservation_pass": value_pass,
            "semantic_utility_pass": utility_pass,
            "strict_pass": value_pass and utility_pass,
        },
        "legacy_ratio_diagnostic": legacy_ratio_diagnostic,
        "text_utility": {
            "original_private_moralclip_cosine_mean": float(text_cosine.mean()),
            "original_private_moralclip_cosine_median": float(np.median(text_cosine)),
        },
    }, per_pair


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(Path(__file__).with_name("privacy_pair_config.json")))
    parser.add_argument("--private-root")
    parser.add_argument("--splits", nargs="+", choices=["train", "validation", "test"])
    parser.add_argument(
        "--max-images-per-split", type=int,
        help="Smoke-test only; omit for every formal/full evaluation.",
    )
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8-sig"))
    base = config_path.parent
    dataset_root = resolve(cfg["dataset_root"], base)
    private_root = resolve(args.private_root or cfg["output_dir"], base)
    evaluation_cfg = cfg["evaluation"]
    splits = tuple(args.splits or evaluation_cfg.get("splits", ["test"]))
    source, private_manifest_path, records = load_joined_pairs(
        dataset_root, private_root, splits, args.max_images_per_split
    )
    for index, record in enumerate(records):
        record["global_index"] = index
    original_image_paths = list(dict.fromkeys(record["original_image_abs"] for record in records))
    original_image_index = {path: index for index, path in enumerate(original_image_paths)}
    image_indices = np.asarray(
        [original_image_index[record["original_image_abs"]] for record in records], dtype=np.int64
    )
    private_by_original = {}
    for record in records:
        private_by_original.setdefault(record["original_image_abs"], record["private_image_abs"])
        if private_by_original[record["original_image_abs"]] != record["private_image_abs"]:
            raise ValueError("One original image maps to multiple private images")
    private_image_paths = [private_by_original[path] for path in original_image_paths]

    model_cfg = dict(evaluation_cfg)
    model_cfg["model_dir"] = cfg["model_dir"]
    model, processor, device = load_model(model_cfg, base)
    batch_size = int(evaluation_cfg.get("batch_size", 32))
    original_image_features = encode_images(
        original_image_paths, model, processor, device, batch_size,
        label="Encode original images",
    )
    private_image_features = encode_images(
        private_image_paths, model, processor, device, batch_size,
        label="Encode private images",
    )
    original_text_features, original_truncated = encode_texts(
        [record["original_caption"] for record in records], model, processor, device,
        batch_size, label="Encode original captions",
    )
    private_text_features, private_truncated = encode_texts(
        [record["private_caption"] for record in records], model, processor, device,
        batch_size, label="Encode private captions",
    )
    labels, label_features = build_label_features(
        evaluation_cfg["value_prompts"], model, processor, device, batch_size
    )
    unknown = sorted({label for record in records for label in record["moral_labels"]} - set(labels))
    if unknown:
        raise ValueError("Labels missing from prompt bank: {}".format(unknown))
    logit_scale = float(model.logit_scale.detach().float().exp().cpu().item())
    target = float(evaluation_cfg.get("retention_target_percent", 80.0))
    split_reports = {}
    pair_rows = []
    for split in splits:
        selected = [record for record in records if record["split"] == split]
        report, rows = evaluate_split(
            selected, original_image_features, private_image_features,
            original_text_features, private_text_features, image_indices,
            label_features, labels, logit_scale,
            int(evaluation_cfg.get("retrieval_chunk_size", 128)),
            int(evaluation_cfg.get("bootstrap_samples", 2000)),
            int(evaluation_cfg.get("bootstrap_seed", 20261003)), target,
        )
        split_reports[split] = report
        pair_rows.extend(rows)
    report = {
        "schema_version": 2,
        "created": datetime.now().isoformat(),
        "metric_definition": {
            "value_consistency": "100 * mean(1 - JSD(P_value(image), P_value(text)) / ln(2))",
            "value_profile_similarity": "100 * (1 + cosine(centered value-score profiles)) / 2",
            "primary_retention": (
                "100 * mean(cuberoot(image-profile preservation * text-profile preservation "
                "* cross-modal-relation preservation))"
            ),
            "cross_modal_relation_preservation": "1 - abs(profile_similarity(O/O) - profile_similarity(P/P))",
            "semantic_utility_gate": (
                "geometric mean of capped P/P-to-O/O image-to-text and text-to-image R@1 ratios"
            ),
            "legacy_ratio": "100 * C(condition) / C(O/O); diagnostic only and never used for pass/fail",
            "primary_condition": "P/P",
            "target_percent": target,
            "strict_rule": (
                "bounded joint value-preservation point estimate and unique-image cluster-bootstrap "
                "lower CI exceed target, and joint R@1 semantic-utility retention exceeds target"
            ),
        },
        "inputs": {
            "dataset_root": str(dataset_root),
            "private_manifest": str(private_manifest_path),
            "private_manifest_sha256": file_sha256(private_manifest_path),
            "model_dir": str(resolve(cfg["model_dir"], base)),
            "splits": list(splits),
        },
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "device": device,
        },
        "truncation": {
            "original_caption_count": original_truncated,
            "private_caption_count": private_truncated,
        },
        "labels": labels,
        "splits": split_reports,
        "privacy_statement": (
            "LDP-Slicing and CluSanT use different modality-specific privacy definitions; "
            "this report does not claim a unified record-level epsilon."
        ),
    }
    output_root = resolve(evaluation_cfg.get("output_dir", "private_results"), base)
    output_dir = output_root / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / "report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (output_dir / "pairs.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(pair_rows[0]))
        writer.writeheader()
        writer.writerows(pair_rows)
    summary = {
        split: {
            "value_preservation": value["value_preservation"],
            "semantic_utility_gate": value["semantic_utility_gate"],
            "conclusion": value["conclusion"],
        }
        for split, value in split_reports.items()
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("Results: {}".format(output_dir))


if __name__ == "__main__":
    main()
