"""Metrics and adaptive classifiers for CLIP-style membership inference.

The cosine-similarity attack follows the threat model used by Ko et al.,
"Practical Membership Inference Attacks Against Large-Scale Multi-Modal
Models: A Pilot Study" (ICCV 2023).  This module contains only the project-
specific metric and calibration code; model queries are implemented by the
top-level evaluator.
"""

from __future__ import division

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, roc_auc_score, roc_curve
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def _as_binary(labels):
    values = np.asarray(labels, dtype=np.int64)
    if values.ndim != 1 or set(np.unique(values).tolist()) != {0, 1}:
        raise ValueError("Membership labels must contain both 0 and 1")
    return values


def orient_scores(calibration_labels, calibration_scores):
    """Choose score direction on calibration data, never on test data."""
    labels = _as_binary(calibration_labels)
    scores = np.asarray(calibration_scores, dtype=np.float64)
    auc = roc_auc_score(labels, scores)
    direction = 1.0 if auc >= 0.5 else -1.0
    return direction * scores, direction


def best_balanced_threshold(labels, scores):
    """Select the threshold maximizing calibration balanced accuracy."""
    labels = _as_binary(labels)
    scores = np.asarray(scores, dtype=np.float64)
    if not np.isfinite(scores).all():
        raise ValueError("Attack scores must be finite")
    unique = np.unique(scores)
    if len(unique) == 1:
        return float(unique[0])
    candidates = np.concatenate((
        [np.nextafter(unique[0], -np.inf)],
        0.5 * (unique[:-1] + unique[1:]),
        [np.nextafter(unique[-1], np.inf)],
    ))
    best_threshold = float(candidates[0])
    best_value = -1.0
    for threshold in candidates:
        predictions = (scores >= threshold).astype(np.int64)
        value = balanced_accuracy_score(labels, predictions)
        if value > best_value:
            best_value = value
            best_threshold = float(threshold)
    return best_threshold


def tpr_at_fpr(labels, scores, target_fpr=0.01):
    labels = _as_binary(labels)
    fpr, tpr, _ = roc_curve(labels, np.asarray(scores, dtype=np.float64))
    valid = np.flatnonzero(fpr <= float(target_fpr) + 1e-12)
    return float(tpr[valid].max()) if len(valid) else 0.0


def score_metrics(labels, scores, threshold):
    labels = _as_binary(labels)
    scores = np.asarray(scores, dtype=np.float64)
    predictions = (scores >= float(threshold)).astype(np.int64)
    tp = int(np.sum((predictions == 1) & (labels == 1)))
    tn = int(np.sum((predictions == 0) & (labels == 0)))
    fp = int(np.sum((predictions == 1) & (labels == 0)))
    fn = int(np.sum((predictions == 0) & (labels == 1)))
    return {
        "balanced_ASR_percent": float(100.0 * balanced_accuracy_score(labels, predictions)),
        "accuracy_percent": float(100.0 * np.mean(predictions == labels)),
        "AUC": float(roc_auc_score(labels, scores)),
        "TPR_at_1pct_FPR_percent": float(100.0 * tpr_at_fpr(labels, scores, 0.01)),
        "threshold": float(threshold),
        "confusion": {"TP": tp, "TN": tn, "FP": fp, "FN": fn},
        "predictions": predictions,
    }


def calibrated_scalar_attack(calibration_labels, calibration_scores,
                             test_labels, test_scores):
    oriented_calibration, direction = orient_scores(
        calibration_labels, calibration_scores
    )
    oriented_test = direction * np.asarray(test_scores, dtype=np.float64)
    threshold = best_balanced_threshold(calibration_labels, oriented_calibration)
    calibration = score_metrics(calibration_labels, oriented_calibration, threshold)
    test = score_metrics(test_labels, oriented_test, threshold)
    return {
        "score_direction": "higher_is_member" if direction > 0 else "lower_is_member",
        "calibration": calibration,
        "test": test,
        "calibration_scores": oriented_calibration,
        "test_scores": oriented_test,
    }


def calibrated_feature_attack(calibration_labels, calibration_features,
                              test_labels, test_features, seed=20261013):
    calibration_labels = _as_binary(calibration_labels)
    test_labels = _as_binary(test_labels)
    calibration_features = np.asarray(calibration_features, dtype=np.float64)
    test_features = np.asarray(test_features, dtype=np.float64)
    if calibration_features.ndim != 2 or test_features.ndim != 2:
        raise ValueError("Attack features must be two-dimensional")
    if calibration_features.shape[1] != test_features.shape[1]:
        raise ValueError("Calibration/test feature dimensions differ")
    model = make_pipeline(
        StandardScaler(),
        LogisticRegression(
            class_weight="balanced", random_state=int(seed), max_iter=2000,
            solver="liblinear",
        ),
    )
    model.fit(calibration_features, calibration_labels)
    calibration_scores = model.predict_proba(calibration_features)[:, 1]
    test_scores = model.predict_proba(test_features)[:, 1]
    threshold = best_balanced_threshold(calibration_labels, calibration_scores)
    return {
        "score_direction": "learned_member_probability",
        "calibration": score_metrics(calibration_labels, calibration_scores, threshold),
        "test": score_metrics(test_labels, test_scores, threshold),
        "calibration_scores": calibration_scores,
        "test_scores": test_scores,
        "model": model,
    }


def select_strongest_attack(attacks):
    """Select on calibration AUC, with balanced ASR as deterministic tie-break."""
    if not attacks:
        raise ValueError("No attacks were provided")
    return max(
        attacks,
        key=lambda name: (
            attacks[name]["calibration"]["AUC"],
            attacks[name]["calibration"]["balanced_ASR_percent"],
            name,
        ),
    )


def _clean_metrics(value):
    return {key: item for key, item in value.items() if key != "predictions"}


def public_attack_result(value):
    """Remove arrays and fitted sklearn objects before JSON serialization."""
    return {
        "score_direction": value["score_direction"],
        "calibration": _clean_metrics(value["calibration"]),
        "test": _clean_metrics(value["test"]),
    }


def stratified_cluster_bootstrap_difference(
        labels, cluster_ids, first_scores, first_threshold,
        second_scores, second_threshold, samples=2000, seed=20261013):
    """Paired image-cluster bootstrap for O/O minus P/P attack metrics."""
    labels = _as_binary(labels)
    clusters = np.asarray(cluster_ids, dtype=object)
    first_scores = np.asarray(first_scores, dtype=np.float64)
    second_scores = np.asarray(second_scores, dtype=np.float64)
    if not (len(labels) == len(clusters) == len(first_scores) == len(second_scores)):
        raise ValueError("Bootstrap arrays have different lengths")
    cluster_to_indices = {}
    cluster_to_label = {}
    for index, cluster in enumerate(clusters.tolist()):
        cluster_to_indices.setdefault(cluster, []).append(index)
        old = cluster_to_label.setdefault(cluster, int(labels[index]))
        if old != int(labels[index]):
            raise ValueError("One image cluster contains mixed membership labels")
    by_label = {
        label: [cluster for cluster, value in cluster_to_label.items() if value == label]
        for label in (0, 1)
    }
    if not by_label[0] or not by_label[1]:
        raise ValueError("Both member and non-member clusters are required")
    rng = np.random.default_rng(int(seed))
    differences = {"balanced_ASR_percent": [], "AUC_points": []}
    for _ in range(int(samples)):
        chosen = []
        for label in (0, 1):
            pool = by_label[label]
            chosen.extend(rng.choice(pool, size=len(pool), replace=True).tolist())
        indices = np.concatenate([
            np.asarray(cluster_to_indices[cluster], dtype=np.int64) for cluster in chosen
        ])
        sampled_labels = labels[indices]
        first = score_metrics(sampled_labels, first_scores[indices], first_threshold)
        second = score_metrics(sampled_labels, second_scores[indices], second_threshold)
        differences["balanced_ASR_percent"].append(
            first["balanced_ASR_percent"] - second["balanced_ASR_percent"]
        )
        differences["AUC_points"].append(100.0 * (first["AUC"] - second["AUC"]))
    result = {}
    for name, values in differences.items():
        array = np.asarray(values, dtype=np.float64)
        result[name] = {
            "mean": float(array.mean()),
            "ci95_low": float(np.quantile(array, 0.025)),
            "ci95_high": float(np.quantile(array, 0.975)),
        }
    return result

