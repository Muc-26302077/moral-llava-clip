"""在 PyCharm 中运行此文件。默认读取同目录 config.json。"""
import argparse
import csv
import hashlib
import json
import platform
from datetime import datetime
from pathlib import Path

import numpy as np


def resolve(value, base):
    p = Path(value).expanduser()
    return p.resolve() if p.is_absolute() else (base / p).resolve()


def is_relative_to(path, root):
    """Python 3.8-compatible equivalent of Path.is_relative_to()."""
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def load_rows(annotation, image_dir, split=None, manifest_root=None):
    """CSV/TSV: image,text; JSON: [{image,text}]; 或每张图同名 TXT。"""
    image_dir = image_dir.resolve()
    if manifest_root is not None:
        manifest_root = manifest_root.resolve()
    if annotation is None:
        extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tif', '.tiff'}
        raw = []
        for p in sorted(image_dir.rglob('*')):
            if p.suffix.lower() in extensions:
                txt = p.with_suffix('.txt')
                if not txt.is_file():
                    raise FileNotFoundError(f'缺少同名描述文件: {txt}')
                raw.append({'image': str(p.relative_to(image_dir)),
                            'text': txt.read_text(encoding='utf-8-sig')})
    elif annotation.suffix.lower() in {'.csv', '.tsv'}:
        with annotation.open(encoding='utf-8-sig', newline='') as f:
            raw = list(csv.DictReader(f, delimiter='\t' if annotation.suffix.lower() == '.tsv' else ','))
    elif annotation.suffix.lower() == '.json':
        raw = json.loads(annotation.read_text(encoding='utf-8-sig'))
        if not isinstance(raw, list):
            raise ValueError('JSON 须为 [{"image": "0001.jpg", "text": "描述"}, ...]')
    else:
        raise ValueError('描述文件支持 CSV、TSV、JSON；annotations=null 使用同名 TXT。')
    if raw and 'image_path' in raw[0]:
        if split is None or manifest_root is None:
            raise ValueError('SMID manifest 需要指定 split 和 manifest_root')
        expanded, duplicate_count = [], 0
        for item in raw:
            if item.get('split') != split:
                continue
            p = resolve(item['image_path'], manifest_root)
            if not is_relative_to(p, image_dir):
                raise ValueError(f'清单图片不属于配置的 split 目录: {p}')
            captions = item.get('captions') or [item.get('caption')]
            if not isinstance(captions, list) or not all(isinstance(t, str) and t.strip() for t in captions):
                raise ValueError(f'无效 captions: {p}')
            normalized = [t.strip() for t in captions]
            unique = list(dict.fromkeys(normalized))
            duplicate_count += len(normalized) - len(unique)
            expanded.extend({'image': str(p), 'text': t} for t in unique)
        print(f'{split}: 同一图片的完全重复描述去重 {duplicate_count} 条；保留全部不同描述。')
        raw = expanded
    rows, seen = [], set()
    for n, row in enumerate(raw, 1):
        if not isinstance(row, dict) or not all(isinstance(row.get(k), str) and row[k].strip()
                                               for k in ('image', 'text')):
            raise ValueError(f'第 {n} 条记录缺少有效的 image/text 字符串')
        p = resolve(row['image'].strip(), image_dir)
        if not p.is_file():
            raise FileNotFoundError(f'第 {n} 条图片不存在: {p}')
        caption = row['text'].strip()
        key = (str(p), caption)
        if key in seen:
            raise ValueError(f'第 {n} 条为完全重复的图文对，请检查: {p}')
        seen.add(key)
        rows.append({'image': str(p), 'text': caption})
    if not rows:
        raise ValueError(f'数据集为空: {image_dir}')
    return rows


def file_hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def audit_splits(datasets):
    cache, hashes, warnings = {}, {}, []
    for name, rows in datasets.items():
        paths = set(r['image'] for r in rows)
        for p in paths:
            if p not in cache:
                cache[p] = file_hash(p)
        hashes[name] = {cache[p] for p in paths}
        duplicates = len(paths) - len(hashes[name])
        if duplicates:
            warnings.append(f'{name}: 不同路径中有 {duplicates} 个字节完全相同的重复图片，请核查。')
    names = list(datasets)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            common = hashes[a] & hashes[b]
            if common:
                warnings.append(f'{a}/{b}: {len(common)} 张内容完全相同的图片跨集合重复。')
    return {'warnings': warnings, 'image_sha256': cache,
            'limitation': '仅检查文件字节重复；不能检测裁剪/重编码近重复，也不知道权重原始训练集。'}


def load_model(cfg, base):
    import torch
    from transformers import CLIPConfig, CLIPModel, CLIPProcessor
    model_dir = resolve(cfg['model_dir'], base)
    if not model_dir.is_dir():
        raise FileNotFoundError(f'请先修改 config.json 的 model_dir: {model_dir}')
    local = cfg.get('local_files_only', True)
    checkpoint = cfg.get('checkpoint_file')
    if checkpoint:
        # model_dir 提供与权重严格对应的 config.json；不先加载其他模型权重。
        model = CLIPModel(CLIPConfig.from_pretrained(str(model_dir), local_files_only=local))
        path = resolve(checkpoint, base)
        if path.suffix.lower() == '.safetensors':
            from safetensors.torch import load_file
            state = load_file(str(path))
        else:
            state = torch.load(str(path), map_location='cpu', weights_only=True)
        if isinstance(state, dict):
            for key in ('state_dict', 'model_state_dict'):
                if key in state:
                    state = state[key]
                    break
        if not isinstance(state, dict) or not state:
            raise ValueError('权重应为 HF CLIP 完整 state_dict，不支持直接保存的模型对象。')
        if all(k.startswith('module.') for k in state):
            state = {k[len('module.'):]: v for k, v in state.items()}
        model.load_state_dict(state, strict=True)
    else:
        model, info = CLIPModel.from_pretrained(str(model_dir), local_files_only=local,
                                               output_loading_info=True)
        errors = {k: info.get(k) for k in ('missing_keys', 'unexpected_keys', 'mismatched_keys', 'error_msgs')
                  if info.get(k)}
        if errors:
            raise RuntimeError(f'权重未完整匹配，停止评估: {errors}')
    processor_dir = resolve(cfg['processor_dir'], base) if cfg.get('processor_dir') else model_dir
    processor = CLIPProcessor.from_pretrained(str(processor_dir), local_files_only=local, use_fast=False)
    device = cfg.get('device', 'auto')
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = model.to(device).eval()
    print(f'模型已完整加载，设备: {device}', flush=True)
    return model, processor, device


def encode(rows, model, processor, device, batch_size, truncate):
    import torch
    from PIL import Image
    images = list(dict.fromkeys(r['image'] for r in rows))
    texts = list(dict.fromkeys(r['text'] for r in rows))
    image_index = {p: i for i, p in enumerate(images)}
    text_index = {t: i for i, t in enumerate(texts)}
    positives = np.zeros((len(images), len(texts)), dtype=bool)
    for r in rows:
        positives[image_index[r['image']], text_index[r['text']]] = True
    max_length = model.config.text_config.max_position_embeddings
    token_ids = processor.tokenizer(texts, truncation=False, padding=False)['input_ids']
    long_count = sum(len(ids) > max_length for ids in token_ids)
    if long_count and not truncate:
        raise ValueError(f'{long_count} 条描述超过 {max_length} tokens。请缩短描述，或明确设置 '
                         'truncate_long_text=true；截断会影响评价。')
    image_features, text_features = [], []
    with torch.inference_mode():
        for start in range(0, len(images), batch_size):
            batch = []
            for p in images[start:start + batch_size]:
                with Image.open(p) as im:
                    batch.append(im.convert('RGB'))
            inputs = processor(images=batch, return_tensors='pt').to(device)
            feat = model.get_image_features(**inputs)
            if not isinstance(feat, torch.Tensor):
                feat = feat.pooler_output  # Transformers 5 返回已投影的池化特征。
            image_features.append(torch.nn.functional.normalize(feat.float(), dim=-1).cpu().numpy())
            for im in batch:
                im.close()
            print(f'  图片 {min(start + batch_size, len(images))}/{len(images)}', flush=True)
        for start in range(0, len(texts), batch_size):
            options = {'max_length': max_length} if truncate else {}
            inputs = processor(text=texts[start:start + batch_size], return_tensors='pt',
                               padding=True, truncation=truncate, **options).to(device)
            feat = model.get_text_features(**inputs)
            if not isinstance(feat, torch.Tensor):
                feat = feat.pooler_output
            text_features.append(torch.nn.functional.normalize(feat.float(), dim=-1).cpu().numpy())
            if start % (batch_size * 50) == 0:
                print(f'  文本 {min(start + batch_size, len(texts))}/{len(texts)}', flush=True)
    return (np.concatenate(image_features), np.concatenate(text_features), positives,
            images, texts, image_index, text_index, long_count)


def retrieval(query, gallery, relevant, chunk_size):
    """全 split 候选池；多个已标注正确答案均有效；并列用保守排名。"""
    ranks, top_indices = [], []
    for start in range(0, len(query), chunk_size):
        scores = query[start:start + chunk_size] @ gallery.T
        pos = relevant[start:start + chunk_size]
        if not np.all(pos.any(axis=1)):
            raise ValueError('每个查询都必须有至少一个已标注正例。')
        best = np.where(pos, scores, -np.inf).max(axis=1)
        # 容差内同分负例全部排在正确答案前，避免排序顺序抬高指标。
        rank = 1 + ((scores >= best[:, None] - 1e-6) & ~pos).sum(axis=1)
        ranks.extend(rank.tolist())
        top_indices.extend(scores.argmax(axis=1).tolist())
    ranks = np.asarray(ranks)
    metrics = {f'R@{k}_percent': float(100 * np.mean(ranks <= k)) for k in (1, 5, 10)
               if k <= len(gallery)}
    metrics.update(query_count=len(query), gallery_count=len(gallery),
                   median_rank=float(np.median(ranks)), MRR=float(np.mean(1 / ranks)),
                   tie_policy='conservative: negatives within 1e-6 count before positives')
    return metrics, ranks, top_indices


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=str(Path(__file__).with_name('config.json')))
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    cfg = json.loads(config_path.read_text(encoding='utf-8-sig'))
    base = config_path.parent
    for key in ('batch_size', 'retrieval_chunk_size'):
        if not isinstance(cfg[key], int) or cfg[key] < 1:
            raise ValueError(f'{key} 必须是正整数')
    threshold = cfg.get('cosine_threshold')
    if threshold is not None and not -1 <= threshold <= 1:
        raise ValueError('cosine_threshold 须在 [-1,1] 内，不能填写 95。')
    datasets = {}
    for name, spec in cfg['splits'].items():
        if name not in ('train', 'validation', 'test'):
            raise ValueError(f'未知 split: {name}')
        image_dir = resolve(spec['image_dir'], base)
        annotation = resolve(spec['annotations'], base) if spec.get('annotations') else None
        manifest_root = resolve(spec['manifest_root'], base) if spec.get('manifest_root') else None
        datasets[name] = load_rows(annotation, image_dir, name, manifest_root)
    if not datasets:
        raise ValueError('至少配置一个 split')
    audit = audit_splits(datasets)
    for warning in audit['warnings']:
        print('数据检查:', warning)
    model, processor, device = load_model(cfg, base)
    import torch
    import transformers
    out = resolve(cfg['output_dir'], base) / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    out.mkdir(parents=True, exist_ok=False)
    report = {'config': cfg, 'versions': {'python': platform.python_version(),
              'torch': torch.__version__, 'transformers': transformers.__version__,
              'numpy': np.__version__}, 'device': device, 'audit': audit, 'splits': {},
              'interpretation': 'R@K measures annotated-pair retrieval, not semantic correctness '
                                'or paper moral-label mAP. Train is diagnostic only.'}
    for name, rows in datasets.items():
        print(f'\n评估 {name}: {len(rows)} 对', flush=True)
        im, tx, pos, images, texts, ii, ti, long_count = encode(
            rows, model, processor, device, cfg['batch_size'], cfg.get('truncate_long_text', False))
        if not np.isfinite(im).all() or not np.isfinite(tx).all():
            raise ValueError('模型产生了非有限特征，停止评估')
        i2t, irank, itop = retrieval(im, tx, pos, cfg['retrieval_chunk_size'])
        t2i, trank, ttop = retrieval(tx, im, pos.T, cfg['retrieval_chunk_size'])
        details = []
        for row in rows:
            i, j = ii[row['image']], ti[row['text']]
            cosine = float(np.clip(im[i] @ tx[j], -1, 1))
            item = dict(row, cosine=cosine, i2t_best_positive_rank=int(irank[i]),
                        t2i_best_positive_rank=int(trank[j]),
                        top_text=texts[itop[i]], top_image=images[ttop[j]])
            if threshold is not None:
                item['above_threshold'] = cosine >= threshold
            details.append(item)
        scores = np.asarray([d['cosine'] for d in details])
        stats = {'pair_count': len(rows), 'unique_images': len(images), 'unique_texts': len(texts),
                 'truncated_unique_texts': long_count,
                 'paired_cosine_mean': float(scores.mean()),
                 'paired_cosine_median': float(np.median(scores)),
                 'paired_cosine_p05': float(np.quantile(scores, .05)),
                 'paired_cosine_p95': float(np.quantile(scores, .95)),
                 'image_to_text': i2t, 'text_to_image': t2i}
        if threshold is not None:
            stats['threshold_pass_rate_percent_NOT_accuracy'] = float(100 * np.mean(scores >= threshold))
        report['splits'][name] = stats
        write_csv(out / f'{name}_pairs.csv', details)
        write_csv(out / f'{name}_lowest_cosine.csv', sorted(details, key=lambda x: x['cosine'])[:100])
        # 固定文件可复核实际使用的清单；所有样本都参与，没有按分数筛选。
        write_csv(out / f'{name}_manifest.csv', rows)
        (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(stats, ensure_ascii=False, indent=2), flush=True)
    print(f'\n完成。结果目录: {out}')


if __name__ == '__main__':
    main()
