"""Progress reporting that works in interactive terminals and nohup logs."""

import math
import sys
import time


class ProgressBar:
    """Render in place on a TTY and emit flushed checkpoints in redirected logs."""

    def __init__(self, label, total, initial=0, stream=None, log_updates=100, width=28):
        self.label = str(label)
        self.total = int(total)
        self.initial = int(initial)
        if self.total < 0 or not 0 <= self.initial <= self.total:
            raise ValueError("Progress total/initial values are invalid")
        self.stream = stream or sys.stdout
        self.is_tty = bool(getattr(self.stream, "isatty", lambda: False)())
        self.width = int(width)
        self.log_step = max(1, int(math.ceil(max(self.total, 1) / int(log_updates))))
        self.last_rendered = -1
        self.started = time.monotonic()
        self.update(self.initial, force=True)

    @staticmethod
    def _duration(seconds):
        seconds = max(0, int(seconds))
        minutes, seconds = divmod(seconds, 60)
        hours, minutes = divmod(minutes, 60)
        return "{:02d}:{:02d}:{:02d}".format(hours, minutes, seconds)

    def update(self, current, force=False):
        current = int(current)
        if not 0 <= current <= self.total:
            raise ValueError("Progress value is outside [0, total]")
        if current < self.last_rendered:
            raise ValueError("Progress cannot move backwards")
        should_render = (
            force or self.is_tty or current == self.total or
            self.last_rendered < 0 or current - self.last_rendered >= self.log_step
        )
        if not should_render:
            return
        elapsed = time.monotonic() - self.started
        newly_completed = current - self.initial
        rate = newly_completed / elapsed if elapsed > 0 and newly_completed > 0 else 0.0
        remaining = self.total - current
        fraction = current / self.total if self.total else 1.0
        filled = min(self.width, int(round(self.width * fraction)))
        bar = "#" * filled + "-" * (self.width - filled)
        eta = self._duration(remaining / rate) if rate > 0 else "--:--:--"
        message = (
            "{} [{}] {:6.2f}% {}/{} elapsed={} eta={} rate={:.2f}/s".format(
                self.label, bar, 100.0 * fraction, current, self.total,
                self._duration(elapsed), eta, rate,
            )
        )
        if self.is_tty:
            self.stream.write("\r" + message)
            if current == self.total:
                self.stream.write("\n")
        else:
            self.stream.write(message + "\n")
        self.stream.flush()
        self.last_rendered = current

