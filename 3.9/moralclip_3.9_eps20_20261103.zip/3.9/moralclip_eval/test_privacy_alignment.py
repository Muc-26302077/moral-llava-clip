import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from evaluate_privacy_alignment import js_similarity, load_joined_records, retention_percent
from prepare_privacy_inputs import canonical_sha256
from run_cadp_bridge import load_bridge_rows


class PrivacyAlignmentTests(unittest.TestCase):
    def test_js_similarity_bounds_and_identity(self):
        p = np.array([[0.5, 0.5], [1.0, 0.0]])
        np.testing.assert_allclose(js_similarity(p, p), [1.0, 1.0])
        self.assertAlmostEqual(float(js_similarity([[1.0, 0.0]], [[0.0, 1.0]])[0]), 0.0)

    def test_retention(self):
        self.assertEqual(retention_percent(0.76, 0.8), 95.0)
        with self.assertRaises(ValueError):
            retention_percent(1.0, 0.0)

    def test_strict_join(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "test").mkdir()
            (root / "test" / "a.jpg").write_bytes(b"image")
            records = [{"row_id": 0, "sample_id": "test:a:0", "image_path": "test/a.jpg",
                        "text": "original", "moral_labels": ["Care"]}]
            bundle = {"kind": "smid_cadp_bridge_input", "records": records,
                      "records_sha256": canonical_sha256(records)}
            bundle_path = root / "input.json"
            result_path = root / "private.json"
            bundle_path.write_text(json.dumps(bundle), encoding="utf-8")
            result_path.write_text(json.dumps([{"ground_truth": 0, "text": "original",
                                                "perturbed_sentence": "private"}]), encoding="utf-8")
            _, joined = load_joined_records(bundle_path, result_path, root)
            self.assertEqual(joined[0]["private_text"], "private")
            result_path.write_text(json.dumps([]), encoding="utf-8")
            with self.assertRaises(ValueError):
                load_joined_records(bundle_path, result_path, root)

    def test_bridge_rows_preserve_stable_ids(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "input.json"
            records = [{"row_id": 0, "sample_id": "test:a:0", "text": "caption"}]
            path.write_text(json.dumps({"kind": "smid_cadp_bridge_input", "records": records}), encoding="utf-8")
            _, rows = load_bridge_rows(path)
            self.assertEqual(rows, [{"text": "caption", "label": 0, "user_id": "test:a:0"}])


if __name__ == "__main__":
    unittest.main()
