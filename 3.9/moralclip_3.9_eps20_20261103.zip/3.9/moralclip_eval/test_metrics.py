"""仅测试评价逻辑；不会下载模型或使用真实数据。"""
import tempfile
import json
import unittest
from pathlib import Path
import numpy as np
from evaluate import retrieval, load_rows, audit_splits


class MetricTests(unittest.TestCase):
    def test_smid_manifest_split_and_captions(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'test').mkdir()
            (root / 'test' / 'a.jpg').write_bytes(b'manifest test')
            path = root / 'manifest.json'
            path.write_text(json.dumps([
                {'split': 'test', 'image_path': 'test/a.jpg', 'captions': ['one', 'two', 'one']},
                {'split': 'train', 'image_path': 'train/missing.jpg', 'captions': ['other']}
            ]), encoding='utf-8')
            rows = load_rows(path, root / 'test', 'test', root)
            self.assertEqual([r['text'] for r in rows], ['one', 'two'])

    def test_perfect_and_swapped(self):
        x = np.eye(3, dtype=np.float32)
        pos = np.eye(3, dtype=bool)
        good, _, _ = retrieval(x, x, pos, 1)
        bad, _, _ = retrieval(x, x[[1, 2, 0]], pos, 2)
        self.assertEqual(good['R@1_percent'], 100)
        self.assertEqual(bad['R@1_percent'], 0)
        self.assertNotIn('R@5_percent', good)

    def test_multiple_captions(self):
        images = np.eye(2, dtype=np.float32)
        texts = np.array([[1, 0], [1, 0], [0, 1]], dtype=np.float32)
        pos = np.array([[1, 1, 0], [0, 0, 1]], dtype=bool)
        self.assertEqual(retrieval(images, texts, pos, 1)[0]['R@1_percent'], 100)
        self.assertEqual(retrieval(texts, images, pos.T, 2)[0]['R@1_percent'], 100)

    def test_ties_do_not_inflate_scores(self):
        x = np.ones((3, 2), dtype=np.float32)
        metrics, ranks, _ = retrieval(x, x, np.eye(3, dtype=bool), 2)
        self.assertEqual(metrics['R@1_percent'], 0)
        np.testing.assert_array_equal(ranks, [3, 3, 3])

    def test_chunk_invariance(self):
        rng = np.random.default_rng(4)
        x, y = rng.normal(size=(13, 4)), rng.normal(size=(13, 4))
        pos = np.eye(13, dtype=bool)
        self.assertEqual(retrieval(x, y, pos, 1)[0], retrieval(x, y, pos, 7)[0])

    def test_data_and_leakage(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'a.jpg').write_bytes(b'fake image for manifest-only test')
            (root / 'b.jpg').write_bytes((root / 'a.jpg').read_bytes())
            annotation = root / 'a.csv'
            annotation.write_text('image,text\na.jpg,"Hello, world"\n', encoding='utf-8-sig')
            rows = load_rows(annotation, root)
            self.assertEqual(rows[0]['text'], 'Hello, world')
            audit = audit_splits({'train': rows, 'test': [{'image': str(root / 'b.jpg'), 'text': 'Other'}]})
            self.assertEqual(len(audit['warnings']), 1)
            annotation.write_text('image,text\na.jpg,Hello\na.jpg,Hello\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                load_rows(annotation, root)


if __name__ == '__main__':
    unittest.main()
