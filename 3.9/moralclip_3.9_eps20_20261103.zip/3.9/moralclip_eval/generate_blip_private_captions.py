"""Generate one BLIP caption per already-private image and write an audit cache."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from privacy_pipeline.blip_private_caption import BlipPrivateCaptioner, load_blip_config
from privacy_pipeline.manifest_schema import (
    atomic_write_json,
    canonical_sha256,
    file_sha256,
    is_within,
)


VALID_SPLITS = ("train", "validation", "test")


def generate_caption_cache(source_root, output_path, blip_config_path, splits):
    source_root = Path(source_root).expanduser().resolve()
    output_path = Path(output_path).expanduser().resolve()
    if not source_root.is_dir():
        raise FileNotFoundError("Private source root not found: {}".format(source_root))
    if output_path.exists():
        raise FileExistsError("Caption cache already exists: {}".format(output_path))
    manifest_path = source_root / "pair_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = manifest.get("pairs")
    if manifest.get("kind") != "smid_private_ldpslicing_clusant" or not isinstance(rows, list):
        raise ValueError("Invalid private-pair manifest")
    if manifest.get("private_pairs_sha256") not in (None, canonical_sha256(rows)):
        raise ValueError("Source private_pairs_sha256 mismatch")
    selected = [row for row in rows if row.get("split") in splits]
    if not selected:
        raise ValueError("No private rows for splits={}".format(list(splits)))
    images = {}
    for row in selected:
        key = "{}:{}".format(row["split"], row["anonymous_image_id"])
        relative = row["private_image_path"]
        if key in images and images[key] != relative:
            raise ValueError("One private image maps to multiple paths: {}".format(key))
        images[key] = relative
    ordered = sorted(images.items())
    paths = []
    for _, relative in ordered:
        path = (source_root / relative).resolve()
        if not is_within(path, source_root) or not path.is_file():
            raise FileNotFoundError("Private image missing/outside root: {}".format(path))
        paths.append(path)

    config_path, config = load_blip_config(blip_config_path)
    captioner = BlipPrivateCaptioner(config, config_path.parent)
    candidate_groups = captioner.generate_candidates(paths)
    records = []
    for (key, relative), path, candidates in zip(ordered, paths, candidate_groups):
        split, anonymous_image_id = key.split(":", 1)
        records.append({
            "image_key": key,
            "split": split,
            "anonymous_image_id": anonymous_image_id,
            "private_image_path": relative,
            "private_image_sha256": file_sha256(path),
            "blip_caption": candidates[0],
            "blip_candidates": candidates,
        })
    payload = {
        "schema_version": 1,
        "kind": "blip_captions_from_ldp_private_images",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "selected_splits": list(splits),
        "source_private_manifest_sha256": file_sha256(manifest_path),
        "model": captioner.metadata(),
        "image_count": len(records),
        "records": records,
    }
    payload["records_sha256"] = canonical_sha256(records)
    atomic_write_json(output_path, payload)
    print(json.dumps({key: value for key, value in payload.items() if key != "records"},
                     ensure_ascii=False, indent=2))
    print("BLIP caption cache: {}".format(output_path))
    return payload


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--blip-config", default=str(Path(__file__).with_name("blip_caption_config.json"))
    )
    parser.add_argument("--splits", nargs="+", choices=VALID_SPLITS, default=["validation"])
    args = parser.parse_args()
    generate_caption_cache(
        args.source_root, args.output, args.blip_config, tuple(args.splits)
    )


if __name__ == "__main__":
    main()
