"""Create two reproducible figures from a private-pair evaluation report."""

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True)
    parser.add_argument("--out-dir", default=".")
    args = parser.parse_args()
    report = json.loads(Path(args.report).read_text(encoding="utf-8"))
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    splits = list(report["splits"])
    conditions = ["O_O", "P_O", "O_P", "P_P"]

    x = np.arange(len(conditions))
    width = 0.8 / max(1, len(splits))
    fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
    for index, split in enumerate(splits):
        values = [
            report["splits"][split]["conditions"][name]["cross_modal_value_consistency_percent"]
            for name in conditions
        ]
        ax.bar(x + (index - (len(splits) - 1) / 2) * width, values, width, label=split)
    ax.set_xticks(x, ["Original/Original", "Private image", "Private text", "Private/Private"])
    ax.set_ylabel("Cross-modal value consistency (%)")
    ax.set_title("MoralCLIP value consistency by privacy condition")
    ax.set_ylim(0, 105)
    ax.legend()
    fig.savefig(out_dir / "Figure_1.png", dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
    names = ["P_O", "O_P", "P_P"]
    offset = 0.12
    for index, split in enumerate(splits):
        values = [report["splits"][split]["preservation"][name] for name in names]
        means = np.asarray([value["cross_modal_value_consistency_retention_percent"] for value in values])
        lows = np.asarray([value["bootstrap"]["ci95_low"] for value in values])
        highs = np.asarray([value["bootstrap"]["ci95_high"] for value in values])
        positions = np.arange(len(names)) + (index - (len(splits) - 1) / 2) * offset
        ax.errorbar(positions, means, yerr=[means - lows, highs - means], fmt="o", capsize=4, label=split)
    target = float(report["metric_definition"]["target_percent"])
    ax.axhline(target, color="red", linestyle="--", label="target ({:.0f}%)".format(target))
    ax.set_xticks(np.arange(len(names)), ["Private image", "Private text", "Private/Private"])
    ax.set_ylabel("Value-consistency retention (%)")
    ax.set_title("Privacy utility with image-cluster bootstrap 95% CI")
    ax.legend()
    fig.savefig(out_dir / "Figure_2.png", dpi=200)
    plt.close(fig)
    print("Wrote {} and {}".format(out_dir / "Figure_1.png", out_dir / "Figure_2.png"))


if __name__ == "__main__":
    main()
