"""LDP-Slicing image sanitizer adapted from the official Apache-2.0 code.

Upstream: https://github.com/HideTheDandi/LDP-Slicing
Pinned during adaptation: e3154540ed42e1d1c6022ae4d00df7f43a11a193

The randomized bit-plane mechanism and optimized budget table retain the
upstream semantics. This adapter adds PIL I/O, odd-size padding, secret-derived
per-image randomness, PNG output, hashing and strict metadata checks.
"""

import json
from contextlib import contextmanager
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

from .image_postprocessing import (
    apply_private_image_postprocessing,
    resolve_postprocess_config,
)
from .manifest_schema import derive_seed, file_sha256


SUPPORTED_TOTAL_EPSILONS = (1.0, 2.4, 5.2, 12.0, 20.0, 32.0, 58.0)
COLOR_ALIASES = {"411": "4:1:1", "211": "2:1:1", "111": "1:1:1"}


def load_budget(total_epsilon, color_weight="411", budget_path=None):
    budget_path = Path(budget_path or Path(__file__).with_name("ldp_privacy_budgets.json"))
    table = json.loads(budget_path.read_text(encoding="utf-8"))
    color_key = COLOR_ALIASES.get(str(color_weight).replace(":", ""), color_weight)
    if color_key not in table:
        raise ValueError("Unknown LDP-Slicing color weight: {}".format(color_weight))
    epsilon_key = "{:.1f}".format(float(total_epsilon))
    if epsilon_key not in table[color_key]:
        raise ValueError(
            "epsilon_image={} is not in the official optimized table; choose {}".format(
                total_epsilon, SUPPORTED_TOTAL_EPSILONS
            )
        )
    row = table[color_key][epsilon_key]
    epsilon_y = tuple(float(x) for x in row["epsilon_y"])
    epsilon_cb = tuple(float(x) for x in row["epsilon_cb"])
    epsilon_cr = tuple(float(x) for x in row["epsilon_cr"])
    if len(epsilon_y) != 8 or len(epsilon_cb) != 8 or epsilon_cb != epsilon_cr:
        raise ValueError("Invalid LDP-Slicing budget table row")
    actual_total = sum(epsilon_y) + sum(epsilon_cb) + sum(epsilon_cr)
    if abs(actual_total - float(total_epsilon)) > 0.05:
        raise ValueError(
            "Budget row sums to {:.6f}, expected {}".format(actual_total, total_epsilon)
        )
    return epsilon_y, epsilon_cb, actual_total, color_key, epsilon_key


def _require_torch_wavelets():
    try:
        import torch
        from pytorch_wavelets import DWTForward, DWTInverse
    except ImportError as exc:
        raise RuntimeError(
            "Formal LDP-Slicing requires torch and pytorch-wavelets. "
            "Install requirements_privacy.txt; no non-private fallback is allowed."
        ) from exc
    return torch, DWTForward, DWTInverse


def _to_ycbcr(x, max_value=255.0):
    if x.ndim != 4 or x.size(1) != 3:
        raise ValueError("Expected RGB tensor [N,3,H,W], got {}".format(tuple(x.shape)))
    delta = max_value / 2.0
    red, green, blue = x[:, 0:1], x[:, 1:2], x[:, 2:3]
    y = 0.299000 * red + 0.587000 * green + 0.114000 * blue
    cb = -0.168736 * red - 0.331264 * green + 0.500000 * blue + delta
    cr = 0.500000 * red - 0.418688 * green - 0.081312 * blue + delta
    return torch_cat((y, cb, cr), dim=1)


def _to_rgb(ycbcr, max_value=255.0):
    if ycbcr.ndim != 4 or ycbcr.size(1) != 3:
        raise ValueError("Expected YCbCr tensor [N,3,H,W], got {}".format(tuple(ycbcr.shape)))
    delta = max_value / 2.0
    y = ycbcr[:, 0:1]
    cb = ycbcr[:, 1:2] - delta
    cr = ycbcr[:, 2:3] - delta
    red = y + 1.402000 * cr
    green = y - 0.344136 * cb - 0.714136 * cr
    blue = y + 1.772000 * cb
    return torch_cat((red, green, blue), dim=1)


def torch_cat(values, dim):
    import torch
    return torch.cat(values, dim=dim)


def bit_plane_slicing(channel_data, epsilon, device):
    import torch
    if channel_data.ndim != 4 or channel_data.size(1) != 1:
        raise ValueError("Expected one-channel tensor [N,1,H,W]")
    if isinstance(epsilon, (int, float)):
        values = [float(epsilon)] * 8
    else:
        values = [float(value) for value in epsilon]
    if len(values) != 8 or any(value < 0 for value in values):
        raise ValueError("epsilon must contain eight non-negative per-bit budgets")
    image_bytes = channel_data.clamp(0, 255).to(torch.uint8)
    shifts = torch.arange(8, device=device, dtype=torch.uint8).view(1, 1, 8, 1, 1)
    bit_planes = ((image_bytes.unsqueeze(2) >> shifts) & 1).to(torch.float32)
    budgets = torch.tensor(values, device=device, dtype=torch.float32)
    truthful_probability = torch.sigmoid(budgets).view(1, 1, 8, 1, 1)
    random_values = torch.rand_like(bit_planes)
    randomized = torch.where(
        random_values < truthful_probability, bit_planes, 1.0 - bit_planes
    )
    weights = (2 ** torch.arange(8, device=device, dtype=torch.float32)).view(
        1, 1, 8, 1, 1
    )
    return (randomized * weights).sum(dim=2)


def dp_slicing_dwt(x, epsilon_y, epsilon_c, device, wavelet="haar", level=1,
                   remove_ll=True, ll_scale=0.0, mode="periodization"):
    torch, DWTForward, DWTInverse = _require_torch_wavelets()
    if x.ndim != 4 or x.size(1) != 3:
        raise ValueError("Expected RGB tensor [N,3,H,W]")
    x = x.to(device)
    dwt = DWTForward(J=int(level), wave=wavelet, mode=mode).to(device)
    idwt = DWTInverse(wave=wavelet, mode=mode).to(device)
    x_255 = x * 255.0 if x.max().item() <= 1.0 else x
    centered = _to_ycbcr(x_255) - 128.0
    y_centered, cb_centered, cr_centered = torch.chunk(centered, 3, dim=1)
    y_ll, y_high = dwt(y_centered)
    cb_ll, cb_high = dwt(cb_centered)
    cr_ll, cr_high = dwt(cr_centered)
    if remove_ll:
        y_ll = y_ll * float(ll_scale)
        cb_ll = cb_ll * float(ll_scale)
        cr_ll = cr_ll * float(ll_scale)
    y_obfuscated = (idwt((y_ll, y_high)) + 128.0).clamp(0, 255)
    cb_obfuscated = (idwt((cb_ll, cb_high)) + 128.0).clamp(0, 255)
    cr_obfuscated = (idwt((cr_ll, cr_high)) + 128.0).clamp(0, 255)
    y_private = bit_plane_slicing(y_obfuscated, epsilon_y, device)
    cb_private = bit_plane_slicing(cb_obfuscated, epsilon_c, device)
    cr_private = bit_plane_slicing(cr_obfuscated, epsilon_c, device)
    private_ycbcr = torch.cat((y_private, cb_private, cr_private), dim=1).clamp(0, 255)
    return _to_rgb(private_ycbcr).clamp(0, 255) / 255.0


@contextmanager
def _isolated_torch_seed(seed, device):
    import torch
    devices = []
    if str(device).startswith("cuda") and torch.cuda.is_available():
        index = torch.device(device).index
        devices = [torch.cuda.current_device() if index is None else index]
    with torch.random.fork_rng(devices=devices, enabled=True):
        torch.manual_seed(int(seed))
        if devices:
            torch.cuda.manual_seed_all(int(seed))
        yield


def _pad_to_wavelet_multiple(array, level):
    multiple = 2 ** int(level)
    height, width = array.shape[:2]
    pad_height = (-height) % multiple
    pad_width = (-width) % multiple
    if pad_height or pad_width:
        array = np.pad(array, ((0, pad_height), (0, pad_width), (0, 0)), mode="edge")
    return array, height, width, pad_height, pad_width


class LdpSlicingSanitizer:
    def __init__(self, config, secret):
        import torch
        self.config = dict(config)
        self.secret = secret
        requested = self.config.get("device", "auto")
        self.device = "cuda" if requested == "auto" and torch.cuda.is_available() else requested
        if self.device == "auto":
            self.device = "cpu"
        self.total_epsilon = float(self.config["epsilon"])
        values = load_budget(
            self.total_epsilon,
            self.config.get("color_weight", "411"),
            self.config.get("budget_path"),
        )
        self.epsilon_y, self.epsilon_c, self.actual_total, self.color_key, self.budget_key = values
        self.level = int(self.config.get("level", 1))
        self.wavelet = self.config.get("wavelet", "haar")
        self.remove_ll = bool(self.config.get("remove_ll", True))
        self.ll_scale = float(self.config.get("ll_scale", 0.0))
        self.mode = self.config.get("mode", "periodization")
        self.postprocess = resolve_postprocess_config(
            self.config.get("postprocess", {"method": "identity"})
        )

    def metadata(self):
        return {
            "mechanism": "LDP-Slicing",
            "upstream_commit": "e3154540ed42e1d1c6022ae4d00df7f43a11a193",
            "privacy_scope": "pixel/bit-plane local differential privacy",
            "epsilon_image_requested": self.total_epsilon,
            "epsilon_image_schedule_sum": self.actual_total,
            "color_weight": self.color_key,
            "budget_key": self.budget_key,
            "epsilon_y": list(self.epsilon_y),
            "epsilon_c": list(self.epsilon_c),
            "wavelet": self.wavelet,
            "level": self.level,
            "remove_ll": self.remove_ll,
            "ll_scale": self.ll_scale,
            "postprocessing": self.postprocess,
            "postprocessing_privacy_note": (
                "Consumes only the LDP-Slicing output and does not access the original image."
            ),
            "device": self.device,
        }

    def sanitize_file(self, input_path, output_path, stable_image_id):
        import torch
        input_path = Path(input_path)
        output_path = Path(output_path)
        with Image.open(str(input_path)) as image:
            image = ImageOps.exif_transpose(image).convert("RGB")
            rgb = np.asarray(image, dtype=np.uint8)
        padded, height, width, pad_height, pad_width = _pad_to_wavelet_multiple(
            rgb, self.level
        )
        tensor = torch.from_numpy(padded.copy()).permute(2, 0, 1).unsqueeze(0).float() / 255.0
        seed = derive_seed(self.secret, "ldp-slicing-image", stable_image_id)
        with _isolated_torch_seed(seed, self.device), torch.inference_mode():
            private = dp_slicing_dwt(
                tensor,
                epsilon_y=self.epsilon_y,
                epsilon_c=self.epsilon_c,
                device=self.device,
                wavelet=self.wavelet,
                level=self.level,
                remove_ll=self.remove_ll,
                ll_scale=self.ll_scale,
                mode=self.mode,
            )
        private = private[0, :, :height, :width].detach().cpu().permute(1, 2, 0).numpy()
        private_uint8 = np.rint(np.clip(private, 0.0, 1.0) * 255.0).astype(np.uint8)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        private_image = Image.fromarray(private_uint8, mode="RGB")
        private_image = apply_private_image_postprocessing(private_image, self.postprocess)
        private_image.save(str(output_path), format="PNG", optimize=False)
        return {
            "private_image_sha256": file_sha256(output_path),
            "width": width,
            "height": height,
            "pad_width": pad_width,
            "pad_height": pad_height,
            "postprocessing": self.postprocess,
        }
