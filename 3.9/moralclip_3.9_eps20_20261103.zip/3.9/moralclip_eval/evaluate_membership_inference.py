"""Run adaptive CLIP-style membership inference on O/O and P/P pairs.

This evaluator deliberately separates an unverified proxy experiment from a
formal membership audit.  A formal conclusion requires documented evidence
that the configured member records were used to train the frozen target model
and that the non-member records were not used for training or model selection.
"""

import argparse
import csv
import json
import platform
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from evaluate import load_model
from privacy_attacks.clip_mia import (
    calibrated_feature_attack,
    calibrated_scalar_attack,
    public_attack_result,
    select_strongest_attack,
    stratified_cluster_bootstrap_difference,
)
from privacy_pipeline.manifest_schema import file_sha256, load_smid_pairs
from privacy_pipeline.progress import ProgressBar


CONDITIONS = ("O_O", "P_P")
AUGMENTATION_NAMES = ("mirror", "brightness", "contrast", "rotate")


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def read_config(path):
    path = Path(path).resolve()
    return json.loads(path.read_text(encoding="utf-8-sig")), path.parent


def validate_provenance(config, allow_unverified_proxy):
    provenance = config.get("membership_provenance") or {}
    confirmed = provenance.get("confirmed") is True
    evidence = str(provenance.get("evidence", "")).strip()
    if confirmed and not evidence:
        raise ValueError("Confirmed membership provenance requires non-empty evidence")
    if not confirmed and not allow_unverified_proxy:
        raise RuntimeError(
            "Membership provenance is not confirmed. Add documentary evidence and set "
            "membership_provenance.confirmed=true, or use --allow-unverified-proxy "
            "for an exploratory result that cannot support a formal privacy claim."
        )
    return {
        "confirmed": confirmed,
        "evidence": evidence or "No verified model-training membership evidence supplied.",
        "claim_scope": (
            "formal_membership_inference" if confirmed
            else "exploratory_proxy_only_not_a_formal_membership_claim"
        ),
    }


def load_private_rows(private_root):
    manifest_path = Path(private_root).resolve() / "pair_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError("Private pair manifest not found: {}".format(manifest_path))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = manifest.get("pairs")
    if not isinstance(rows, list) or not rows:
        raise ValueError("Private pair manifest has no pairs")
    by_id = {}
    for row in rows:
        pair_id = row.get("pair_id")
        if not isinstance(pair_id, str) or pair_id in by_id:
            raise ValueError("Invalid or duplicate private pair_id: {}".format(pair_id))
        image_path = (manifest_path.parent / row["private_image_path"]).resolve()
        if not image_path.is_file():
            raise FileNotFoundError("Private image missing: {}".format(image_path))
        caption = row.get("private_caption")
        if not isinstance(caption, str) or not caption.strip():
            raise ValueError("Empty private caption: {}".format(pair_id))
        by_id[pair_id] = {
            "private_image_abs": str(image_path),
            "private_caption": caption.strip(),
        }
    return manifest_path, manifest, by_id


def image_records(rows, split):
    result = {}
    for row in rows:
        if row["split"] != split:
            continue
        key = row["anonymous_image_id"]
        record = result.setdefault(key, {
            "anonymous_image_id": key,
            "moral_labels": tuple(sorted(row["moral_labels"])),
            "rows": [],
        })
        if record["moral_labels"] != tuple(sorted(row["moral_labels"])):
            raise ValueError("Inconsistent moral labels for image {}".format(key))
        record["rows"].append(row)
    return result


def matched_image_units(rows, member_split, nonmember_split, seed,
                        max_images_per_class=None):
    member = image_records(rows, member_split)
    nonmember = image_records(rows, nonmember_split)
    member_by_signature = defaultdict(list)
    nonmember_by_signature = defaultdict(list)
    for record in member.values():
        member_by_signature[record["moral_labels"]].append(record)
    for record in nonmember.values():
        nonmember_by_signature[record["moral_labels"]].append(record)
    rng = np.random.default_rng(int(seed))
    units = []
    for signature in sorted(set(member_by_signature) & set(nonmember_by_signature)):
        left = member_by_signature[signature]
        right = nonmember_by_signature[signature]
        rng.shuffle(left)
        rng.shuffle(right)
        units.extend(zip(left[:min(len(left), len(right))], right[:min(len(left), len(right))]))
    rng.shuffle(units)
    if max_images_per_class is not None:
        units = units[:int(max_images_per_class)]
    if len(units) < 4:
        raise ValueError("Need at least four label-matched member/non-member image pairs")
    return units


def split_units(units, calibration_fraction):
    count = len(units)
    calibration_count = int(round(count * float(calibration_fraction)))
    calibration_count = min(max(calibration_count, 2), count - 2)
    return units[:calibration_count], units[calibration_count:]


def flatten_units(calibration_units, test_units):
    selected = []
    stage_by_image = {}
    membership_by_image = {}
    for stage, units in (("calibration", calibration_units), ("test", test_units)):
        for member_record, nonmember_record in units:
            for record, membership in ((member_record, 1), (nonmember_record, 0)):
                image_id = record["anonymous_image_id"]
                stage_by_image[image_id] = stage
                membership_by_image[image_id] = membership
                selected.extend(record["rows"])
    selected.sort(key=lambda row: (stage_by_image[row["anonymous_image_id"]],
                                   membership_by_image[row["anonymous_image_id"]],
                                   row["pair_id"]))
    return selected, stage_by_image, membership_by_image


def join_private(selected_rows, private_by_id):
    joined = []
    missing = []
    for row in selected_rows:
        private = private_by_id.get(row["pair_id"])
        if private is None:
            missing.append(row["pair_id"])
            continue
        joined.append(dict(row, **private))
    if missing:
        raise ValueError(
            "Private manifest is missing {} selected pairs; first IDs: {}".format(
                len(missing), missing[:5]
            )
        )
    return joined


def _feature_tensor(value, torch):
    return value if isinstance(value, torch.Tensor) else value.pooler_output


def _augment(image, name):
    from PIL import ImageEnhance, ImageOps
    if name == "mirror":
        return ImageOps.mirror(image)
    if name == "brightness":
        return ImageEnhance.Brightness(image).enhance(0.85)
    if name == "contrast":
        return ImageEnhance.Contrast(image).enhance(0.85)
    if name == "rotate":
        return image.rotate(5.0, resample=2)
    raise ValueError("Unknown augmentation: {}".format(name))


def encode_image_variants(paths, model, processor, device, batch_size,
                          augmentations):
    import torch
    from PIL import Image
    variants = ("base",) + tuple(augmentations)
    outputs = []
    progress = ProgressBar("Encode image attack views", len(paths) * len(variants))
    completed = 0
    with torch.inference_mode():
        for variant in variants:
            features = []
            for start in range(0, len(paths), batch_size):
                batch = []
                for path in paths[start:start + batch_size]:
                    with Image.open(path) as source:
                        image = source.convert("RGB")
                    batch.append(image if variant == "base" else _augment(image, variant))
                inputs = processor(images=batch, return_tensors="pt").to(device)
                values = _feature_tensor(model.get_image_features(**inputs), torch).float()
                values = torch.nn.functional.normalize(values, dim=-1)
                features.append(values.cpu().numpy())
                completed += len(batch)
                progress.update(completed)
            outputs.append(np.concatenate(features))
    return np.stack(outputs, axis=0), list(variants)


def encode_texts(texts, model, processor, device, batch_size):
    import torch
    features = []
    max_length = model.config.text_config.max_position_embeddings
    progress = ProgressBar("Encode attack captions", len(texts))
    with torch.inference_mode():
        for start in range(0, len(texts), batch_size):
            batch = texts[start:start + batch_size]
            inputs = processor(
                text=batch, return_tensors="pt", padding=True, truncation=True,
                max_length=max_length,
            ).to(device)
            values = _feature_tensor(model.get_text_features(**inputs), torch).float()
            values = torch.nn.functional.normalize(values, dim=-1)
            features.append(values.cpu().numpy())
            progress.update(min(start + batch_size, len(texts)))
    return np.concatenate(features)


def condition_features(rows, condition, model, processor, device, batch_size,
                       augmentations):
    if condition not in CONDITIONS:
        raise ValueError("Unknown condition: {}".format(condition))
    image_field = "original_image_abs" if condition == "O_O" else "private_image_abs"
    text_field = "original_caption" if condition == "O_O" else "private_caption"
    image_paths = list(dict.fromkeys(row[image_field] for row in rows))
    image_index = {path: index for index, path in enumerate(image_paths)}
    row_image_indices = np.asarray([image_index[row[image_field]] for row in rows])
    image_features, variant_names = encode_image_variants(
        image_paths, model, processor, device, batch_size, augmentations
    )
    text_features = encode_texts(
        [row[text_field] for row in rows], model, processor, device, batch_size
    )
    similarities = np.stack([
        np.sum(variant[row_image_indices] * text_features, axis=1)
        for variant in image_features
    ], axis=1)
    base = similarities[:, 0]
    if similarities.shape[1] > 1:
        augmented = similarities[:, 1:]
        attack_features = np.column_stack((
            base,
            augmented.mean(axis=1),
            augmented.std(axis=1),
            base - augmented.mean(axis=1),
            augmented.min(axis=1),
            augmented.max(axis=1),
        ))
        feature_names = [
            "base_cosine", "augmentation_mean", "augmentation_std",
            "base_minus_augmentation_mean", "augmentation_min", "augmentation_max",
        ]
    else:
        attack_features = base[:, None]
        feature_names = ["base_cosine"]
    return {
        "base_scores": base,
        "attack_features": attack_features,
        "feature_names": feature_names,
        "variant_names": variant_names,
    }


def run_condition(labels, stages, features, seed):
    calibration_mask = stages == "calibration"
    test_mask = stages == "test"
    attacks = {
        "cosine_similarity": calibrated_scalar_attack(
            labels[calibration_mask], features["base_scores"][calibration_mask],
            labels[test_mask], features["base_scores"][test_mask],
        )
    }
    if features["attack_features"].shape[1] > 1:
        attacks["augmentation_enhanced"] = calibrated_feature_attack(
            labels[calibration_mask], features["attack_features"][calibration_mask],
            labels[test_mask], features["attack_features"][test_mask], seed=seed,
        )
    selected = select_strongest_attack(attacks)
    return attacks, selected, test_mask


def counts_by_stage(rows, stages, labels):
    result = {}
    for stage in ("calibration", "test"):
        mask = stages == stage
        result[stage] = {
            "pairs": int(mask.sum()),
            "member_pairs": int(np.sum(labels[mask] == 1)),
            "nonmember_pairs": int(np.sum(labels[mask] == 0)),
            "unique_images": int(len({
                row["anonymous_image_id"] for row, keep in zip(rows, mask.tolist()) if keep
            })),
        }
    return result


def write_pair_csv(path, rows, stages, labels, condition_outputs):
    fields = [
        "pair_id", "anonymous_image_id", "split", "attack_stage", "is_member",
        "OO_selected_attack", "OO_score", "OO_prediction",
        "PP_selected_attack", "PP_score", "PP_prediction",
    ]
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for index, row in enumerate(rows):
            values = {
                "pair_id": row["pair_id"],
                "anonymous_image_id": row["anonymous_image_id"],
                "split": row["split"],
                "attack_stage": stages[index],
                "is_member": int(labels[index]),
            }
            for condition, prefix in (("O_O", "OO"), ("P_P", "PP")):
                attack = condition_outputs[condition]["selected_name"]
                output = condition_outputs[condition]["attacks"][attack]
                if stages[index] == "calibration":
                    mask = condition_outputs[condition]["calibration_mask"]
                    local = int(np.sum(mask[:index]))
                    score = output["calibration_scores"][local]
                    prediction = output["calibration"]["predictions"][local]
                else:
                    mask = condition_outputs[condition]["test_mask"]
                    local = int(np.sum(mask[:index]))
                    score = output["test_scores"][local]
                    prediction = output["test"]["predictions"][local]
                values[prefix + "_selected_attack"] = attack
                values[prefix + "_score"] = float(score)
                values[prefix + "_prediction"] = int(prediction)
            writer.writerow(values)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(Path(__file__).with_name(
        "membership_inference_config.json")))
    parser.add_argument("--private-root")
    parser.add_argument("--out-dir")
    parser.add_argument("--max-images-per-class", type=int)
    parser.add_argument("--allow-unverified-proxy", action="store_true")
    parser.add_argument("--no-augmentations", action="store_true")
    args = parser.parse_args()

    cfg, base = read_config(args.config)
    provenance = validate_provenance(cfg, args.allow_unverified_proxy)
    dataset_root = resolve(cfg["dataset_root"], base)
    private_root = resolve(args.private_root or cfg["private_root"], base)
    member_split = cfg.get("member_split", "train")
    nonmember_split = cfg.get("nonmember_split", "test")
    if member_split == nonmember_split:
        raise ValueError("Member and non-member splits must differ")

    print("This experiment compares an adaptive CLIP-style membership attack on O/O and P/P.")
    print("Claim scope: {}".format(provenance["claim_scope"]), flush=True)
    source = load_smid_pairs(dataset_root, splits=(member_split, nonmember_split))
    manifest_path, private_manifest, private_by_id = load_private_rows(private_root)
    source_pair_count = len(source["pairs"])
    available_source_rows = [
        row for row in source["pairs"] if row["pair_id"] in private_by_id
    ]
    available_by_split = {
        split: sum(row["split"] == split for row in available_source_rows)
        for split in (member_split, nonmember_split)
    }
    if not all(available_by_split.values()):
        raise ValueError(
            "Private manifest does not overlap both membership splits: {}".format(
                available_by_split
            )
        )
    seed = int(cfg.get("seed", 20261013))
    units = matched_image_units(
        available_source_rows, member_split, nonmember_split, seed,
        args.max_images_per_class or cfg.get("max_images_per_class"),
    )
    calibration_units, test_units = split_units(
        units, cfg.get("calibration_fraction", 0.5)
    )
    selected_rows, stage_by_image, membership_by_image = flatten_units(
        calibration_units, test_units
    )
    rows = join_private(selected_rows, private_by_id)
    stages = np.asarray([stage_by_image[row["anonymous_image_id"]] for row in rows])
    labels = np.asarray([membership_by_image[row["anonymous_image_id"]] for row in rows])
    clusters = np.asarray([row["anonymous_image_id"] for row in rows], dtype=object)

    model_cfg = {
        "model_dir": cfg["model_dir"],
        "processor_dir": cfg.get("processor_dir"),
        "checkpoint_file": cfg.get("checkpoint_file"),
        "local_files_only": cfg.get("local_files_only", True),
        "device": cfg.get("device", "auto"),
    }
    model_cfg = {key: value for key, value in model_cfg.items() if value is not None}
    model, processor, device = load_model(model_cfg, base)
    augmentations = () if args.no_augmentations else tuple(
        cfg.get("augmentations", AUGMENTATION_NAMES)
    )

    condition_outputs = {}
    for condition in CONDITIONS:
        print("\nEvaluating membership condition {}".format(condition), flush=True)
        features = condition_features(
            rows, condition, model, processor, device,
            int(cfg.get("batch_size", 32)), augmentations,
        )
        attacks, selected_name, test_mask = run_condition(labels, stages, features, seed)
        condition_outputs[condition] = {
            "features": features,
            "attacks": attacks,
            "selected_name": selected_name,
            "calibration_mask": stages == "calibration",
            "test_mask": test_mask,
        }
        result = attacks[selected_name]["test"]
        print(json.dumps({
            "selected_attack": selected_name,
            "balanced_ASR_percent": result["balanced_ASR_percent"],
            "AUC": result["AUC"],
            "TPR_at_1pct_FPR_percent": result["TPR_at_1pct_FPR_percent"],
        }, ensure_ascii=False, indent=2), flush=True)

    oo_name = condition_outputs["O_O"]["selected_name"]
    pp_name = condition_outputs["P_P"]["selected_name"]
    oo_attack = condition_outputs["O_O"]["attacks"][oo_name]
    pp_attack = condition_outputs["P_P"]["attacks"][pp_name]
    test_mask = stages == "test"
    oo_test = oo_attack["test"]
    pp_test = pp_attack["test"]
    asr_drop = oo_test["balanced_ASR_percent"] - pp_test["balanced_ASR_percent"]
    auc_drop = 100.0 * (oo_test["AUC"] - pp_test["AUC"])
    tpr_drop = (
        oo_test["TPR_at_1pct_FPR_percent"] - pp_test["TPR_at_1pct_FPR_percent"]
    )
    relative_asr_drop = (
        100.0 * asr_drop / oo_test["balanced_ASR_percent"]
        if oo_test["balanced_ASR_percent"] > 0 else None
    )
    bootstrap = stratified_cluster_bootstrap_difference(
        labels[test_mask], clusters[test_mask],
        oo_attack["test_scores"], oo_test["threshold"],
        pp_attack["test_scores"], pp_test["threshold"],
        samples=int(cfg.get("bootstrap_samples", 2000)), seed=seed,
    )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output_base = resolve(args.out_dir or cfg.get("output_dir", "membership_inference_runs"), base)
    run_dir = output_base / timestamp
    run_dir.mkdir(parents=True, exist_ok=False)
    report = {
        "schema_version": 1,
        "method": {
            "name": "adaptive CLIP-style membership inference",
            "paper": "Practical Membership Inference Attacks Against Large-Scale Multi-Modal Models: A Pilot Study",
            "venue": "ICCV 2023",
            "paper_url": "https://openaccess.thecvf.com/content/ICCV2023/html/Ko_Practical_Membership_Inference_Attacks_Against_Large-Scale_Multi-Modal_Models_A_Pilot_ICCV_2023_paper.html",
            "upstream_code": "https://github.com/ruoxi-jia-group/CLIP-MIA",
            "adaptation": "cosine-similarity and augmentation-enhanced attacks; each condition is independently calibrated",
        },
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "provenance": provenance,
        "inputs": {
            "dataset_root": str(dataset_root),
            "private_root": str(private_root),
            "private_manifest_sha256": file_sha256(manifest_path),
            "model_dir": str(resolve(cfg["model_dir"], base)),
            "member_split": member_split,
            "nonmember_split": nonmember_split,
            "source_pair_count_before_private_intersection": source_pair_count,
            "available_private_pairs_by_split": available_by_split,
        },
        "design": {
            "matching": "one-to-one unique-image matching by exact moral-label signature",
            "split_unit": "unique image; all captions stay in one attack stage",
            "calibration_fraction": float(cfg.get("calibration_fraction", 0.5)),
            "condition_specific_recalibration": True,
            "selection_rule": "highest calibration AUC, then calibration balanced ASR",
            "augmentations": list(augmentations),
            "counts": counts_by_stage(rows, stages, labels),
            "matched_images_per_class": len(units),
        },
        "conditions": {},
        "defense_effect": {
            "balanced_ASR_absolute_drop_points": float(asr_drop),
            "balanced_ASR_relative_drop_percent": (
                None if relative_asr_drop is None else float(relative_asr_drop)
            ),
            "AUC_drop_points": float(auc_drop),
            "TPR_at_1pct_FPR_drop_points": float(tpr_drop),
            "cluster_bootstrap": bootstrap,
            "defense_direction": "improved" if asr_drop > 0 and auc_drop > 0 else "not_consistently_improved",
        },
        "interpretation": (
            "Formal MIA evidence is permitted because membership provenance was confirmed."
            if provenance["confirmed"] else
            "Exploratory proxy only: train/test split labels are not verified target-model membership labels."
        ),
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "device": device,
        },
    }
    for condition in CONDITIONS:
        value = condition_outputs[condition]
        report["conditions"][condition] = {
            "selected_attack": value["selected_name"],
            "feature_names": value["features"]["feature_names"],
            "image_views": value["features"]["variant_names"],
            "attacks": {
                name: public_attack_result(attack)
                for name, attack in value["attacks"].items()
            },
        }
    report_path = run_dir / "report.json"
    payload = json.dumps(report, ensure_ascii=False, indent=2)
    report_path.write_text(payload, encoding="utf-8")
    (run_dir / "final_info.json").write_text(payload, encoding="utf-8")
    write_pair_csv(
        run_dir / "pair_predictions.csv", rows, stages, labels, condition_outputs
    )

    try:
        from plot_membership_inference import create_figures
        create_figures(report, run_dir)
    except Exception as error:
        print("Plot warning: {}".format(error), flush=True)

    print("\n===== Membership inference defense effect =====")
    print("O/O balanced ASR: {:.4f}%".format(oo_test["balanced_ASR_percent"]))
    print("P/P balanced ASR: {:.4f}%".format(pp_test["balanced_ASR_percent"]))
    print("ASR absolute drop: {:.4f} percentage points".format(asr_drop))
    print("O/O AUC: {:.6f}".format(oo_test["AUC"]))
    print("P/P AUC: {:.6f}".format(pp_test["AUC"]))
    print("AUC drop: {:.4f} points".format(auc_drop))
    print("O/O TPR@1%FPR: {:.4f}%".format(oo_test["TPR_at_1pct_FPR_percent"]))
    print("P/P TPR@1%FPR: {:.4f}%".format(pp_test["TPR_at_1pct_FPR_percent"]))
    print("Claim scope: {}".format(provenance["claim_scope"]))
    print("Report: {}".format(report_path))


if __name__ == "__main__":
    main()

