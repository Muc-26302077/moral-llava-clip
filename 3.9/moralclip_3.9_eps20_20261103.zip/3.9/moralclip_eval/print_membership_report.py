"""Print the essential O/O versus P/P membership-inference results."""

import argparse
import json
from pathlib import Path


def latest_report(root):
    reports = list(Path(root).expanduser().resolve().glob("*/report.json"))
    if not reports:
        raise FileNotFoundError("No report.json found below {}".format(root))
    return max(reports, key=lambda path: path.stat().st_mtime)


def selected_test(report, condition):
    block = report["conditions"][condition]
    name = block["selected_attack"]
    return name, block["attacks"][name]["test"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--report")
    group.add_argument("--root")
    args = parser.parse_args()
    path = Path(args.report).resolve() if args.report else latest_report(args.root)
    report = json.loads(path.read_text(encoding="utf-8"))
    oo_name, oo = selected_test(report, "O_O")
    pp_name, pp = selected_test(report, "P_P")
    effect = report["defense_effect"]
    interval = effect["cluster_bootstrap"]["balanced_ASR_percent"]

    print("===== 成员推理攻击结果 =====")
    print("结论范围:", report["provenance"]["claim_scope"])
    print("O/O最强攻击:", oo_name)
    print("P/P最强攻击:", pp_name)
    print("O/O平衡ASR:", oo["balanced_ASR_percent"], "%")
    print("P/P平衡ASR:", pp["balanced_ASR_percent"], "%")
    print("ASR绝对下降:", effect["balanced_ASR_absolute_drop_points"], "个百分点")
    print("ASR下降95% CI: [", interval["ci95_low"], ",", interval["ci95_high"], "]")
    print("O/O AUC:", oo["AUC"])
    print("P/P AUC:", pp["AUC"])
    print("AUC下降:", effect["AUC_drop_points"], "个百分点")
    print("O/O TPR@1%FPR:", oo["TPR_at_1pct_FPR_percent"], "%")
    print("P/P TPR@1%FPR:", pp["TPR_at_1pct_FPR_percent"], "%")
    print("报告路径:", path)


if __name__ == "__main__":
    main()

