# 3.7 隐私保护图文检索评测

本目录整理 LDP-Slicing 图像扰动、CluSanT 适配文本扰动及 MoralCLIP 图文检索评估的实验代码。正式冻结配置由验证集选择，测试集仅用于报告结果。

## 冻结方案

| 模块 | 参数 |
| --- | --- |
| 图像 | LDP-Slicing，epsilon_image=20，颜色权重 4:1:1，median3 后处理 |
| 文本 | CluSanT 适配，epsilon_text=20 |
| 候选与融合 | BLIP 24 beams / 24 candidates，对每个私有图文对使用冻结 MoralCLIP 选择最终融合文本，最多 77 tokens |

图像与文本 epsilon 使用不同的模态隐私定义，不能相加后声称统一的图文记录级 epsilon。文本隐私声明仅覆盖机制选中且位于词表内的 token；未选中或 OOV 的 token 不在该声明范围内。后处理仅使用已私有化图像、已私有化文本和冻结模型权重。

## 已有结果

| 数据集 | 图→文 R@1 保持率 | 文→图 R@1 保持率 | 双向几何平均保持率 |
| --- | ---: | ---: | ---: |
| Validation | 87.8788% | 76.1628% | 81.8113% |
| Test（126 张图，1260 对） | 91.2698% | 77.0985% | 83.8855% |

探索性成员推断代理攻击：私有图文对 balanced ASR 为 52.3016%，AUC 0.5124。模型训练成员身份尚未验证，此结果不能用作正式成员推断泄露结论。

## 运行与数据

代码位于 `moralclip_eval/`，逐对融合脚本位于 `experiments/`。模型权重、数据、私有样本、候选缓存和运行结果均需单独准备。原实验使用 Python 3.12 和 CUDA；依赖见 `moralclip_eval/requirements_privacy.txt`。安装依赖和准备模型时应遵守模型、数据及第三方软件许可。

原始配置中的 `/root/autodl-tmp` 是实验服务器路径，迁移时必须修改配置中的模型、数据与输出路径；冻结说明 JSON 是实验记录，不是完整的一键执行配置。LDP-Slicing、CluSanT 的实际运行还依赖其各自外部实现及数据资产，参见第三方声明与部署说明。请先查看各脚本的 `--help`，并先在少量数据上验证。

已有私有数据生成后，下面示例展示固定方案的后处理；将尖括号替换为实际路径：

```bash
cd 3.7/moralclip_eval
python postprocess_private_dataset.py --source-root <private-root> --output-root <median-root> --preset median3 --splits test
python generate_blip_private_captions.py --source-root <median-root> --output <cache.json> --blip-config ../experiments/blip_beam24.json --splits test
PYTHONPATH=. python ../experiments/pairwise_image_rerank_anysplit.py --source-root <median-root> --caption-cache <cache.json> --config <epsilon20-config.json> --output-root <variant-root> --split test
python evaluate_private_pairs.py --config <evaluation-config.json> --private-root <variant-root> --splits test
```

候选缓存与源清单绑定；后处理脚本拒绝覆盖已存在的输出目录。正式评估使用全部 test，不使用 `--max-images-per-split`。

## 目录与记录

- `moralclip_eval/`：隐私管线、生成与评估脚本、依赖、第三方声明和参数说明。
- `experiments/`：本次冻结方案的逐对重排脚本、BLIP 配置和 ε=20 的原始实验配置。
- `moralclip_eval/正式参数冻结说明.md`、`正式测试结果说明.md`：验证集选择和测试结果记录。
