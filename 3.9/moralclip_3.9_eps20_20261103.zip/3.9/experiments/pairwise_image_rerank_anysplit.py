"""Split-specific per-pair private-image-space fusion reranking experiment."""
import argparse
import copy
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from evaluate import load_model
from evaluate_private_pairs import encode_images, encode_texts
from postprocess_private_dataset import build_split_manifests
from privacy_pipeline.blip_private_caption import fit_fusion_to_token_budget
from privacy_pipeline.manifest_schema import atomic_write_json, canonical_sha256, file_sha256, is_within
from privacy_pipeline.progress import ProgressBar


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--caption-cache", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--split", choices=["train", "validation", "test"], default="validation")
    args = parser.parse_args()
    source_root = Path(args.source_root).resolve()
    cache_path = Path(args.caption_cache).resolve()
    config_path = Path(args.config).resolve()
    output_root = Path(args.output_root).resolve()
    if output_root.exists():
        raise FileExistsError("Refusing to overwrite {}".format(output_root))

    cfg = json.loads(config_path.read_text(encoding="utf-8-sig"))
    manifest_path = source_root / "pair_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = manifest.get("pairs")
    if manifest.get("kind") != "smid_private_ldpslicing_clusant" or not isinstance(rows, list):
        raise ValueError("Invalid private source manifest")
    selected = [copy.deepcopy(row) for row in rows if row.get("split") == args.split]
    if not selected:
        raise ValueError("No rows for requested split")

    cache = json.loads(cache_path.read_text(encoding="utf-8"))
    records = cache.get("records")
    if cache.get("kind") != "blip_captions_from_ldp_private_images" or not isinstance(records, list):
        raise ValueError("Invalid BLIP cache")
    if cache.get("records_sha256") != canonical_sha256(records):
        raise ValueError("BLIP cache hash mismatch")
    if cache.get("source_private_manifest_sha256") != file_sha256(manifest_path):
        raise ValueError("BLIP cache source mismatch")
    by_image = {record["image_key"]: record for record in records}
    image_keys = sorted(by_image)

    model_cfg = dict(cfg["evaluation"])
    model_cfg["model_dir"] = cfg["model_dir"]
    model, processor, device = load_model(model_cfg, config_path.parent)
    batch_size = int(model_cfg.get("batch_size", 32))
    image_paths = []
    for key in image_keys:
        path = (source_root / by_image[key]["private_image_path"]).resolve()
        if not is_within(path, source_root) or not path.is_file():
            raise FileNotFoundError("Invalid private image {}".format(path))
        image_paths.append(str(path))
    image_features = encode_images(image_paths, model, processor, device, batch_size,
                                   label="Encode LDP-private images for pairwise selection")
    image_by_key = dict(zip(image_keys, image_features))
    tokenizer = processor.tokenizer
    max_length = int(model.config.text_config.max_position_embeddings)

    all_fused = []
    spans = []
    for row in selected:
        key = "{}:{}".format(row["split"], row["anonymous_image_id"])
        record = by_image.get(key)
        if record is None:
            raise ValueError("Missing candidate record for {}".format(key))
        group = list(dict.fromkeys(record.get("blip_candidates") or [record["blip_caption"]]))
        start = len(all_fused)
        all_fused.extend([
            fit_fusion_to_token_budget(candidate, row["private_caption"], tokenizer, max_length=max_length)
            for candidate in group
        ])
        spans.append((row, key, group, start, len(all_fused)))
    text_features, _ = encode_texts(all_fused, model, processor, device, batch_size,
                                    label="Encode final private fusion candidates")
    for row, key, group, start, end in spans:
        scores = text_features[start:end] @ image_by_key[key]
        best = int(np.argmax(scores))
        row["private_caption"] = all_fused[start + best]
        privacy = dict(row.get("privacy") or {})
        privacy["caption_postprocessing"] = {
            "method": "MoralCLIP per-pair final-fusion reranking",
            "strategy": "pairwise_image_rerank_compact",
            "candidate_count": len(group),
            "selected_candidate_index": best,
            "selected_private_image_text_cosine": float(scores[best]),
            "token_budget": max_length,
            "privacy_basis": "uses only an LDP-private image, a CluSanT-private caption, and public frozen weights",
        }
        row["privacy"] = privacy

    images = {}
    for row in selected:
        images["{}:{}".format(row["split"], row["anonymous_image_id"])] = row["private_image_path"]
    output_root.mkdir(parents=True, exist_ok=False)
    progress = ProgressBar("Copy private images", len(images))
    for index, (key, relative) in enumerate(sorted(images.items()), 1):
        source = (source_root / relative).resolve()
        target = (output_root / relative).resolve()
        if not is_within(source, source_root) or not source.is_file():
            raise FileNotFoundError("Private image missing {}".format(source))
        if not is_within(target, output_root):
            raise ValueError("Output path escaped root")
        if file_sha256(source) != by_image[key]["private_image_sha256"]:
            raise ValueError("Private image hash changed {}".format(key))
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        progress.update(index)

    derived = {
        "schema_version": 1,
        "kind": "smid_private_ldpslicing_clusant",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_private_manifest_sha256": file_sha256(manifest_path),
        "blip_caption_cache_sha256": file_sha256(cache_path),
        "pair_count": len(selected),
        "unique_image_count": len(images),
        "selected_splits": [args.split],
        "caption_fusion_strategy": "pairwise_image_rerank_compact",
        "caption_candidate_selection": "MoralCLIP cosine reranking of final fused captions against LDP-private image",
        "pairs": selected,
    }
    derived["private_pairs_sha256"] = canonical_sha256(selected)
    atomic_write_json(output_root / "pair_manifest.json", derived)
    build_split_manifests(selected, output_root)
    atomic_write_json(output_root / "privacy_config.json", {
        "schema_version": 1,
        "source_private_manifest_sha256": derived["source_private_manifest_sha256"],
        "blip_caption_cache_sha256": derived["blip_caption_cache_sha256"],
        "caption_fusion_strategy": "pairwise_image_rerank_compact",
        "selection_boundary": "split-specific experiment",
        "privacy_boundary": "Post-processing reads only LDP-private images, CluSanT-private captions, and public frozen weights.",
    })
    audit = {
        "schema_version": 1,
        "status": "complete",
        "strategy": "pairwise_image_rerank_compact",
        "selected_splits": [args.split],
        "pair_count": len(selected),
        "unique_image_count": len(images),
        "candidate_count_mean": float(len(all_fused) / len(selected)),
        "private_pairs_sha256": derived["private_pairs_sha256"],
    }
    atomic_write_json(output_root / "caption_postprocess_audit.json", audit)
    candidate_cfg = copy.deepcopy(cfg)
    candidate_cfg["output_dir"] = str(output_root)
    candidate_cfg["splits"] = [args.split]
    candidate_cfg["evaluation"]["splits"] = [args.split]
    candidate_cfg["evaluation"]["output_dir"] = str(output_root.parent / "evaluation_results")
    config_out = output_root.parent / "config.json"
    atomic_write_json(config_out, candidate_cfg)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print("Derived config: {}".format(config_out))
    print("Variant root: {}".format(output_root))


if __name__ == "__main__":
    main()
