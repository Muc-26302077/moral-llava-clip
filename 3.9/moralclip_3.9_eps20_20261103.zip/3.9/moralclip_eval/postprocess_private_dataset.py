"""Create a DP-safe image-restored view of an existing private dataset.

Only already-private PNG files and the public private-pair manifest are read.
The original SMID images and captions are intentionally not accepted as inputs.
"""

import argparse
import copy
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from privacy_pipeline.image_postprocessing import (
    PRESETS,
    postprocess_private_file,
    resolve_postprocess_config,
)
from privacy_pipeline.manifest_schema import (
    atomic_write_json,
    canonical_sha256,
    file_sha256,
    is_within,
)
from privacy_pipeline.progress import ProgressBar


VALID_SPLITS = ("train", "validation", "test")


def build_split_manifests(public_pairs, output_dir):
    grouped = defaultdict(lambda: defaultdict(list))
    for row in public_pairs:
        grouped[row["split"]][row["anonymous_image_id"]].append(row)
    for split, images in grouped.items():
        manifest = []
        for anonymous_image_id, rows in images.items():
            rows = sorted(rows, key=lambda row: row["caption_index"])
            first = rows[0]
            manifest.append({
                "id": anonymous_image_id,
                "source_dataset": "smid_private_ldpslicing_clusant_postprocessed",
                "split": split,
                "image_path": first["private_image_path"],
                "captions": [row["private_caption"] for row in rows],
                "caption": first["private_caption"],
                "moral_labels": first["moral_labels"],
                "source_image_id_hash": anonymous_image_id,
            })
        atomic_write_json(output_dir / split / "smid_manifest.json", manifest)


def postprocess_dataset(source_root, output_root, preset, splits):
    source_root = Path(source_root).expanduser().resolve()
    output_root = Path(output_root).expanduser().resolve()
    if not source_root.is_dir():
        raise FileNotFoundError("Private source root not found: {}".format(source_root))
    if output_root.exists():
        raise FileExistsError(
            "Output already exists; refusing to mix runs: {}".format(output_root)
        )
    if output_root == source_root or is_within(output_root, source_root):
        raise ValueError("Output must not be inside the source private dataset")
    config = resolve_postprocess_config({"preset": preset})
    source_manifest_path = source_root / "pair_manifest.json"
    source_manifest = json.loads(source_manifest_path.read_text(encoding="utf-8"))
    rows = source_manifest.get("pairs")
    if source_manifest.get("kind") != "smid_private_ldpslicing_clusant" or not isinstance(rows, list):
        raise ValueError("Invalid source private-pair manifest")
    expected_hash = source_manifest.get("private_pairs_sha256")
    if expected_hash and expected_hash != canonical_sha256(rows):
        raise ValueError("Source private_pairs_sha256 mismatch")
    selected = [copy.deepcopy(row) for row in rows if row.get("split") in splits]
    if not selected:
        raise ValueError("No private pairs found for splits={}".format(list(splits)))
    pair_ids = [row.get("pair_id") for row in selected]
    if any(not isinstance(value, str) for value in pair_ids) or len(pair_ids) != len(set(pair_ids)):
        raise ValueError("Invalid or duplicate pair_id in source private manifest")

    images = {}
    for row in selected:
        relative = row.get("private_image_path")
        if not isinstance(relative, str) or not relative:
            raise ValueError("Missing private_image_path for {}".format(row["pair_id"]))
        key = (row["split"], row["anonymous_image_id"])
        existing = images.setdefault(key, relative)
        if existing != relative:
            raise ValueError("One private image maps to multiple paths: {}".format(key))

    output_root.mkdir(parents=True, exist_ok=False)
    image_audit = {}
    progress = ProgressBar("Post-process private images", len(images))
    for index, (key, relative) in enumerate(sorted(images.items()), 1):
        input_path = (source_root / relative).resolve()
        output_path = (output_root / relative).resolve()
        if not is_within(input_path, source_root) or not input_path.is_file():
            raise FileNotFoundError("Private input image missing/outside root: {}".format(input_path))
        if not is_within(output_path, output_root):
            raise ValueError("Private output image escaped root: {}".format(output_path))
        image_audit["{}:{}".format(*key)] = postprocess_private_file(
            input_path, output_path, config
        )
        progress.update(index)

    for row in selected:
        privacy = dict(row.get("privacy") or {})
        privacy["image_postprocessing"] = config
        privacy["image_postprocessing_privacy_basis"] = (
            "post-processing of an already-private LDP-Slicing image only"
        )
        row["privacy"] = privacy
    manifest = {
        "schema_version": 1,
        "kind": "smid_private_ldpslicing_clusant",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_private_manifest_sha256": file_sha256(source_manifest_path),
        "pairs_sha256_source": source_manifest.get("pairs_sha256_source"),
        "pair_count": len(selected),
        "unique_image_count": len(images),
        "selected_splits": list(splits),
        "pairs": selected,
    }
    manifest["private_pairs_sha256"] = canonical_sha256(selected)
    atomic_write_json(output_root / "pair_manifest.json", manifest)
    build_split_manifests(selected, output_root)

    source_privacy_config_path = source_root / "privacy_config.json"
    source_privacy_config_sha256 = None
    source_privacy_summary = None
    if source_privacy_config_path.is_file():
        source_privacy_config_sha256 = file_sha256(source_privacy_config_path)
        source_privacy_config = json.loads(
            source_privacy_config_path.read_text(encoding="utf-8")
        )
        source_privacy_summary = {
            "secret_commitment": source_privacy_config.get("secret_commitment"),
            "image": source_privacy_config.get("image"),
            "text": source_privacy_config.get("text"),
        }
    atomic_write_json(output_root / "privacy_config.json", {
        "schema_version": 1,
        "source_private_manifest_sha256": file_sha256(source_manifest_path),
        "source_privacy_config_sha256": source_privacy_config_sha256,
        "source_privacy_summary": source_privacy_summary,
        "image_postprocessing": config,
        "selection_boundary": "Choose the fixed preset on validation only; test is final-use only.",
        "privacy_boundary": (
            "This derived release reads only already-private images and public private-pair "
            "metadata. It does not read original SMID content and does not spend additional epsilon."
        ),
    })
    audit = {
        "schema_version": 1,
        "status": "complete",
        "preset": preset,
        "postprocessing": config,
        "selected_splits": list(splits),
        "pair_count": len(selected),
        "unique_image_count": len(images),
        "source_private_manifest_sha256": file_sha256(source_manifest_path),
        "private_pairs_sha256": manifest["private_pairs_sha256"],
        "images": image_audit,
    }
    atomic_write_json(output_root / "postprocess_audit.json", audit)
    print(json.dumps({key: value for key, value in audit.items() if key != "images"},
                     ensure_ascii=False, indent=2))
    print("Post-processed private dataset: {}".format(output_root))
    return audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--preset", choices=sorted(PRESETS), required=True)
    parser.add_argument("--splits", nargs="+", choices=VALID_SPLITS, default=["validation"])
    args = parser.parse_args()
    postprocess_dataset(args.source_root, args.output_root, args.preset, tuple(args.splits))


if __name__ == "__main__":
    main()
