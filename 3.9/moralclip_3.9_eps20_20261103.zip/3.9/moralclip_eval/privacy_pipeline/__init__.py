"""Auditable LDP-Slicing + CluSanT data-release pipeline."""

from .manifest_schema import load_smid_pairs

__all__ = ["load_smid_pairs"]
