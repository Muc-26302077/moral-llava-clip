"""Privacy-safe image post-processing for already sanitized images.

Every transform in this module consumes only the output of LDP-Slicing.  It
must never inspect an original image, a paired original caption, or a test-set
metric while choosing parameters.  Therefore a fixed transform is ordinary
post-processing of a differentially private release; parameter selection still
has to be performed on the validation split only.
"""

from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

from .manifest_schema import file_sha256


PRESETS = {
    "identity": {"method": "identity"},
    "median3": {"method": "median", "size": 3},
    "median5": {"method": "median", "size": 5},
    "gaussian05": {"method": "gaussian", "radius": 0.5},
    "gaussian10": {"method": "gaussian", "radius": 1.0},
    "median3_unsharp": {
        "method": "median_unsharp",
        "size": 3,
        "radius": 1.0,
        "percent": 75,
        "threshold": 3,
    },
    "wavelet03": {
        "method": "wavelet_soft",
        "wavelet": "db2",
        "level": 2,
        "strength": 0.3,
    },
    "wavelet06": {
        "method": "wavelet_soft",
        "wavelet": "db2",
        "level": 2,
        "strength": 0.6,
    },
}


def resolve_postprocess_config(config=None):
    """Return and validate a normalized post-processing configuration."""
    if config is None:
        prepared = {"method": "identity"}
    elif isinstance(config, str):
        if config not in PRESETS:
            raise ValueError("Unknown image post-processing preset: {}".format(config))
        prepared = dict(PRESETS[config])
        prepared["preset"] = config
    elif isinstance(config, dict):
        if "preset" in config:
            preset = config["preset"]
            if preset not in PRESETS:
                raise ValueError("Unknown image post-processing preset: {}".format(preset))
            prepared = dict(PRESETS[preset])
            prepared.update({key: value for key, value in config.items() if key != "preset"})
            prepared["preset"] = preset
        else:
            prepared = dict(config)
    else:
        raise TypeError("image post-processing config must be a preset name or object")

    method = prepared.get("method", "identity")
    allowed = {"identity", "median", "gaussian", "median_unsharp", "wavelet_soft"}
    if method not in allowed:
        raise ValueError("Unknown image post-processing method: {}".format(method))
    prepared["method"] = method
    if method in {"median", "median_unsharp"}:
        size = int(prepared.get("size", 3))
        if size < 3 or size % 2 == 0:
            raise ValueError("median filter size must be an odd integer >= 3")
        prepared["size"] = size
    if method in {"gaussian", "median_unsharp"}:
        radius = float(prepared.get("radius", 1.0))
        if radius < 0:
            raise ValueError("filter radius must be non-negative")
        prepared["radius"] = radius
    if method == "median_unsharp":
        prepared["percent"] = int(prepared.get("percent", 75))
        prepared["threshold"] = int(prepared.get("threshold", 3))
        if prepared["percent"] < 0 or prepared["threshold"] < 0:
            raise ValueError("unsharp percent and threshold must be non-negative")
    if method == "wavelet_soft":
        prepared["wavelet"] = str(prepared.get("wavelet", "db2"))
        prepared["level"] = int(prepared.get("level", 2))
        prepared["strength"] = float(prepared.get("strength", 0.3))
        if prepared["level"] < 1 or prepared["strength"] < 0:
            raise ValueError("wavelet level must be >= 1 and strength must be non-negative")
    return prepared


def _wavelet_soft(image, config):
    try:
        import pywt
    except ImportError as exc:
        raise RuntimeError(
            "wavelet_soft requires PyWavelets from requirements_privacy.txt"
        ) from exc
    array = np.asarray(image, dtype=np.float32)
    output = np.empty_like(array)
    for channel in range(array.shape[2]):
        values = array[:, :, channel]
        maximum_level = pywt.dwtn_max_level(values.shape, config["wavelet"])
        level = min(config["level"], maximum_level)
        if level < 1:
            output[:, :, channel] = values
            continue
        coefficients = pywt.wavedec2(
            values, wavelet=config["wavelet"], level=level, mode="periodization"
        )
        finest_diagonal = coefficients[-1][2]
        sigma = float(np.median(np.abs(finest_diagonal))) / 0.67448975
        threshold = config["strength"] * sigma * np.sqrt(2.0 * np.log(values.size))
        filtered = [coefficients[0]]
        filtered.extend(
            tuple(pywt.threshold(detail, threshold, mode="soft") for detail in band)
            for band in coefficients[1:]
        )
        restored = pywt.waverec2(
            filtered, wavelet=config["wavelet"], mode="periodization"
        )
        output[:, :, channel] = restored[: values.shape[0], : values.shape[1]]
    return Image.fromarray(np.rint(np.clip(output, 0, 255)).astype(np.uint8), mode="RGB")


def apply_private_image_postprocessing(image, config=None):
    """Apply a validated transform to an already-private RGB image."""
    prepared = resolve_postprocess_config(config)
    image = image.convert("RGB")
    method = prepared["method"]
    if method == "identity":
        return image.copy()
    if method == "median":
        return image.filter(ImageFilter.MedianFilter(size=prepared["size"]))
    if method == "gaussian":
        return image.filter(ImageFilter.GaussianBlur(radius=prepared["radius"]))
    if method == "median_unsharp":
        denoised = image.filter(ImageFilter.MedianFilter(size=prepared["size"]))
        return denoised.filter(ImageFilter.UnsharpMask(
            radius=prepared["radius"], percent=prepared["percent"],
            threshold=prepared["threshold"],
        ))
    if method == "wavelet_soft":
        return _wavelet_soft(image, prepared)
    raise AssertionError("validated method was not dispatched")


def postprocess_private_file(input_path, output_path, config=None):
    """Transform one private PNG and return auditable output metadata."""
    input_path = Path(input_path)
    output_path = Path(output_path)
    prepared = resolve_postprocess_config(config)
    with Image.open(str(input_path)) as image:
        private = apply_private_image_postprocessing(image, prepared)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    private.save(str(output_path), format="PNG", optimize=False)
    return {
        "postprocessing": prepared,
        "input_private_image_sha256": file_sha256(input_path),
        "private_image_sha256": file_sha256(output_path),
        "width": private.width,
        "height": private.height,
    }
