"""Privacy attack utilities for MoralCLIP evaluations."""

