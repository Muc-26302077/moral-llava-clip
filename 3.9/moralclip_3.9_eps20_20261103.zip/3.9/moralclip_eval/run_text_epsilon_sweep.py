"""Run a reproducible CluSanT text-epsilon smoke sweep on the real SMID data."""

import argparse
import csv
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def epsilon_slug(value):
    return ("{:g}".format(float(value))).replace("-", "m").replace(".", "p")


def run_logged(command, log_path):
    print("\nRunning: {}".format(" ".join(str(value) for value in command)), flush=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    with log_path.open("w", encoding="utf-8", newline="\n") as stream:
        process = subprocess.Popen(
            [str(value) for value in command], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            stream.write(line)
            stream.flush()
            lines.append(line.rstrip("\n"))
        return_code = process.wait()
    if return_code:
        raise RuntimeError(
            "Command failed with exit code {}. See {}".format(return_code, log_path)
        )
    return lines


def make_config(base_config_path, cfg, epsilon, private_root, evaluation_root, path,
                selected_split=None, image_epsilon=None):
    base = base_config_path.parent
    prepared = json.loads(json.dumps(cfg))
    prepared["dataset_root"] = str(resolve(prepared["dataset_root"], base))
    prepared["model_dir"] = str(resolve(prepared["model_dir"], base))
    prepared["output_dir"] = str(private_root.resolve())
    if selected_split is not None:
        prepared["splits"] = [selected_split]
    if image_epsilon is not None:
        prepared["image_privacy"]["epsilon"] = float(image_epsilon)
    text_cfg = prepared["text_privacy"]
    text_cfg["epsilon"] = float(epsilon)
    if "embedding_model" in text_cfg:
        text_cfg["embedding_model"] = str(resolve(text_cfg["embedding_model"], base))
    if "public_vocab_path" in text_cfg:
        text_cfg["public_vocab_path"] = str(resolve(text_cfg["public_vocab_path"], base))
    prepared["evaluation"]["output_dir"] = str(evaluation_root.resolve())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(prepared, ensure_ascii=False, indent=2), encoding="utf-8")


def result_path_from_output(lines):
    for line in reversed(lines):
        if line.startswith("Results: "):
            return Path(line.split("Results: ", 1)[1].strip()).resolve()
    raise RuntimeError("Evaluator completed without reporting its Results directory")


def summarize(report_path, epsilon, private_root):
    report = json.loads(report_path.read_text(encoding="utf-8"))
    audit = json.loads((private_root / "privacy_audit.json").read_text(encoding="utf-8"))
    privacy_config = json.loads(
        (private_root / "privacy_config.json").read_text(encoding="utf-8")
    )
    if len(report["splits"]) != 1:
        raise ValueError("Sweep expects exactly one evaluation split")
    split, values = next(iter(report["splits"].items()))
    preservation = values["value_preservation"]
    utility = values["semantic_utility_gate"]
    conclusion = values["conclusion"]
    generated_pairs = int(audit["generated_pairs"])
    changed_pairs = int(audit["pairs_with_at_least_one_changed_token"])
    return {
        "epsilon_image": float(privacy_config["config"]["image_privacy"]["epsilon"]),
        "epsilon_text": float(epsilon),
        "split": split,
        "images": values["counts"]["images"],
        "pairs": values["counts"]["pairs"],
        "protected_token_coverage_percent": audit[
            "text_protected_coverage_percent_mean"
        ],
        "pairs_with_changed_text": changed_pairs,
        "changed_text_pair_percent": float(100.0 * changed_pairs / generated_pairs),
        "joint_value_preservation_percent": preservation[
            "joint_value_profile_preservation_percent"
        ],
        "joint_value_ci95_low": preservation["bootstrap"]["ci95_low"],
        "joint_value_ci95_high": preservation["bootstrap"]["ci95_high"],
        "image_value_preservation_percent": preservation[
            "image_value_profile_preservation_percent"
        ],
        "text_value_preservation_percent": preservation[
            "text_value_profile_preservation_percent"
        ],
        "cross_modal_relation_preservation_percent": preservation[
            "cross_modal_relation_preservation_percent"
        ],
        "image_to_text_R1_retention_percent": utility[
            "image_to_text_R1_retention_percent"
        ],
        "text_to_image_R1_retention_percent": utility[
            "text_to_image_R1_retention_percent"
        ],
        "joint_R1_retention_percent": utility["joint_R1_retention_percent"],
        "value_preservation_pass": conclusion["value_preservation_pass"],
        "semantic_utility_pass": conclusion["semantic_utility_pass"],
        "strict_pass": conclusion["strict_pass"],
        "private_root": str(private_root),
        "report_path": str(report_path),
    }


def write_outputs(root, rows, arguments):
    payload = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "experiment": (
            "CluSanT text epsilon smoke sweep with fixed LDP-Slicing image configuration"
        ),
        "selection_rule": (
            "Prefer the smallest epsilon whose bounded joint value preservation point and "
            "cluster-bootstrap lower CI exceed the target and whose joint R@1 utility gate passes."
        ),
        "arguments": arguments,
        "runs": rows,
    }
    (root / "summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (root / "summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    notes = [
        "# Text epsilon sweep notes",
        "",
        payload["experiment"],
        "",
        "Selection rule: " + payload["selection_rule"],
        "",
    ]
    for row in rows:
        notes.extend([
            "## epsilon_image={:g}, epsilon_text={:g}".format(
                row["epsilon_image"], row["epsilon_text"]
            ),
            "",
            "Joint value preservation: {:.4f}% (95% CI {:.4f}–{:.4f}%).".format(
                row["joint_value_preservation_percent"], row["joint_value_ci95_low"],
                row["joint_value_ci95_high"],
            ),
            "Joint R@1 utility retention: {:.4f}%. Strict pass: {}.".format(
                row["joint_R1_retention_percent"], row["strict_pass"]
            ),
            "Pairs with changed text: {}/{} ({:.4f}%).".format(
                row["pairs_with_changed_text"], row["pairs"],
                row["changed_text_pair_percent"],
            ),
            "",
        ])
    (root / "notes.txt").write_text("\n".join(notes), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-config", default=str(Path(__file__).with_name("privacy_pair_config.json")))
    parser.add_argument("--epsilons", nargs="+", type=float, default=[8.0, 12.0, 20.0, 40.0])
    parser.add_argument(
        "--image-epsilon", type=float,
        help="Override the fixed LDP-Slicing image epsilon with a supported official budget.",
    )
    parser.add_argument("--max-images-per-split", type=int, default=10)
    parser.add_argument("--split", choices=["train", "validation", "test"], default="validation")
    parser.add_argument("--work-root", default="../privacy_epsilon_sweep")
    args = parser.parse_args()

    base_config_path = Path(args.base_config).resolve()
    cfg = json.loads(base_config_path.read_text(encoding="utf-8-sig"))
    work_root = resolve(args.work_root, base_config_path.parent)
    work_root.mkdir(parents=True, exist_ok=True)
    script_root = Path(__file__).resolve().parent
    rows = []
    for epsilon in args.epsilons:
        slug = epsilon_slug(epsilon)
        run_root = work_root / ("epsilon_" + slug)
        private_root = run_root / "private_dataset"
        evaluation_root = run_root / "evaluation_results"
        config_path = work_root / "configs" / ("epsilon_" + slug + ".json")
        make_config(
            base_config_path, cfg, epsilon, private_root, evaluation_root, config_path,
            selected_split=args.split,
            image_epsilon=args.image_epsilon,
        )
        print(
            "\n=== epsilon_image={}, epsilon_text={:g}: generate/validate/evaluate {} real images per split ===".format(
                args.image_epsilon if args.image_epsilon is not None else "config-default",
                epsilon, args.max_images_per_split
            ), flush=True,
        )
        generate_command = [
            sys.executable, str(script_root / "generate_private_pairs.py"),
            "--config", str(config_path),
            "--max-images-per-split", str(args.max_images_per_split),
        ]
        if private_root.exists():
            generate_command.append("--resume")
        run_logged(generate_command, run_root / "generate.log")
        run_logged([
            sys.executable, str(script_root / "validate_private_dataset.py"),
            "--config", str(config_path), "--private-root", str(private_root),
            "--max-images-per-split", str(args.max_images_per_split),
            "--out", str(run_root / "validation_report.json"),
        ], run_root / "validate.log")
        evaluation_lines = run_logged([
            sys.executable, str(script_root / "evaluate_private_pairs.py"),
            "--config", str(config_path), "--private-root", str(private_root),
            "--splits", args.split,
            "--max-images-per-split", str(args.max_images_per_split),
        ], run_root / "evaluate.log")
        result_root = result_path_from_output(evaluation_lines)
        rows.append(summarize(result_root / "report.json", epsilon, private_root))
        write_outputs(work_root, rows, vars(args))

    run_logged([
        sys.executable, str(script_root / "plot_privacy_sweep.py"),
        "--summary", str(work_root / "summary.json"), "--output-dir", str(work_root),
    ], work_root / "plot.log")
    print("\nSweep summary: {}".format(work_root / "summary.json"))


if __name__ == "__main__":
    main()
