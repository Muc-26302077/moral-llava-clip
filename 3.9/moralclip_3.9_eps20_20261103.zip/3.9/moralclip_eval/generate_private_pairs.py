"""Generate one LDP-Slicing + CluSanT pair for every original SMID pair."""

import argparse
import json
import platform
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from privacy_pipeline.clusant_text_adapter import (
    CluSanTMechanism,
    build_embedding_backend,
    build_or_load_assets,
)
from privacy_pipeline.ldp_image_adapter import LdpSlicingSanitizer
from privacy_pipeline.manifest_schema import (
    VALID_SPLITS,
    atomic_write_json,
    canonical_sha256,
    file_sha256,
    is_within,
    load_secret,
    load_smid_pairs,
    secret_commitment,
)
from privacy_pipeline.progress import ProgressBar


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def read_jsonl(path, key):
    rows = {}
    if not Path(path).is_file():
        return rows
    with Path(path).open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            value = row.get(key)
            if not isinstance(value, str) or value in rows:
                raise ValueError("Invalid/duplicate {} at {}:{}".format(key, path, line_number))
            rows[value] = row
    return rows


def append_jsonl(path, row):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()


def public_config(cfg):
    cleaned = json.loads(json.dumps(cfg))
    cleaned.pop("secret", None)
    return cleaned


def build_split_manifests(public_pairs, output_dir):
    grouped = defaultdict(lambda: defaultdict(list))
    metadata = {}
    for row in public_pairs:
        key = (row["split"], row["anonymous_image_id"])
        grouped[row["split"]][row["anonymous_image_id"]].append(row)
        metadata[key] = row
    for split, images in grouped.items():
        manifest = []
        for image_id, rows in sorted(images.items()):
            rows.sort(key=lambda value: value["caption_index"])
            first = metadata[(split, image_id)]
            manifest.append({
                "id": first["anonymous_image_id"],
                "source_dataset": "smid_private_ldpslicing_clusant",
                "split": split,
                "image_path": first["private_image_path"],
                "captions": [row["private_caption"] for row in rows],
                "caption": rows[0]["private_caption"],
                "moral_labels": first["moral_labels"],
                "source_image_id_hash": first["anonymous_image_id"],
            })
        atomic_write_json(output_dir / split / "smid_manifest.json", manifest)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(Path(__file__).with_name("privacy_pair_config.json")))
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-images-per-split", type=int)
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--output-dir", help="Override config output_dir (useful for smoke runs)")
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8-sig"))
    base = config_path.parent
    dataset_root = resolve(cfg["dataset_root"], base)
    if args.output_dir:
        cfg["output_dir"] = args.output_dir
    output_dir = resolve(cfg["output_dir"], base)
    if output_dir == dataset_root or is_within(output_dir, dataset_root):
        raise ValueError("output_dir must be outside the original dataset root")
    splits = tuple(cfg.get("splits", VALID_SPLITS))
    bundle = load_smid_pairs(
        dataset_root, splits=splits, max_images_per_split=args.max_images_per_split
    )
    counts = {
        "images": sum(item["unique_images"] for item in bundle["stats"].values()),
        "pairs": sum(item["pairs"] for item in bundle["stats"].values()),
        "splits": bundle["stats"],
        "pairs_sha256": bundle["pairs_sha256"],
    }
    print("This run is meant to create exactly one private image/text pair per original pair.")
    print(json.dumps(counts, ensure_ascii=False, indent=2))
    if args.plan_only:
        print("Plan-only validation succeeded; no private data was generated.")
        return

    secret_env = cfg.get("secret_env", "PRIVACY_RELEASE_SEED")
    secret = load_secret(secret_env)
    commitment = secret_commitment(secret)
    cfg_public = public_config(cfg)
    run_fingerprint = canonical_sha256({
        "config": cfg_public,
        "pairs_sha256": bundle["pairs_sha256"],
        "secret_commitment": commitment,
        "max_images_per_split": args.max_images_per_split,
    })
    state_path = output_dir / "run_state.json"
    if output_dir.exists() and not args.resume:
        raise FileExistsError(
            "Output already exists; use a new output_dir or --resume: {}".format(output_dir)
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    if state_path.is_file():
        old_state = json.loads(state_path.read_text(encoding="utf-8"))
        if old_state.get("run_fingerprint") != run_fingerprint:
            raise ValueError("Cannot resume: config, source manifest, sample limit or secret changed")
    state = {
        "schema_version": 1,
        "status": "running",
        "started_or_resumed_utc": datetime.now(timezone.utc).isoformat(),
        "run_fingerprint": run_fingerprint,
        "secret_commitment": commitment,
        "counts_expected": counts,
        "note": "The secret itself is never stored. Do not publish internal/.",
    }
    atomic_write_json(state_path, state)

    image_sanitizer = LdpSlicingSanitizer(cfg["image_privacy"], secret)
    text_cfg = dict(cfg["text_privacy"])
    if "public_vocab_path" not in text_cfg:
        text_cfg["public_vocab_path"] = str(resolve(cfg["model_dir"], base) / "vocab.json")
    backend = build_embedding_backend(text_cfg, base)
    words, embeddings, labels, asset_metadata = build_or_load_assets(
        text_cfg, base, output_dir, backend=backend
    )
    text_sanitizer = CluSanTMechanism(
        words, embeddings, labels,
        epsilon=float(text_cfg["epsilon"]),
        centroid_scale=float(text_cfg.get("centroid_scale", 1.0)),
        selection_policy=text_cfg.get("selection_policy", "all_words"),
        min_token_length=int(text_cfg.get("min_token_length", 2)),
    )

    image_checkpoint = output_dir / "internal" / "image_records.jsonl"
    text_checkpoint = output_dir / "internal" / "pair_records.jsonl"
    completed_images = read_jsonl(image_checkpoint, "image_key")
    completed_pairs = read_jsonl(text_checkpoint, "pair_id")

    unique_images = {}
    for row in bundle["pairs"]:
        image_key = "{}:{}".format(row["split"], row["image_id"])
        unique_images.setdefault(image_key, row)
    image_progress = ProgressBar(
        "Private images", len(unique_images), initial=len(completed_images)
    )
    for image_key, row in unique_images.items():
        if image_key in completed_images:
            private_abs = output_dir / completed_images[image_key]["private_image_path"]
            if not private_abs.is_file() or file_sha256(private_abs) != completed_images[image_key]["private_image_sha256"]:
                raise ValueError("Resume image checksum mismatch: {}".format(image_key))
            continue
        private_rel = "{}/images/{}.png".format(row["split"], row["anonymous_image_id"])
        private_abs = output_dir / private_rel
        result = image_sanitizer.sanitize_file(
            row["original_image_abs"], private_abs, row["anonymous_image_id"]
        )
        checkpoint_row = {
            "image_key": image_key,
            "anonymous_image_id": row["anonymous_image_id"],
            "split": row["split"],
            "private_image_path": private_rel,
            **result,
        }
        append_jsonl(image_checkpoint, checkpoint_row)
        completed_images[image_key] = checkpoint_row
        image_progress.update(len(completed_images))

    text_progress = ProgressBar(
        "Private captions", len(bundle["pairs"]), initial=len(completed_pairs)
    )
    for row in bundle["pairs"]:
        if row["pair_id"] in completed_pairs:
            continue
        private_text, text_audit = text_sanitizer.sanitize(
            row["original_caption"], secret, row["pair_id"]
        )
        checkpoint_row = {
            "pair_id": row["pair_id"],
            "private_caption": private_text,
            "text_audit": text_audit,
        }
        append_jsonl(text_checkpoint, checkpoint_row)
        completed_pairs[row["pair_id"]] = checkpoint_row
        text_progress.update(len(completed_pairs))

    public_pairs = []
    for row in bundle["pairs"]:
        image_key = "{}:{}".format(row["split"], row["image_id"])
        image_row = completed_images[image_key]
        text_row = completed_pairs[row["pair_id"]]
        public_pairs.append({
            "pair_id": row["pair_id"],
            "split": row["split"],
            "anonymous_image_id": row["anonymous_image_id"],
            "caption_index": row["caption_index"],
            "private_image_path": image_row["private_image_path"],
            "private_caption": text_row["private_caption"],
            "moral_labels": row["moral_labels"],
            "privacy": {
                "image_mechanism": "LDP-Slicing",
                "epsilon_image": image_sanitizer.total_epsilon,
                "text_mechanism": "CluSanT-adapted",
                "epsilon_text": text_sanitizer.epsilon,
                **text_row["text_audit"],
            },
        })
    manifest = {
        "schema_version": 1,
        "kind": "smid_private_ldpslicing_clusant",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "pairs_sha256_source": bundle["pairs_sha256"],
        "pair_count": len(public_pairs),
        "unique_image_count": len(unique_images),
        "pairs": public_pairs,
    }
    manifest["private_pairs_sha256"] = canonical_sha256(public_pairs)
    atomic_write_json(output_dir / "pair_manifest.json", manifest)
    build_split_manifests(public_pairs, output_dir)

    coverage = [row["privacy"]["protected_coverage_percent"] for row in public_pairs]
    protected = [row["privacy"]["protected_token_count"] for row in public_pairs]
    changed = [row["privacy"]["changed_token_count"] for row in public_pairs]
    zero_protected = int(np.sum(np.asarray(protected) <= 0))
    if text_cfg.get("require_at_least_one_protected_token_per_pair", True) and zero_protected:
        raise RuntimeError(
            "{} captions contain no protected token; expand the public vocabulary before release".format(
                zero_protected
            )
        )
    privacy_config = {
        "schema_version": 1,
        "config": cfg_public,
        "run_fingerprint": run_fingerprint,
        "secret_commitment": commitment,
        "image": image_sanitizer.metadata(),
        "text": text_sanitizer.metadata(),
        "clusant_assets": asset_metadata,
        "privacy_boundary": (
            "Image and selected text tokens have separate modality-specific local privacy "
            "definitions. No unified image-text record epsilon is claimed."
        ),
    }
    atomic_write_json(output_dir / "privacy_config.json", privacy_config)
    audit = {
        "schema_version": 1,
        "status": "complete",
        "counts": counts,
        "generated_unique_images": len(completed_images),
        "generated_pairs": len(completed_pairs),
        "private_pairs_sha256": manifest["private_pairs_sha256"],
        "text_protected_coverage_percent_mean": float(np.mean(coverage)),
        "pairs_with_at_least_one_protected_token": int(np.sum(np.asarray(protected) > 0)),
        "pairs_without_protected_tokens": zero_protected,
        "pairs_with_at_least_one_changed_token": int(np.sum(np.asarray(changed) > 0)),
        "source_manifests": bundle["sources"],
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
        },
    }
    atomic_write_json(output_dir / "privacy_audit.json", audit)
    state.update({
        "status": "complete",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "private_pairs_sha256": manifest["private_pairs_sha256"],
    })
    atomic_write_json(state_path, state)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print("Private dataset: {}".format(output_dir))


if __name__ == "__main__":
    main()
