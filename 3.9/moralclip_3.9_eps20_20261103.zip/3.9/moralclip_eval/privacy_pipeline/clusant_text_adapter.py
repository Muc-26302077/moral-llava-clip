"""CluSanT text sanitization adapted for SMID captions.

Upstream: https://github.com/AwonSomeSauce/CluSanT
Pinned during adaptation: 07c73be6fa32784e222d8d3be3381733c15a7b87

The two-stage cluster/word exponential mechanism follows the upstream code.
This adapter replaces TAB-specific LOC/ORG annotations with an explicit token
policy and a public CLIP-tokenizer vocabulary, adds deterministic asset building,
stable secret-derived sampling, numeric stability and auditable coverage.
"""

import hashlib
import json
import re
from pathlib import Path

import numpy as np
from scipy.spatial.distance import cdist, pdist

from .manifest_schema import canonical_sha256, derive_seed, file_sha256


TOKEN_PATTERN = re.compile(r"[A-Za-z]+(?:['’\-][A-Za-z]+)*")
CONTENT_STOPWORDS = frozenset(
    "a an and are as at be been being but by for from had has have he her hers him his "
    "i in into is it its of on or our ours she that the their theirs them they this those "
    "to was we were will with you your yours showing shows shown image photo picture scene "
    "there here".split()
)


def _normalize_rows(values):
    values = np.asarray(values, dtype=np.float32)
    norms = np.linalg.norm(values, axis=1, keepdims=True)
    if np.any(norms <= 0):
        raise ValueError("Embedding backend returned a zero vector")
    return values / norms


def load_public_clip_vocabulary(vocab_path, min_length=2, max_words=30000):
    """Build a public, data-independent substitute vocabulary from CLIP BPE."""
    raw = json.loads(Path(vocab_path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("CLIP vocab.json must be a JSON object")
    ordered = sorted(raw.items(), key=lambda item: int(item[1]))
    words = []
    seen = set()
    for token, _ in ordered:
        if not token.endswith("</w>"):
            continue
        word = token[:-4].lower()
        if len(word) < int(min_length) or not re.fullmatch(r"[a-z]+(?:['-][a-z]+)*", word):
            continue
        if word not in seen:
            words.append(word)
            seen.add(word)
        if max_words and len(words) >= int(max_words):
            break
    if len(words) < 100:
        raise ValueError("Too few public candidate words extracted: {}".format(len(words)))
    return words


class SentenceTransformerEmbeddingBackend:
    def __init__(self, model_name_or_path, device="auto", batch_size=256):
        try:
            import torch
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "sentence-transformers is required for the formal CluSanT configuration"
            ) from exc
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = SentenceTransformer(model_name_or_path, device=device)
        self.model_name_or_path = str(model_name_or_path)
        self.device = device
        self.batch_size = int(batch_size)

    def encode(self, words):
        values = self.model.encode(
            list(words), batch_size=self.batch_size, show_progress_bar=len(words) > 1000,
            convert_to_numpy=True, normalize_embeddings=True,
        )
        return _normalize_rows(values)

    def metadata(self):
        return {
            "backend": "sentence_transformers",
            "model": self.model_name_or_path,
            "device": self.device,
        }


class MoralClipEmbeddingBackend:
    """Offline integration backend for pipeline smoke tests and ablation only."""
    def __init__(self, model_dir, device="auto", batch_size=256, local_files_only=True):
        try:
            import torch
            from transformers import CLIPModel, CLIPProcessor
        except ImportError as exc:
            raise RuntimeError("A transformers version with CLIPModel is required") from exc
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.torch = torch
        self.model = CLIPModel.from_pretrained(
            str(model_dir), local_files_only=bool(local_files_only)
        ).to(device).eval()
        self.processor = CLIPProcessor.from_pretrained(
            str(model_dir), local_files_only=bool(local_files_only), use_fast=False
        )
        self.model_dir = str(Path(model_dir).resolve())
        self.device = device
        self.batch_size = int(batch_size)

    def encode(self, words):
        results = []
        with self.torch.inference_mode():
            for start in range(0, len(words), self.batch_size):
                inputs = self.processor(
                    text=list(words[start:start + self.batch_size]), return_tensors="pt",
                    padding=True, truncation=True,
                ).to(self.device)
                values = self.model.get_text_features(**inputs)
                if not isinstance(values, self.torch.Tensor):
                    values = values.pooler_output
                values = self.torch.nn.functional.normalize(values.float(), dim=-1)
                results.append(values.cpu().numpy())
        return _normalize_rows(np.concatenate(results, axis=0))

    def metadata(self):
        return {
            "backend": "moralclip_ablation",
            "model": self.model_dir,
            "device": self.device,
            "warning": "Ablation/smoke backend; formal experiment should use all-mpnet-base-v2.",
        }


def build_embedding_backend(config, base_dir):
    name = config.get("embedding_backend", "sentence_transformers")
    device = config.get("device", "auto")
    batch_size = int(config.get("embedding_batch_size", 256))
    if name == "sentence_transformers":
        model = config.get("embedding_model", "sentence-transformers/all-mpnet-base-v2")
        candidate = Path(model).expanduser()
        if not candidate.is_absolute() and (base_dir / candidate).exists():
            model = str((base_dir / candidate).resolve())
        return SentenceTransformerEmbeddingBackend(model, device=device, batch_size=batch_size)
    if name == "moralclip":
        model_dir = Path(config["embedding_model"])
        if not model_dir.is_absolute():
            model_dir = (base_dir / model_dir).resolve()
        return MoralClipEmbeddingBackend(
            model_dir, device=device, batch_size=batch_size,
            local_files_only=config.get("local_files_only", True),
        )
    raise ValueError("Unknown text embedding backend: {}".format(name))


def build_or_load_assets(config, base_dir, output_dir, backend=None):
    """Build clusters only from a public tokenizer vocabulary."""
    vocab_path = Path(config["public_vocab_path"])
    if not vocab_path.is_absolute():
        vocab_path = (base_dir / vocab_path).resolve()
    words = load_public_clip_vocabulary(
        vocab_path,
        min_length=config.get("min_token_length", 2),
        max_words=config.get("max_public_vocabulary", 30000),
    )
    fingerprint = {
        "vocab_sha256": file_sha256(vocab_path),
        "candidate_count": len(words),
        "candidate_sha256": canonical_sha256(words),
        "embedding_backend": config.get("embedding_backend", "sentence_transformers"),
        "embedding_model": config.get("embedding_model", "sentence-transformers/all-mpnet-base-v2"),
        "num_clusters": int(config.get("num_clusters", 180)),
        "cluster_seed": int(config.get("cluster_seed", 2026)),
    }
    asset_id = canonical_sha256(fingerprint)[:16]
    output_dir = Path(output_dir)
    asset_path = output_dir / "internal" / "clusant_assets_{}.npz".format(asset_id)
    metadata_path = output_dir / "internal" / "clusant_assets_{}.json".format(asset_id)
    if asset_path.is_file() and metadata_path.is_file():
        payload = np.load(str(asset_path), allow_pickle=False)
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata.get("fingerprint") != fingerprint:
            raise ValueError("Cached CluSanT asset fingerprint mismatch")
        return payload["words"].tolist(), payload["embeddings"], payload["labels"], metadata

    backend = backend or build_embedding_backend(config, base_dir)
    print("Building CluSanT public assets: {} words".format(len(words)))
    embeddings = backend.encode(words).astype(np.float32)
    num_clusters = int(config.get("num_clusters", 180))
    if not 1 <= num_clusters <= len(words) // 2:
        raise ValueError("num_clusters must leave at least two candidates per cluster on average")
    from sklearn.cluster import MiniBatchKMeans
    clusterer = MiniBatchKMeans(
        n_clusters=num_clusters,
        random_state=int(config.get("cluster_seed", 2026)),
        batch_size=int(config.get("cluster_batch_size", 2048)),
        n_init=int(config.get("cluster_n_init", 3)),
        max_iter=int(config.get("cluster_max_iter", 100)),
    )
    labels = clusterer.fit_predict(embeddings).astype(np.int32)
    counts = np.bincount(labels, minlength=num_clusters)
    if np.any(counts == 0):
        raise RuntimeError("CluSanT clustering created an empty cluster")
    asset_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        str(asset_path), words=np.asarray(words, dtype=str), embeddings=embeddings, labels=labels
    )
    metadata = {
        "schema_version": 1,
        "kind": "clusant_public_substitute_assets",
        "fingerprint": fingerprint,
        "asset_id": asset_id,
        "asset_sha256": file_sha256(asset_path),
        "embedding": backend.metadata(),
        "cluster_size_min": int(counts.min()),
        "cluster_size_max": int(counts.max()),
        "cluster_size_mean": float(counts.mean()),
        "release_warning": "Internal mechanism asset; do not publish with a private dataset release.",
    }
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return words, embeddings, labels, metadata


class CluSanTMechanism:
    def __init__(self, words, embeddings, labels, epsilon=8.0, centroid_scale=1.0,
                 selection_policy="all_words", min_token_length=2):
        self.words = np.asarray(words, dtype=str)
        self.embeddings = _normalize_rows(embeddings)
        self.labels = np.asarray(labels, dtype=np.int32)
        if len(self.words) != len(self.embeddings) or len(self.words) != len(self.labels):
            raise ValueError("CluSanT asset arrays have inconsistent lengths")
        if len(set(self.words.tolist())) != len(self.words):
            raise ValueError("CluSanT candidate vocabulary contains duplicates")
        self.epsilon = float(epsilon)
        if self.epsilon <= 0:
            raise ValueError("epsilon_text must be positive")
        self.selection_policy = selection_policy
        if selection_policy not in ("all_words", "content_words"):
            raise ValueError("selection_policy must be all_words or content_words")
        self.min_token_length = int(min_token_length)
        self.word_to_index = {word: index for index, word in enumerate(self.words.tolist())}
        self.cluster_ids = np.asarray(sorted(set(self.labels.tolist())), dtype=np.int32)
        if not np.array_equal(self.cluster_ids, np.arange(len(self.cluster_ids))):
            raise ValueError("Cluster labels must be contiguous from zero")
        self.cluster_indices = [np.flatnonzero(self.labels == cluster) for cluster in self.cluster_ids]
        self.centroids = np.stack([
            float(centroid_scale) * self.embeddings[indices].mean(axis=0)
            for indices in self.cluster_indices
        ])
        self.inter_distances = cdist(self.centroids, self.centroids, metric="euclidean")
        self.intra_sensitivities = []
        for indices in self.cluster_indices:
            values = self.embeddings[indices]
            sensitivity = float(np.max(pdist(values, metric="euclidean"))) if len(values) > 1 else 0.0
            self.intra_sensitivities.append(sensitivity)

    @staticmethod
    def _probabilities(utilities, epsilon, sensitivity):
        utilities = np.asarray(utilities, dtype=np.float64)
        if not np.all(np.isfinite(utilities)):
            raise ValueError("Non-finite CluSanT utility")
        if sensitivity <= np.finfo(np.float64).eps:
            return np.full(len(utilities), 1.0 / len(utilities), dtype=np.float64)
        logits = float(epsilon) * utilities / (2.0 * float(sensitivity))
        logits -= logits.max()
        probabilities = np.exp(logits)
        probabilities /= probabilities.sum()
        return probabilities

    def _eligible(self, word):
        if len(word) < self.min_token_length:
            return False
        if self.selection_policy == "content_words" and word in CONTENT_STOPWORDS:
            return False
        return True

    def replace_word(self, word, rng):
        index = self.word_to_index.get(word)
        if index is None:
            return None
        target_cluster = int(self.labels[index])
        if len(self.cluster_ids) == 1:
            selected_cluster = target_cluster
        else:
            utilities = -self.inter_distances[target_cluster]
            probabilities = self._probabilities(utilities, self.epsilon, 1.0)
            selected_cluster = int(rng.choice(self.cluster_ids, p=probabilities))
        candidate_indices = self.cluster_indices[selected_cluster]
        distances = cdist(
            self.embeddings[index:index + 1], self.embeddings[candidate_indices], metric="euclidean"
        )[0]
        probabilities = self._probabilities(
            -distances, self.epsilon, self.intra_sensitivities[selected_cluster]
        )
        selected_index = int(rng.choice(candidate_indices, p=probabilities))
        return str(self.words[selected_index])

    @staticmethod
    def _restore_case(original, replacement):
        if original.isupper():
            return replacement.upper()
        if original[:1].isupper():
            return replacement[:1].upper() + replacement[1:]
        return replacement

    def sanitize(self, text, secret, pair_id):
        parts = []
        cursor = 0
        eligible = protected = changed = out_of_vocabulary = 0
        seed = derive_seed(secret, "clusant-caption", pair_id)
        rng = np.random.default_rng(seed)
        for match in TOKEN_PATTERN.finditer(text):
            parts.append(text[cursor:match.start()])
            original = match.group(0)
            normalized = original.lower().replace("’", "'")
            replacement = None
            if self._eligible(normalized):
                eligible += 1
                replacement = self.replace_word(normalized, rng)
                if replacement is None:
                    out_of_vocabulary += 1
                else:
                    protected += 1
            if replacement is None:
                parts.append(original)
            else:
                replacement = self._restore_case(original, replacement)
                parts.append(replacement)
                changed += int(replacement != original)
            cursor = match.end()
        parts.append(text[cursor:])
        private_text = "".join(parts)
        if not private_text.strip():
            raise ValueError("CluSanT produced empty text for {}".format(pair_id))
        return private_text, {
            "eligible_token_count": eligible,
            "protected_token_count": protected,
            "changed_token_count": changed,
            "out_of_vocabulary_token_count": out_of_vocabulary,
            "protected_coverage_percent": 100.0 * protected / eligible if eligible else 0.0,
            "basic_composition_upper_bound": self.epsilon * protected,
        }

    def metadata(self):
        return {
            "mechanism": "CluSanT-adapted",
            "upstream_commit": "07c73be6fa32784e222d8d3be3381733c15a7b87",
            "privacy_scope": "MLDP for selected in-vocabulary tokens",
            "epsilon_text_parameter": self.epsilon,
            "selection_policy": self.selection_policy,
            "candidate_count": len(self.words),
            "cluster_count": len(self.cluster_ids),
            "important": (
                "Unselected/OOV tokens are not claimed private; per-caption basic composition "
                "is reported separately and is not combined with epsilon_image."
            ),
        }
