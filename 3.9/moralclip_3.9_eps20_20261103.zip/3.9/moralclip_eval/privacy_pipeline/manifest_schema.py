"""SMID manifest normalization and stable one-to-one identifiers."""

import hashlib
import hmac
import json
from pathlib import Path


VALID_SPLITS = ("train", "validation", "test")


def canonical_sha256(value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def is_within(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def resolve_manifest(dataset_root, split):
    split_manifest = dataset_root / split / "smid_manifest.json"
    return split_manifest if split_manifest.is_file() else dataset_root / "smid_manifest.json"


def _normalize_labels(labels, image_id):
    if not isinstance(labels, list) or not labels:
        raise ValueError("Invalid moral_labels for {}".format(image_id))
    normalized = []
    for label in labels:
        if not isinstance(label, str) or not label.strip():
            raise ValueError("Invalid moral_labels for {}".format(image_id))
        normalized.append(label.strip())
    return list(dict.fromkeys(normalized))


def load_smid_pairs(dataset_root, splits=VALID_SPLITS, max_images_per_split=None):
    """Expand SMID image records into unique-caption pairs.

    Exact duplicate captions for one image are removed to preserve the behavior of
    the existing evaluator. The returned pair_id remains stable across runs.
    """
    dataset_root = Path(dataset_root).expanduser().resolve()
    if not dataset_root.is_dir():
        raise FileNotFoundError("Dataset root not found: {}".format(dataset_root))
    splits = tuple(splits)
    invalid = sorted(set(splits) - set(VALID_SPLITS))
    if invalid:
        raise ValueError("Unknown splits: {}".format(invalid))

    all_pairs = []
    sources = {}
    stats = {}
    seen_pair_ids = set()
    seen_image_keys = set()
    for split in splits:
        manifest_path = resolve_manifest(dataset_root, split)
        if not manifest_path.is_file():
            raise FileNotFoundError("SMID manifest not found: {}".format(manifest_path))
        raw = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
        if not isinstance(raw, list):
            raise ValueError("SMID manifest must be a JSON list: {}".format(manifest_path))
        sources[split] = {
            "path": str(manifest_path.relative_to(dataset_root)).replace("\\", "/"),
            "sha256": file_sha256(manifest_path),
        }
        image_count = 0
        duplicate_captions = 0
        pair_count_before = len(all_pairs)
        for item in raw:
            if item.get("split") != split:
                continue
            if max_images_per_split is not None and image_count >= int(max_images_per_split):
                break
            image_id = item.get("id")
            image_rel = item.get("image_path")
            if not isinstance(image_id, str) or not image_id.strip():
                raise ValueError("Invalid image id in {}".format(manifest_path))
            if not isinstance(image_rel, str) or not image_rel.strip():
                raise ValueError("Invalid image_path for {}".format(image_id))
            image_key = "{}:{}".format(split, image_id.strip())
            if image_key in seen_image_keys:
                raise ValueError("Duplicate image key: {}".format(image_key))
            seen_image_keys.add(image_key)
            image_abs = (dataset_root / image_rel).resolve()
            if not is_within(image_abs, dataset_root) or not image_abs.is_file():
                raise FileNotFoundError("Image missing or outside dataset: {}".format(image_abs))
            labels = _normalize_labels(item.get("moral_labels"), image_id)
            captions = item.get("captions") or [item.get("caption")]
            if not isinstance(captions, list):
                raise ValueError("Invalid captions for {}".format(image_id))
            normalized = []
            for caption in captions:
                if not isinstance(caption, str) or not caption.strip():
                    raise ValueError("Invalid caption for {}".format(image_id))
                normalized.append(caption.strip())
            unique_captions = list(dict.fromkeys(normalized))
            duplicate_captions += len(normalized) - len(unique_captions)
            image_count += 1
            anonymous_image_id = hashlib.sha256(image_key.encode("utf-8")).hexdigest()[:24]
            for caption_index, text in enumerate(unique_captions):
                pair_id = "{}__caption_{:03d}".format(anonymous_image_id, caption_index)
                if pair_id in seen_pair_ids:
                    raise ValueError("Duplicate pair_id: {}".format(pair_id))
                seen_pair_ids.add(pair_id)
                all_pairs.append({
                    "pair_id": pair_id,
                    "split": split,
                    "image_id": image_id.strip(),
                    "anonymous_image_id": anonymous_image_id,
                    "caption_index": caption_index,
                    "original_image_path": image_rel.replace("\\", "/"),
                    "original_image_abs": str(image_abs),
                    "original_caption": text,
                    "moral_labels": labels,
                })
        pair_count = len(all_pairs) - pair_count_before
        if not pair_count:
            raise ValueError("No records found for split={}".format(split))
        stats[split] = {
            "unique_images": image_count,
            "pairs": pair_count,
            "duplicate_captions_removed": duplicate_captions,
        }
    return {
        "schema_version": 1,
        "dataset_root": str(dataset_root),
        "sources": sources,
        "stats": stats,
        "pairs": all_pairs,
        "pairs_sha256": canonical_sha256([
            {k: row[k] for k in (
                "pair_id", "split", "image_id", "caption_index",
                "original_image_path", "original_caption", "moral_labels"
            )}
            for row in all_pairs
        ]),
    }


def load_secret(secret_env):
    import os
    value = os.environ.get(secret_env)
    if not value or len(value.encode("utf-8")) < 16:
        raise RuntimeError(
            "Environment variable {} must contain at least 16 bytes of secret seed material".format(
                secret_env
            )
        )
    return value.encode("utf-8")


def secret_commitment(secret):
    return hashlib.sha256(b"moralclip-private-release-v1\x00" + secret).hexdigest()


def derive_seed(secret, namespace, stable_id):
    message = "{}\x00{}".format(namespace, stable_id).encode("utf-8")
    digest = hmac.new(secret, message, hashlib.sha256).digest()
    return int.from_bytes(digest[:8], byteorder="big", signed=False) & ((1 << 63) - 1)


def atomic_write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)
