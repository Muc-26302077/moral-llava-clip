"""BLIP captioning and auditable fusion for already-private images."""

import json
import os
from pathlib import Path

import numpy as np
from PIL import Image

from .manifest_schema import canonical_sha256, file_sha256
from .progress import ProgressBar


FUSION_STRATEGIES = (
    "clusant",
    "blip_only",
    "blip_first",
    "clusant_first",
    "blip_first_compact",
    "rerank_only",
    "rerank_first",
    "rerank_compact",
)

RERANK_STRATEGIES = frozenset(("rerank_only", "rerank_first", "rerank_compact"))
COMPACT_STRATEGIES = frozenset(("blip_first_compact", "rerank_compact"))


def normalize_caption(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Caption must be a non-empty string")
    return " ".join(text.strip().split())


def _sentence(text):
    text = normalize_caption(text)
    return text if text.endswith((".", "!", "?")) else text + "."


def fit_fusion_to_token_budget(primary_caption, secondary_caption, tokenizer, max_length=77):
    """Put the image-grounded caption first and fill the remaining CLIP token budget.

    Both inputs must already be private.  Word-boundary search is used only to
    avoid producing text that the frozen evaluator would silently truncate.
    """
    primary = _sentence(primary_caption)
    secondary_words = normalize_caption(secondary_caption).split()

    def token_count(value):
        encoded = tokenizer(value, add_special_tokens=True, truncation=False)
        ids = encoded["input_ids"]
        if ids and isinstance(ids[0], list):
            ids = ids[0]
        return len(ids)

    if token_count(primary) > int(max_length):
        encoded = tokenizer(
            primary, add_special_tokens=True, truncation=True, max_length=int(max_length)
        )
        return normalize_caption(tokenizer.decode(
            encoded["input_ids"], skip_special_tokens=True
        ))

    low, high = 0, len(secondary_words)
    while low < high:
        middle = (low + high + 1) // 2
        candidate = "{} {}".format(primary, " ".join(secondary_words[:middle]))
        if token_count(candidate) <= int(max_length):
            low = middle
        else:
            high = middle - 1
    return normalize_caption(
        "{} {}".format(primary, " ".join(secondary_words[:low]))
    )


def fuse_private_caption(
    clusant_caption, blip_caption, strategy, tokenizer=None, max_length=77
):
    """Fuse two already-private descriptions without original content."""
    if strategy not in FUSION_STRATEGIES:
        raise ValueError("Unknown BLIP caption fusion strategy: {}".format(strategy))
    clusant = normalize_caption(clusant_caption)
    blip = normalize_caption(blip_caption)
    if strategy == "clusant":
        return clusant
    if strategy in ("blip_only", "rerank_only"):
        return blip
    if strategy in ("blip_first", "rerank_first"):
        return "{} Private text: {}".format(_sentence(blip), clusant)
    if strategy == "clusant_first":
        return "{} Visual context: {}".format(_sentence(clusant), blip)
    if tokenizer is None:
        raise ValueError("Compact fusion requires the frozen MoralCLIP tokenizer")
    return fit_fusion_to_token_budget(blip, clusant, tokenizer, max_length=max_length)


def select_best_candidate(query_embedding, candidate_embeddings):
    query = np.asarray(query_embedding, dtype=np.float32).reshape(-1)
    candidates = np.asarray(candidate_embeddings, dtype=np.float32)
    if candidates.ndim != 2 or candidates.shape[1] != query.shape[0] or not len(candidates):
        raise ValueError("Candidate/query embedding shape mismatch")
    if not np.isfinite(query).all() or not np.isfinite(candidates).all():
        raise ValueError("Candidate reranking embeddings must be finite")
    return int(np.argmax(candidates @ query))


class SemanticPrivateCaptionReranker:
    """Rerank private-image BLIP candidates against a CluSanT-private caption."""

    def __init__(self, model_name_or_path, device="auto", batch_size=256):
        from .clusant_text_adapter import SentenceTransformerEmbeddingBackend

        self.backend = SentenceTransformerEmbeddingBackend(
            model_name_or_path, device=device, batch_size=batch_size
        )

    def select_many(self, private_captions, candidate_groups):
        if len(private_captions) != len(candidate_groups):
            raise ValueError("Private caption/candidate group count mismatch")
        normalized_groups = []
        unique_candidates = []
        candidate_index = {}
        for group in candidate_groups:
            values = list(dict.fromkeys(normalize_caption(value) for value in group))
            if not values:
                raise ValueError("Empty BLIP candidate group")
            normalized_groups.append(values)
            for value in values:
                if value not in candidate_index:
                    candidate_index[value] = len(unique_candidates)
                    unique_candidates.append(value)
        query_embeddings = self.backend.encode(
            [normalize_caption(value) for value in private_captions]
        )
        candidate_embeddings = self.backend.encode(unique_candidates)
        selected = []
        indices = []
        for query, group in zip(query_embeddings, normalized_groups):
            positions = [candidate_index[value] for value in group]
            local = select_best_candidate(query, candidate_embeddings[positions])
            selected.append(group[local])
            indices.append(local)
        return selected, indices


def _directory_weight_fingerprint(model_dir):
    model_dir = Path(model_dir)
    candidates = []
    for pattern in ("*.safetensors", "pytorch_model*.bin", "config.json"):
        candidates.extend(model_dir.glob(pattern))
    candidates = sorted({path.resolve() for path in candidates if path.is_file()})
    if not candidates:
        raise FileNotFoundError("No BLIP weight/config files found in {}".format(model_dir))
    records = [
        {"name": path.name, "size": path.stat().st_size, "sha256": file_sha256(path)}
        for path in candidates
    ]
    return records, canonical_sha256(records)


class BlipPrivateCaptioner:
    """Generate captions from LDP-private images with a public frozen BLIP model."""

    def __init__(self, config, base_dir):
        # This project is PyTorch-only.  Set these before importing Transformers
        # so an unrelated/broken system TensorFlow installation cannot block BLIP.
        os.environ.setdefault("USE_TF", "0")
        os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
        import torch
        try:
            from transformers import BlipForConditionalGeneration, BlipProcessor
        except ImportError as exc:
            raise RuntimeError(
                "The installed Transformers build does not provide BLIP. "
                "Install requirements_privacy.txt with a BLIP-capable Transformers version."
            ) from exc

        self.config = dict(config)
        model_dir = Path(self.config["model_dir"]).expanduser()
        self.model_dir = (
            model_dir.resolve() if model_dir.is_absolute()
            else (Path(base_dir) / model_dir).resolve()
        )
        if not self.model_dir.is_dir():
            raise FileNotFoundError("BLIP model directory not found: {}".format(self.model_dir))
        requested = self.config.get("device", "auto")
        self.device = "cuda" if requested == "auto" and torch.cuda.is_available() else requested
        if self.device == "auto":
            self.device = "cpu"
        self.dtype = torch.float16 if str(self.device).startswith("cuda") else torch.float32
        local_only = bool(self.config.get("local_files_only", True))
        self.processor = BlipProcessor.from_pretrained(
            str(self.model_dir), local_files_only=local_only
        )
        self.model = BlipForConditionalGeneration.from_pretrained(
            str(self.model_dir), local_files_only=local_only,
            torch_dtype=self.dtype,
        ).to(self.device)
        self.model.eval()
        self.batch_size = int(self.config.get("batch_size", 16))
        self.max_new_tokens = int(self.config.get("max_new_tokens", 30))
        self.num_beams = int(self.config.get("num_beams", 3))
        self.num_candidates = int(self.config.get("num_candidates", 1))
        if self.batch_size < 1 or self.max_new_tokens < 1 or self.num_beams < 1:
            raise ValueError("BLIP batch_size/max_new_tokens/num_beams must be positive")
        if self.num_candidates < 1 or self.num_candidates > self.num_beams:
            raise ValueError("BLIP num_candidates must be in [1, num_beams]")
        self.weight_files, self.model_fingerprint = _directory_weight_fingerprint(
            self.model_dir
        )

    def metadata(self):
        return {
            "method": "BLIP private-image caption post-processing",
            "paper": "BLIP, ICML 2022",
            "model_dir_name": self.model_dir.name,
            "model_fingerprint": self.model_fingerprint,
            "weight_files": self.weight_files,
            "device": self.device,
            "dtype": str(self.dtype).replace("torch.", ""),
            "batch_size": self.batch_size,
            "max_new_tokens": self.max_new_tokens,
            "num_beams": self.num_beams,
            "num_candidates": self.num_candidates,
            "decoding": "deterministic N-best beam search; do_sample=false",
            "privacy_basis": (
                "The captioner reads only already-private LDP-Slicing images and public weights."
            ),
        }

    def generate_candidates(self, image_paths, label="Generate BLIP private captions"):
        import torch

        paths = [Path(path) for path in image_paths]
        groups = []
        progress = ProgressBar(label, len(paths))
        with torch.inference_mode():
            for start in range(0, len(paths), self.batch_size):
                batch_paths = paths[start:start + self.batch_size]
                images = []
                for path in batch_paths:
                    with Image.open(str(path)) as image:
                        images.append(image.convert("RGB").copy())
                inputs = self.processor(images=images, return_tensors="pt")
                prepared = {}
                for key, value in inputs.items():
                    value = value.to(self.device)
                    if key == "pixel_values":
                        value = value.to(self.dtype)
                    prepared[key] = value
                output = self.model.generate(
                    **prepared,
                    max_new_tokens=self.max_new_tokens,
                    num_beams=self.num_beams,
                    num_return_sequences=self.num_candidates,
                    do_sample=False,
                )
                decoded = self.processor.batch_decode(output, skip_special_tokens=True)
                decoded = [normalize_caption(value) for value in decoded]
                for offset in range(0, len(decoded), self.num_candidates):
                    group = list(dict.fromkeys(decoded[offset:offset + self.num_candidates]))
                    if not group:
                        raise RuntimeError("BLIP returned an empty candidate group")
                    groups.append(group)
                progress.update(len(groups))
        if len(groups) != len(paths):
            raise RuntimeError("BLIP caption count mismatch")
        return groups

    def generate(self, image_paths, label="Generate BLIP private captions"):
        """Backward-compatible top-beam view."""
        return [group[0] for group in self.generate_candidates(image_paths, label=label)]


def load_blip_config(path):
    path = Path(path).expanduser().resolve()
    config = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(config, dict) or "model_dir" not in config:
        raise ValueError("Invalid BLIP caption configuration: {}".format(path))
    return path, config
