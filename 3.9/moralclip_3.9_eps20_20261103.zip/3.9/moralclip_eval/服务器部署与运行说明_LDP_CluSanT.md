# LDP-Slicing + CluSanT 服务器部署与运行说明

本说明对应 `privacy_pair_config.json`。默认正式配置为：

- LDP-Slicing：`epsilon_image=20`、`remove_ll=false`；
- CluSanT：`epsilon_text=20`、`all-mpnet-base-v2`、30,000 个公共候选词；
- 正式评测：test 的 O/O、P/O、O/P、P/P 四条件；
- 保持率门槛：80%，同时检查唯一图片聚类 bootstrap 95% CI 下界。

## 1. 需要上传的目录

将更新后的 `moralclip_eval` 上传到：

```text
/root/autodl-tmp/moralclip_eval
```

服务器同时应已有：

```text
/root/autodl-tmp/SMID_moralclip
/root/autodl-tmp/moralclip-base
```

不要上传本地 `.venv_privacy`、`.references` 或 `reproduction_runs`，它们不是正式运行依赖。

## 2. 创建独立环境

```bash
cd /root/autodl-tmp

conda create -n moralclip-privacy python=3.10 -y
source /root/miniconda3/etc/profile.d/conda.sh
conda activate moralclip-privacy

cd /root/autodl-tmp/moralclip_eval
pip install -r requirements_privacy.txt
```

安装后检查：

```bash
python - <<'PY'
import torch
import transformers
import sentence_transformers
import pytorch_wavelets

print("torch:", torch.__version__)
print("transformers:", transformers.__version__)
print("sentence-transformers:", sentence_transformers.__version__)
print("CUDA available:", torch.cuda.is_available())
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")
PY
```

## 3. 准备 all-mpnet-base-v2

正式 CluSanT 配置不使用 MoralCLIP 生成词表嵌入，需要独立的公开语义嵌入模型：

```bash
mkdir -p /root/autodl-tmp/models/all-mpnet-base-v2

huggingface-cli download sentence-transformers/all-mpnet-base-v2 \
  --local-dir /root/autodl-tmp/models/all-mpnet-base-v2
```

确认目录至少包含模型配置、tokenizer 和权重文件。默认配置路径是：

```text
/root/autodl-tmp/models/all-mpnet-base-v2
```

如果服务器不能联网，可在本地完整下载该模型目录后上传，不能只上传单个权重文件。

## 4. 创建不公开的发布秘密

随机秘密用于为每张图片和每条 caption 派生可恢复但不公开的随机流。不要把秘密写进 JSON、日志或发布包。

```bash
umask 077
openssl rand -hex 32 > /root/autodl-tmp/privacy_release_seed
chmod 600 /root/autodl-tmp/privacy_release_seed
export PRIVACY_RELEASE_SEED="$(cat /root/autodl-tmp/privacy_release_seed)"
```

断点恢复必须使用同一秘密。对外只发布 `privacy_config.json` 中的承诺哈希，不发布秘密文件。

## 5. 只读预检

```bash
cd /root/autodl-tmp/moralclip_eval

export USE_TF=0
export TRANSFORMERS_NO_TF=1
export OMP_NUM_THREADS=8

python generate_private_pairs.py \
  --config privacy_pair_config.json \
  --plan-only

python -m unittest discover -p 'test_*.py' -v
```

预检应显示：

```text
images = 2400
pairs  = 23998
train  = 2140 images / 21398 pairs
validation = 134 images / 1340 pairs
test   = 126 images / 1260 pairs
```

## 6. 正式机制烟雾测试

烟雾测试使用正式 LDP-Slicing 和正式 all-mpnet CluSanT，只缩小数据量：

```bash
python generate_private_pairs.py \
  --config privacy_pair_config.json \
  --output-dir ../SMID_private_smoke \
  --max-images-per-split 10

python validate_private_dataset.py \
  --config privacy_pair_config.json \
  --private-root ../SMID_private_smoke \
  --max-images-per-split 10
```

必须确认 0 缺失、0 重复、0 空文本、0 不可读图片，而且每条 caption 至少有一个受保护 token。烟雾目录不能拿来代替正式数据集。

## 7. 后台执行全量生成与评测

```bash
cd /root/autodl-tmp/moralclip_eval
chmod +x server_run_privacy.sh

screen -S moralclip-privacy
source /root/miniconda3/etc/profile.d/conda.sh
conda activate moralclip-privacy
export PRIVACY_RELEASE_SEED="$(cat /root/autodl-tmp/privacy_release_seed)"
bash server_run_privacy.sh 2>&1 | tee full_privacy_run.log
```

按 `Ctrl+A`、再按 `D` 退出 screen；恢复查看：

```bash
screen -r moralclip-privacy
```

若 SSH 中断或程序异常，重新进入同一环境、导出同一秘密，然后再次运行脚本。脚本使用 `--resume`，会核对源清单、配置、秘密承诺和已生成图片哈希。

## 8. 查看结果

私有数据默认位于：

```text
/root/autodl-tmp/SMID_private_ldpslicing_clusant_eps20_20
```

评测结果默认位于：

```text
/root/autodl-tmp/moralclip_eval/private_results/<时间戳>/
```

重点读取：

```bash
python - <<'PY'
import json
from pathlib import Path

reports = sorted(Path("private_results").glob("*/report.json"), key=lambda p: p.stat().st_mtime)
report = json.loads(reports[-1].read_text(encoding="utf-8"))
test = report["splits"]["test"]
print(json.dumps(test["value_preservation"], ensure_ascii=False, indent=2))
print(json.dumps(test["semantic_utility_gate"], ensure_ascii=False, indent=2))
print(json.dumps(test["conclusion"], ensure_ascii=False, indent=2))
PY
```

必须同时报告联合价值保持率及其CI、图片/文本/跨模态关系保持率、双向检索指标、
文本覆盖率和两个模态各自的隐私参数。原32/24目录和报告不得与本次20/20正式运行混用。

## 9. Validation 预算选择

先分别复制配置文件，只修改 `output_dir`、评测 split 和预算：

- 图片官方优化预算：`12、20、32`；若均无法接近效用目标，可把 `58` 作为较弱隐私的扩展点；
- 文本参数：`2、4、8、16`；
- 参数只在 validation 上选择；
- 固化配置后 test 只进行一次；
- 不允许根据结果删除样本或反复抽样。

不同模态的 ε 定义不同，不能相加成统一图文记录级 ε。

## 10. 发布边界

可发布：

- `pair_manifest.json`；
- `train/validation/test` 下的私有 PNG 和私有 manifest；
- `privacy_config.json`、`privacy_audit.json`；
- 不含原文的评测报告。

禁止发布：

- `internal/`；
- `/root/autodl-tmp/privacy_release_seed`；
- 原始 SMID 图片和 caption；
- 精确随机种子；
- 含原始绝对路径的终端日志。
