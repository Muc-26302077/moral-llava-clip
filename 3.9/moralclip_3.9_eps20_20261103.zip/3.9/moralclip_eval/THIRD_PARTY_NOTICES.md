# Third-party notices

## CLIP-MIA membership-inference methodology

- Paper: Myeongseob Ko, Ming Jin, Chenguang Wang, and Ruoxi Jia,
  "Practical Membership Inference Attacks Against Large-Scale Multi-Modal
  Models: A Pilot Study," ICCV 2023.
- Paper URL: https://openaccess.thecvf.com/content/ICCV2023/html/Ko_Practical_Membership_Inference_Attacks_Against_Large-Scale_Multi-Modal_Models_A_Pilot_ICCV_2023_paper.html
- Upstream code: https://github.com/ruoxi-jia-group/CLIP-MIA
- Local scope: `evaluate_membership_inference.py` and
  `privacy_attacks/clip_mia.py` are project-specific, independently written
  adaptations of the paper's cosine-similarity and augmentation-enhanced
  attack ideas. They are not verbatim copies of the upstream implementation.

This project adapts small algorithmic portions of two official research repositories.

## LDP-Slicing

- Source: <https://github.com/HideTheDandi/LDP-Slicing>
- Pinned commit: `e3154540ed42e1d1c6022ae4d00df7f43a11a193`
- License: Apache License 2.0
- Adapted component: randomized bit-plane slicing, DWT wrapper semantics, and the
  published optimized privacy-budget table.
- Local changes: image file I/O, padding/cropping, private per-image seed derivation,
  strict validation, audit metadata and checkpoint-safe integration.

## CluSanT

- Source: <https://github.com/AwonSomeSauce/CluSanT>
- Pinned commit: `07c73be6fa32784e222d8d3be3381733c15a7b87`
- License: MIT License
- Adapted component: two-stage cluster and token exponential mechanism.
- Local changes: a public CLIP-tokenizer candidate vocabulary, sentence-transformer
  embeddings, MiniBatchKMeans cluster construction, SMID token selection, stable
  private sampling, numeric stabilization and coverage/composition audit fields.

The upstream repositories and their full license texts should be archived with the
experiment release. The local adaptations do not imply endorsement by the authors.
