"""Measure value-consistency retention after CADP text sanitization.

Primary metric:
  C(D) = 100 * mean(1 - JSD(P_value(image), P_value(text)) / log(2))
  retention = 100 * C(private_text) / C(original_text)

The label distributions are zero-shot distributions over a frozen prompt bank.
This is an operational research metric, not a built-in MoralCLIP classifier score.
"""

import argparse
import csv
import hashlib
import json
import math
import platform
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def is_relative_to(path, root):
    """Python 3.8-compatible equivalent of Path.is_relative_to()."""
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def file_sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def js_similarity(p, q):
    p = np.asarray(p, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    midpoint = 0.5 * (p + q)
    tiny = np.finfo(np.float64).tiny
    divergence = 0.5 * np.sum(p * np.log(np.maximum(p, tiny) / np.maximum(midpoint, tiny)), axis=-1)
    divergence += 0.5 * np.sum(q * np.log(np.maximum(q, tiny) / np.maximum(midpoint, tiny)), axis=-1)
    return np.clip(1.0 - divergence / math.log(2.0), 0.0, 1.0)


def softmax(values):
    shifted = values - np.max(values, axis=-1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=-1, keepdims=True)


def retention_percent(private_score, original_score):
    if not np.isfinite(original_score) or original_score <= 0:
        raise ValueError("Original score must be positive and finite for retention")
    return float(100.0 * private_score / original_score)


def load_joined_records(bundle_path, private_path, dataset_root, reject_empty=True):
    dataset_root = dataset_root.resolve()
    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    records = bundle.get("records")
    if bundle.get("kind") != "smid_cadp_bridge_input" or not isinstance(records, list):
        raise ValueError("Invalid bridge input bundle")
    private_rows = json.loads(private_path.read_text(encoding="utf-8"))
    if not isinstance(private_rows, list):
        raise ValueError("CADP result must be a JSON list")
    by_id = {}
    for row in private_rows:
        try:
            row_id = int(row["ground_truth"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError("Every CADP row must contain integer ground_truth=row_id") from exc
        if row_id in by_id:
            raise ValueError(f"Duplicate CADP row_id: {row_id}")
        by_id[row_id] = row
    expected = set(range(len(records)))
    if set(by_id) != expected:
        missing = sorted(expected - set(by_id))[:20]
        extra = sorted(set(by_id) - expected)[:20]
        raise ValueError(f"CADP rows do not exactly match input; missing={missing}, extra={extra}")

    joined = []
    for record in records:
        row_id = record["row_id"]
        private = by_id[row_id]
        if private.get("text") != record["text"]:
            raise ValueError(f"Original text mismatch at row_id={row_id}")
        private_text = private.get("perturbed_sentence")
        if not isinstance(private_text, str) or (reject_empty and not private_text.strip()):
            raise ValueError(f"Empty private text at row_id={row_id}")
        image_path = (dataset_root / record["image_path"]).resolve()
        if not image_path.is_file() or not is_relative_to(image_path, dataset_root):
            raise FileNotFoundError(f"Invalid image path at row_id={row_id}: {image_path}")
        joined.append({**record, "image_abs": str(image_path), "private_text": private_text.strip(),
                       "cadp": private})
    return bundle, joined


def _tensor_value(value):
    import torch
    return value if isinstance(value, torch.Tensor) else value.pooler_output


def encode_images(paths, model, processor, device, batch_size):
    import torch
    from PIL import Image
    features = []
    with torch.inference_mode():
        for start in range(0, len(paths), batch_size):
            batch = []
            for path in paths[start:start + batch_size]:
                with Image.open(path) as image:
                    batch.append(image.convert("RGB"))
            inputs = processor(images=batch, return_tensors="pt").to(device)
            values = _tensor_value(model.get_image_features(**inputs)).float()
            values = torch.nn.functional.normalize(values, dim=-1)
            features.append(values.cpu().numpy())
    return np.concatenate(features)


def encode_texts(texts, model, processor, device, batch_size):
    import torch
    features = []
    max_length = model.config.text_config.max_position_embeddings
    with torch.inference_mode():
        for start in range(0, len(texts), batch_size):
            inputs = processor(
                text=texts[start:start + batch_size], return_tensors="pt", padding=True,
                truncation=True, max_length=max_length,
            ).to(device)
            values = _tensor_value(model.get_text_features(**inputs)).float()
            values = torch.nn.functional.normalize(values, dim=-1)
            features.append(values.cpu().numpy())
    return np.concatenate(features)


def build_label_features(prompt_map, model, processor, device, batch_size):
    labels = list(prompt_map)
    prompts = []
    slices = []
    for label in labels:
        start = len(prompts)
        values = prompt_map[label]
        if not isinstance(values, list) or not values:
            raise ValueError(f"Prompt list is empty for label={label}")
        prompts.extend(values)
        slices.append((start, len(prompts)))
    prompt_features = encode_texts(prompts, model, processor, device, batch_size)
    label_features = []
    for start, end in slices:
        mean = prompt_features[start:end].mean(axis=0)
        label_features.append(mean / np.linalg.norm(mean))
    return labels, np.stack(label_features)


def retrieval_metrics(image_features, text_features, row_image_indices):
    scores = image_features @ text_features.T
    image_count = len(image_features)
    positives = np.zeros((image_count, len(text_features)), dtype=bool)
    positives[row_image_indices, np.arange(len(text_features))] = True

    def ranks_for(matrix, relevant):
        best = np.where(relevant, matrix, -np.inf).max(axis=1)
        ranks = 1 + ((matrix >= best[:, None] - 1e-6) & ~relevant).sum(axis=1)
        result = {f"R@{k}_percent": float(100 * np.mean(ranks <= k)) for k in (1, 5, 10)}
        result.update(median_rank=float(np.median(ranks)), MRR=float(np.mean(1 / ranks)))
        return result

    return {
        "image_to_text": ranks_for(scores, positives),
        "text_to_image": ranks_for(scores.T, positives.T),
    }


def bootstrap_retention(raw_scores, private_scores, image_keys, samples, seed):
    groups = defaultdict(list)
    for idx, key in enumerate(image_keys):
        groups[key].append(idx)
    keys = list(groups)
    rng = np.random.default_rng(seed)
    estimates = []
    for _ in range(samples):
        chosen = rng.choice(keys, size=len(keys), replace=True)
        indices = np.concatenate([np.asarray(groups[key], dtype=int) for key in chosen])
        estimates.append(retention_percent(private_scores[indices].mean(), raw_scores[indices].mean()))
    low, high = np.quantile(estimates, [0.025, 0.975])
    return {"method": "image-cluster bootstrap", "samples": samples,
            "ci95_low": float(low), "ci95_high": float(high)}


def summarize_condition(image_probs, text_probs, image_features, text_features,
                        row_image_indices, label_names, true_label_sets):
    row_image_probs = image_probs[row_image_indices]
    value_scores = js_similarity(row_image_probs, text_probs)
    paired_cosine = np.sum(image_features[row_image_indices] * text_features, axis=1)
    image_pred = np.argmax(row_image_probs, axis=1)
    text_pred = np.argmax(text_probs, axis=1)
    label_to_index = {name: i for i, name in enumerate(label_names)}
    true_indices = [{label_to_index[x] for x in values} for values in true_label_sets]
    image_hit = np.asarray([pred in truth for pred, truth in zip(image_pred, true_indices)])
    text_hit = np.asarray([pred in truth for pred, truth in zip(text_pred, true_indices)])
    true_mass = np.asarray([sum(prob[i] for i in truth) for prob, truth in zip(text_probs, true_indices)])
    return {
        "cross_modal_value_consistency_percent": float(100 * value_scores.mean()),
        "cross_modal_top1_agreement_percent": float(100 * np.mean(image_pred == text_pred)),
        "image_ground_truth_top1_hit_percent": float(100 * image_hit.mean()),
        "text_ground_truth_top1_hit_percent": float(100 * text_hit.mean()),
        "text_ground_truth_probability_mass_mean": float(true_mass.mean()),
        "paired_cosine_mean": float(paired_cosine.mean()),
        "paired_cosine_median": float(np.median(paired_cosine)),
        "value_scores": value_scores,
        "paired_cosine": paired_cosine,
        "image_pred": image_pred,
        "text_pred": text_pred,
        "retrieval": retrieval_metrics(image_features, text_features, row_image_indices),
    }


def json_ready(condition):
    return {k: v for k, v in condition.items() if not isinstance(v, np.ndarray)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(Path(__file__).with_name("privacy_alignment_config.json")))
    parser.add_argument("--private-results")
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8-sig"))
    base = config_path.parent
    private_value = args.private_results or cfg.get("private_results")
    if not private_value:
        raise ValueError("Set private_results in config or pass --private-results")

    dataset_root = resolve(cfg["dataset_root"], base)
    bundle_path = resolve(cfg["bridge_input"], base)
    private_path = resolve(private_value, base)
    bundle, records = load_joined_records(
        bundle_path, private_path, dataset_root, cfg.get("reject_empty_private_text", True)
    )

    import torch
    import transformers
    from transformers import CLIPModel, CLIPProcessor
    model_dir = resolve(cfg["model_dir"], base)
    local = cfg.get("local_files_only", True)
    processor = CLIPProcessor.from_pretrained(str(model_dir), local_files_only=local, use_fast=False)
    model = CLIPModel.from_pretrained(str(model_dir), local_files_only=local)
    device = cfg.get("device", "auto")
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device).eval()
    batch_size = int(cfg.get("batch_size", 16))

    image_paths = list(dict.fromkeys(r["image_abs"] for r in records))
    image_index = {path: i for i, path in enumerate(image_paths)}
    row_image_indices = np.asarray([image_index[r["image_abs"]] for r in records], dtype=int)
    raw_texts = [r["text"] for r in records]
    private_texts = [r["private_text"] for r in records]
    true_labels = [r["moral_labels"] for r in records]

    print(f"Encoding {len(image_paths)} images and {len(records)} original/private text pairs on {device}")
    image_features = encode_images(image_paths, model, processor, device, batch_size)
    raw_features = encode_texts(raw_texts, model, processor, device, batch_size)
    private_features = encode_texts(private_texts, model, processor, device, batch_size)
    label_names, label_features = build_label_features(
        cfg["value_prompts"], model, processor, device, batch_size
    )
    unknown = sorted({x for values in true_labels for x in values} - set(label_names))
    if unknown:
        raise ValueError(f"Ground-truth labels missing from prompt bank: {unknown}")
    logit_scale = float(model.logit_scale.detach().float().exp().cpu().item())
    image_probs = softmax(logit_scale * image_features @ label_features.T)
    raw_probs = softmax(logit_scale * raw_features @ label_features.T)
    private_probs = softmax(logit_scale * private_features @ label_features.T)

    raw = summarize_condition(image_probs, raw_probs, image_features, raw_features,
                              row_image_indices, label_names, true_labels)
    private = summarize_condition(image_probs, private_probs, image_features, private_features,
                                  row_image_indices, label_names, true_labels)
    retention = retention_percent(
        private["cross_modal_value_consistency_percent"],
        raw["cross_modal_value_consistency_percent"],
    )
    bootstrap = bootstrap_retention(
        raw["value_scores"], private["value_scores"],
        [r["image_abs"] for r in records], int(cfg.get("bootstrap_samples", 2000)),
        int(cfg.get("bootstrap_seed", 0)),
    )
    target = float(cfg.get("retention_target_percent", 95.0))
    text_preservation = np.sum(raw_features * private_features, axis=1)

    scopes = Counter()
    changed = 0
    epsilon_values = []
    for record in records:
        cadp = record["cadp"]
        if record["text"] != record["private_text"]:
            changed += 1
        accounting = cadp.get("privacy_accounting") or {}
        scopes[accounting.get("privacy_scope", "missing")] += 1
        value = cadp.get("epsilon_S")
        if isinstance(value, (int, float)) and np.isfinite(value):
            epsilon_values.append(float(value))

    report = {
        "schema_version": 1,
        "metric_definition": {
            "value_consistency": "100 * mean(1 - JSD(P_value(image), P_value(text)) / ln(2))",
            "preservation_rate": "100 * private_value_consistency / original_value_consistency",
            "decision_rule": f"point estimate and image-cluster bootstrap 95% lower bound must exceed {target}%",
            "warning": "Operational zero-shot prompt metric; not a native MoralCLIP classifier accuracy.",
        },
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "transformers": transformers.__version__, "numpy": np.__version__, "device": device},
        "inputs": {"bundle": str(bundle_path), "bundle_sha256": file_sha256(bundle_path),
                   "private_results": str(private_path), "private_results_sha256": file_sha256(private_path),
                   "model_dir": str(model_dir), "split": bundle.get("split")},
        "counts": {"images": len(image_paths), "pairs": len(records)},
        "labels": label_names,
        "original": json_ready(raw),
        "private": json_ready(private),
        "preservation": {
            "cross_modal_value_consistency_retention_percent": retention,
            "bootstrap": bootstrap,
            "target_percent": target,
            "point_estimate_above_target": retention > target,
            "ci95_lower_bound_above_target": bootstrap["ci95_low"] > target,
            "original_private_text_cosine_mean": float(text_preservation.mean()),
        },
        "privacy_output_audit": {
            "changed_pairs": changed,
            "changed_pairs_percent": float(100 * changed / len(records)),
            "privacy_scopes": dict(scopes),
            "epsilon_S_finite_count": len(epsilon_values),
            "epsilon_S_min": min(epsilon_values) if epsilon_values else None,
            "epsilon_S_max": max(epsilon_values) if epsilon_values else None,
            "warning": "Images were not privatized; CADP guarantees are conditional and must be read from each row.",
        },
    }

    out_root = resolve(cfg["output_dir"], base)
    out = out_root / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    out.mkdir(parents=True, exist_ok=False)
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out / "pairs.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        fields = ["row_id", "sample_id", "image_path", "moral_labels", "original_text", "private_text",
                  "original_value_consistency", "private_value_consistency", "original_paired_cosine",
                  "private_paired_cosine", "original_private_text_cosine", "image_value_prediction",
                  "original_text_value_prediction", "private_text_value_prediction"]
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for idx, record in enumerate(records):
            writer.writerow({
                "row_id": record["row_id"], "sample_id": record["sample_id"],
                "image_path": record["image_path"], "moral_labels": "|".join(record["moral_labels"]),
                "original_text": record["text"], "private_text": record["private_text"],
                "original_value_consistency": float(raw["value_scores"][idx]),
                "private_value_consistency": float(private["value_scores"][idx]),
                "original_paired_cosine": float(raw["paired_cosine"][idx]),
                "private_paired_cosine": float(private["paired_cosine"][idx]),
                "original_private_text_cosine": float(text_preservation[idx]),
                "image_value_prediction": label_names[raw["image_pred"][idx]],
                "original_text_value_prediction": label_names[raw["text_pred"][idx]],
                "private_text_value_prediction": label_names[private["text_pred"][idx]],
            })
    print(json.dumps(report["preservation"], ensure_ascii=False, indent=2))
    print(f"Results: {out}")


if __name__ == "__main__":
    main()
