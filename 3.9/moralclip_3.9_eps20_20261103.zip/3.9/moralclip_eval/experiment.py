"""Reproducible evaluation wrapper: python experiment.py --out_dir=run_i."""

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--config", default=str(Path(__file__).with_name("privacy_pair_config.json")))
    parser.add_argument("--private-root")
    parser.add_argument("--splits", nargs="+", choices=["train", "validation", "test"])
    args = parser.parse_args()
    script_dir = Path(__file__).resolve().parent
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=False)
    config_path = Path(args.config).resolve()
    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    config_base = config_path.parent
    for key in ("dataset_root", "model_dir", "output_dir"):
        value = Path(config[key]).expanduser()
        if not value.is_absolute():
            value = (config_base / value).resolve()
        config[key] = str(value)
    config["evaluation"]["output_dir"] = str(out_dir / "raw")
    print("This experiment measures four frozen-model privacy conditions and P/P retention.")
    with tempfile.TemporaryDirectory(prefix="moralclip_eval_") as temp_dir:
        temporary_config = Path(temp_dir) / "config.json"
        temporary_config.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        command = [sys.executable, str(script_dir / "evaluate_private_pairs.py"), "--config", str(temporary_config)]
        if args.private_root:
            command.extend(["--private-root", str(Path(args.private_root).resolve())])
        if args.splits:
            command.extend(["--splits"] + list(args.splits))
        subprocess.run(command, check=True, cwd=str(script_dir))
    reports = sorted((out_dir / "raw").glob("*/report.json"))
    if len(reports) != 1:
        raise RuntimeError("Expected one report, found {}".format(len(reports)))
    final_report = out_dir / "final_info.json"
    shutil.copy2(str(reports[0]), str(final_report))
    subprocess.run(
        [sys.executable, str(script_dir / "plot.py"), "--report", str(final_report),
         "--out-dir", str(out_dir)],
        check=True,
    )
    print("Final experiment report: {}".format(final_report))


if __name__ == "__main__":
    main()
