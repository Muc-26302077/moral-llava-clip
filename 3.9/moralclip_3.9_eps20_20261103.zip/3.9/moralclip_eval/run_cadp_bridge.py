"""Run the real CADP implementation on a prepared SMID caption bundle.

This bridge deliberately does not copy or modify CADP. It injects a strict
read-only dataset adapter into ``baseline.cadp.baseline_cadp`` and preserves
the bundle row_id as CADP's ground_truth field for lossless result joining.
"""

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def file_sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_bridge_rows(path):
    bundle = json.loads(path.read_text(encoding="utf-8"))
    records = bundle.get("records")
    if bundle.get("kind") != "smid_cadp_bridge_input" or not isinstance(records, list):
        raise ValueError("Input is not an SMID CADP bridge bundle")
    rows = []
    for expected, record in enumerate(records):
        if record.get("row_id") != expected:
            raise ValueError(f"row_id must be contiguous; expected {expected}")
        text = record.get("text")
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"Empty text at row_id={expected}")
        rows.append({
            "text": text,
            "label": expected,
            "user_id": record["sample_id"],
        })
    return bundle, rows


def main():
    bridge = argparse.ArgumentParser(
        description="Bridge SMID captions into CADP; unknown options are passed to CADP."
    )
    bridge.add_argument("--cadp-root", required=True)
    bridge.add_argument("--input", required=True)
    bridge.add_argument("--output-root", required=True)
    own, cadp_argv = bridge.parse_known_args()

    cadp_root = Path(own.cadp_root).resolve()
    input_path = Path(own.input).resolve()
    output_root = Path(own.output_root).resolve()
    required = [
        cadp_root / "args.py",
        cadp_root / "baseline" / "cadp" / "baseline_cadp.py",
        cadp_root / "baseline" / "cadp" / "privacy_accounting.py",
    ]
    missing = [str(x) for x in required if not x.is_file()]
    if missing:
        raise FileNotFoundError(f"CADP implementation incomplete: {missing}")
    bundle, rows = load_bridge_rows(input_path)
    output_root.mkdir(parents=True, exist_ok=True)

    sys.path.insert(0, str(cadp_root))
    from args import get_parser  # pylint: disable=import-error,import-outside-toplevel
    import baseline.cadp.baseline_cadp as cadp_impl  # pylint: disable=import-error,import-outside-toplevel

    forbidden = {"--dataset", "--task", "--output_root", "--output-root"}
    if any(x.split("=", 1)[0] in forbidden for x in cadp_argv):
        raise ValueError("dataset/task/output are controlled by the bridge; remove those CADP arguments")
    cadp_args = get_parser().parse_args(cadp_argv)
    cadp_args.method = "cadp"
    cadp_args.dataset = "smid_moralclip"
    cadp_args.task = "cross_modal_value_alignment"
    cadp_args.output_root = str(output_root)

    class BridgeDataLoader:
        def __init__(self, _task, _dataset):
            pass

        def load_and_preprocess(self):
            return [dict(row) for row in rows]

    cadp_impl.DataLoader = BridgeDataLoader
    cadp_impl.extract_text_label = lambda example, _dataset: (
        example["text"], int(example["label"])
    )

    try:
        commit = subprocess.check_output(
            ["git", "-C", str(cadp_root), "rev-parse", "HEAD"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        ).strip()
    except Exception:
        commit = None
    metadata = {
        "schema_version": 1,
        "cadp_root": str(cadp_root),
        "cadp_git_commit": commit,
        "cadp_core_sha256": file_sha256(required[1]),
        "input_file": str(input_path),
        "input_sha256": file_sha256(input_path),
        "input_records_sha256": bundle.get("records_sha256"),
        "record_count": len(rows),
        "split": bundle.get("split"),
        "cadp_arguments": vars(cadp_args),
        "privacy_scope_warning": (
            "CADP certificate is Stage-3 conditional on frozen preprocessing theta; "
            "this bridge does not claim image privacy or raw-document end-to-end DP."
        ),
    }
    metadata_path = output_root / "smid_bridge_run.json"
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    result_dir = cadp_impl.run_cadp(cadp_args)
    print(f"CADP result directory: {result_dir}")
    print(f"Bridge metadata: {metadata_path}")


if __name__ == "__main__":
    main()
