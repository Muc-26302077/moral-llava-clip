"""Materialize one BLIP/CluSanT caption-fusion view of a private dataset."""

import argparse
import copy
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from postprocess_private_dataset import build_split_manifests
from privacy_pipeline.blip_private_caption import (
    COMPACT_STRATEGIES,
    FUSION_STRATEGIES,
    RERANK_STRATEGIES,
    SemanticPrivateCaptionReranker,
    fuse_private_caption,
    load_blip_config,
)
from privacy_pipeline.manifest_schema import (
    atomic_write_json,
    canonical_sha256,
    file_sha256,
    is_within,
)
from privacy_pipeline.progress import ProgressBar


VALID_SPLITS = ("train", "validation", "test")


def _resolve_config_path(value, base_dir):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (Path(base_dir) / path).resolve()


def load_caption_postprocessors(blip_config_path, need_reranker, need_tokenizer):
    if not (need_reranker or need_tokenizer):
        return None, None, None
    config_path, config = load_blip_config(blip_config_path)
    reranker = None
    tokenizer = None
    if need_reranker:
        model_dir = _resolve_config_path(config["reranker_model_dir"], config_path.parent)
        if not model_dir.is_dir():
            raise FileNotFoundError("Caption reranker model missing: {}".format(model_dir))
        reranker = SemanticPrivateCaptionReranker(
            str(model_dir), device=config.get("device", "auto"),
            batch_size=int(config.get("reranker_batch_size", 256)),
        )
    if need_tokenizer:
        from transformers import CLIPProcessor

        model_dir = _resolve_config_path(config["moralclip_model_dir"], config_path.parent)
        tokenizer = CLIPProcessor.from_pretrained(
            str(model_dir), local_files_only=bool(config.get("local_files_only", True)),
            use_fast=False,
        ).tokenizer
    return reranker, tokenizer, config


def materialize_variant(
    source_root, caption_cache_path, output_root, strategy, splits,
    blip_config_path=None, reranker=None, tokenizer=None, postprocess_config=None,
):
    if strategy not in FUSION_STRATEGIES:
        raise ValueError("Unknown fusion strategy: {}".format(strategy))
    source_root = Path(source_root).expanduser().resolve()
    output_root = Path(output_root).expanduser().resolve()
    cache_path = Path(caption_cache_path).expanduser().resolve()
    if output_root.exists():
        raise FileExistsError("Variant output already exists: {}".format(output_root))
    if output_root == source_root or is_within(output_root, source_root):
        raise ValueError("Variant output must not be inside the source private dataset")
    manifest_path = source_root / "pair_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = manifest.get("pairs")
    if manifest.get("kind") != "smid_private_ldpslicing_clusant" or not isinstance(rows, list):
        raise ValueError("Invalid source private-pair manifest")
    if manifest.get("private_pairs_sha256") not in (None, canonical_sha256(rows)):
        raise ValueError("Source private_pairs_sha256 mismatch")
    cache = json.loads(cache_path.read_text(encoding="utf-8"))
    records = cache.get("records")
    if cache.get("kind") != "blip_captions_from_ldp_private_images" or not isinstance(records, list):
        raise ValueError("Invalid BLIP caption cache")
    if cache.get("records_sha256") != canonical_sha256(records):
        raise ValueError("BLIP caption cache hash mismatch")
    if cache.get("source_private_manifest_sha256") != file_sha256(manifest_path):
        raise ValueError("BLIP cache belongs to a different private manifest")
    by_image = {record["image_key"]: record for record in records}
    if len(by_image) != len(records):
        raise ValueError("Duplicate image_key in BLIP caption cache")

    selected = [copy.deepcopy(row) for row in rows if row.get("split") in splits]
    if not selected:
        raise ValueError("No private rows for splits={}".format(list(splits)))

    if (strategy in RERANK_STRATEGIES and reranker is None) or (
        strategy in COMPACT_STRATEGIES and tokenizer is None
    ):
        if blip_config_path is None:
            raise ValueError("Rerank/compact strategies require --blip-config")
        loaded_reranker, loaded_tokenizer, loaded_config = load_caption_postprocessors(
            blip_config_path,
            need_reranker=strategy in RERANK_STRATEGIES and reranker is None,
            need_tokenizer=strategy in COMPACT_STRATEGIES and tokenizer is None,
        )
        reranker = reranker or loaded_reranker
        tokenizer = tokenizer or loaded_tokenizer
        postprocess_config = postprocess_config or loaded_config
    postprocess_config = dict(postprocess_config or {})
    max_length = int(postprocess_config.get("moralclip_max_length", 77))

    chosen_captions = []
    chosen_indices = []
    if strategy in RERANK_STRATEGIES:
        groups = []
        for row in selected:
            key = "{}:{}".format(row["split"], row["anonymous_image_id"])
            record = by_image.get(key)
            if record is None:
                raise ValueError("BLIP caption missing for {}".format(key))
            groups.append(record.get("blip_candidates") or [record["blip_caption"]])
        chosen_captions, chosen_indices = reranker.select_many(
            [row["private_caption"] for row in selected], groups
        )

    images = {}
    for row_index, row in enumerate(selected):
        key = "{}:{}".format(row["split"], row["anonymous_image_id"])
        record = by_image.get(key)
        if record is None:
            raise ValueError("BLIP caption missing for {}".format(key))
        if record["private_image_path"] != row["private_image_path"]:
            raise ValueError("BLIP/source image path mismatch for {}".format(key))
        blip_caption = (
            chosen_captions[row_index]
            if strategy in RERANK_STRATEGIES else record["blip_caption"]
        )
        row["private_caption"] = fuse_private_caption(
            row["private_caption"], blip_caption, strategy,
            tokenizer=tokenizer, max_length=max_length,
        )
        privacy = dict(row.get("privacy") or {})
        privacy["caption_postprocessing"] = {
            "method": "BLIP private-image caption fusion",
            "strategy": strategy,
            "model_fingerprint": cache["model"]["model_fingerprint"],
            "candidate_count": len(record.get("blip_candidates") or [record["blip_caption"]]),
            "selected_candidate_index": (
                chosen_indices[row_index] if strategy in RERANK_STRATEGIES else 0
            ),
            "token_budget": max_length if strategy in COMPACT_STRATEGIES else None,
            "privacy_basis": (
                "uses only an LDP-private image, a CluSanT-private caption, and public weights"
            ),
        }
        row["privacy"] = privacy
        images[key] = row["private_image_path"]

    output_root.mkdir(parents=True, exist_ok=False)
    progress = ProgressBar("Copy private images", len(images))
    for index, (key, relative) in enumerate(sorted(images.items()), 1):
        source_image = (source_root / relative).resolve()
        output_image = (output_root / relative).resolve()
        if not is_within(source_image, source_root) or not source_image.is_file():
            raise FileNotFoundError("Private image missing/outside source: {}".format(source_image))
        if not is_within(output_image, output_root):
            raise ValueError("Private image output escaped root: {}".format(output_image))
        expected = by_image[key]["private_image_sha256"]
        if file_sha256(source_image) != expected:
            raise ValueError("Private image changed after BLIP captioning: {}".format(key))
        output_image.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_image, output_image)
        progress.update(index)

    derived = {
        "schema_version": 1,
        "kind": "smid_private_ldpslicing_clusant",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_private_manifest_sha256": file_sha256(manifest_path),
        "blip_caption_cache_sha256": file_sha256(cache_path),
        "pairs_sha256_source": manifest.get("pairs_sha256_source"),
        "pair_count": len(selected),
        "unique_image_count": len(images),
        "selected_splits": list(splits),
        "caption_fusion_strategy": strategy,
        "caption_candidate_selection": (
            "MPNet cosine reranking against CluSanT-private text"
            if strategy in RERANK_STRATEGIES else "top BLIP beam"
        ),
        "pairs": selected,
    }
    derived["private_pairs_sha256"] = canonical_sha256(selected)
    atomic_write_json(output_root / "pair_manifest.json", derived)
    build_split_manifests(selected, output_root)
    privacy_config = {
        "schema_version": 1,
        "source_private_manifest_sha256": file_sha256(manifest_path),
        "blip_caption_cache_sha256": file_sha256(cache_path),
        "blip_model": cache["model"],
        "caption_fusion_strategy": strategy,
        "caption_candidate_selection": derived["caption_candidate_selection"],
        "selection_boundary": "Choose strategy on validation only; test is final-use only.",
        "privacy_boundary": (
            "The caption stage reads only already-private modality outputs and public BLIP "
            "weights. No original SMID image or caption is accessed."
        ),
    }
    atomic_write_json(output_root / "privacy_config.json", privacy_config)
    audit = {
        "schema_version": 1,
        "status": "complete",
        "strategy": strategy,
        "selected_splits": list(splits),
        "pair_count": len(selected),
        "unique_image_count": len(images),
        "source_private_manifest_sha256": file_sha256(manifest_path),
        "blip_caption_cache_sha256": file_sha256(cache_path),
        "private_pairs_sha256": derived["private_pairs_sha256"],
    }
    atomic_write_json(output_root / "caption_postprocess_audit.json", audit)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print("BLIP caption variant: {}".format(output_root))
    return audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--caption-cache", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--strategy", required=True, choices=FUSION_STRATEGIES)
    parser.add_argument(
        "--blip-config", default=str(Path(__file__).with_name("blip_caption_config.json"))
    )
    parser.add_argument("--splits", nargs="+", choices=VALID_SPLITS, default=["validation"])
    args = parser.parse_args()
    materialize_variant(
        args.source_root, args.caption_cache, args.output_root,
        args.strategy, tuple(args.splits), blip_config_path=args.blip_config,
    )


if __name__ == "__main__":
    main()
