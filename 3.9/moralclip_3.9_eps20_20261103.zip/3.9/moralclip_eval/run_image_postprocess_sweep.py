"""Select a DP-safe image restoration preset on validation data only."""

import argparse
import csv
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from postprocess_private_dataset import postprocess_dataset
from privacy_pipeline.image_postprocessing import PRESETS


def resolve(value, base):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def run_logged(command, log_path):
    print("\nRunning: {}".format(" ".join(str(value) for value in command)), flush=True)
    lines = []
    with log_path.open("w", encoding="utf-8", newline="\n") as stream:
        process = subprocess.Popen(
            [str(value) for value in command], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            stream.write(line)
            stream.flush()
            lines.append(line.rstrip("\n"))
        return_code = process.wait()
    if return_code:
        raise RuntimeError("Evaluation failed; see {}".format(log_path))
    return lines


def result_path(lines):
    for line in reversed(lines):
        if line.startswith("Results: "):
            return Path(line.split("Results: ", 1)[1].strip()).resolve()
    raise RuntimeError("Evaluator did not report its result directory")


def summarize(preset, private_root, report_path):
    report = json.loads(report_path.read_text(encoding="utf-8"))
    values = report["splits"]["validation"]
    preservation = values["value_preservation"]
    utility = values["semantic_utility_gate"]
    conclusion = values["conclusion"]
    return {
        "preset": preset,
        "images": values["counts"]["images"],
        "pairs": values["counts"]["pairs"],
        "joint_value_preservation_percent": preservation[
            "joint_value_profile_preservation_percent"
        ],
        "joint_value_ci95_low": preservation["bootstrap"]["ci95_low"],
        "image_value_preservation_percent": preservation[
            "image_value_profile_preservation_percent"
        ],
        "image_to_text_R1_retention_percent": utility[
            "image_to_text_R1_retention_percent"
        ],
        "text_to_image_R1_retention_percent": utility[
            "text_to_image_R1_retention_percent"
        ],
        "joint_R1_retention_percent": utility["joint_R1_retention_percent"],
        "value_preservation_pass": conclusion["value_preservation_pass"],
        "semantic_utility_pass": conclusion["semantic_utility_pass"],
        "strict_pass": conclusion["strict_pass"],
        "private_root": str(private_root),
        "report_path": str(report_path),
    }


def recommend(rows, target):
    eligible = [
        row for row in rows
        if row["joint_value_preservation_percent"] >= target
        and row["joint_value_ci95_low"] >= target
    ]
    if not eligible:
        return None
    return max(eligible, key=lambda row: row["joint_R1_retention_percent"])["preset"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(Path(__file__).with_name("privacy_pair_config.json")))
    parser.add_argument("--source-root", required=True,
                        help="Existing full private dataset generated with the frozen budgets.")
    parser.add_argument("--work-root", required=True)
    parser.add_argument(
        "--presets", nargs="+",
        default=["identity", "median3", "median5", "gaussian05", "gaussian10",
                 "median3_unsharp", "wavelet03", "wavelet06"],
        choices=sorted(PRESETS),
    )
    parser.add_argument("--target-percent", type=float, default=80.0)
    args = parser.parse_args()
    config = Path(args.config).expanduser().resolve()
    config_base = config.parent
    source_root = Path(args.source_root).expanduser().resolve()
    work_root = Path(args.work_root).expanduser().resolve()
    if work_root.exists():
        raise FileExistsError("Sweep root already exists: {}".format(work_root))
    work_root.mkdir(parents=True)
    rows = []
    for preset in args.presets:
        candidate_root = work_root / preset / "private_validation"
        evaluation_root = work_root / preset / "evaluation_results"
        postprocess_dataset(source_root, candidate_root, preset, ("validation",))
        candidate_config = json.loads(config.read_text(encoding="utf-8-sig"))
        candidate_config["dataset_root"] = str(resolve(
            candidate_config["dataset_root"], config_base
        ))
        candidate_config["model_dir"] = str(resolve(
            candidate_config["model_dir"], config_base
        ))
        text_config = candidate_config.get("text_privacy", {})
        if "embedding_model" in text_config:
            text_config["embedding_model"] = str(resolve(
                text_config["embedding_model"], config_base
            ))
        if "public_vocab_path" in text_config:
            text_config["public_vocab_path"] = str(resolve(
                text_config["public_vocab_path"], config_base
            ))
        candidate_config["output_dir"] = str(candidate_root)
        candidate_config["splits"] = ["validation"]
        candidate_config["evaluation"]["splits"] = ["validation"]
        candidate_config["evaluation"]["output_dir"] = str(evaluation_root)
        candidate_config_path = work_root / preset / "config.json"
        candidate_config_path.write_text(
            json.dumps(candidate_config, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        lines = run_logged([
            sys.executable, str(Path(__file__).with_name("evaluate_private_pairs.py")),
            "--config", str(candidate_config_path), "--private-root", str(candidate_root),
            "--splits", "validation",
        ], work_root / preset / "evaluation.log")
        report_path = result_path(lines) / "report.json"
        rows.append(summarize(preset, candidate_root, report_path))
        payload = {
            "schema_version": 1,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "selection_split": "validation",
            "selection_rule": (
                "Maximize joint R@1 retention among presets whose joint value point estimate "
                "and 95% cluster-bootstrap lower bound both meet the target."
            ),
            "target_percent": args.target_percent,
            "recommended_preset": recommend(rows, args.target_percent),
            "runs": rows,
        }
        (work_root / "summary.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        with (work_root / "summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    print("\nSweep summary: {}".format(work_root / "summary.json"))
    print("Recommended preset: {}".format(recommend(rows, args.target_percent)))


if __name__ == "__main__":
    main()
