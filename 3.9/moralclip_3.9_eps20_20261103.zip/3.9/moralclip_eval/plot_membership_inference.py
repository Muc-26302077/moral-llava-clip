"""Create two figures from a MoralCLIP membership-inference report."""

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def selected_test(report, condition):
    block = report["conditions"][condition]
    return block["attacks"][block["selected_attack"]]["test"]


def create_figures(report, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    oo = selected_test(report, "O_O")
    pp = selected_test(report, "P_P")
    names = ["Balanced ASR", "AUC", "TPR@1%FPR"]
    oo_values = [
        oo["balanced_ASR_percent"], 100.0 * oo["AUC"],
        oo["TPR_at_1pct_FPR_percent"],
    ]
    pp_values = [
        pp["balanced_ASR_percent"], 100.0 * pp["AUC"],
        pp["TPR_at_1pct_FPR_percent"],
    ]
    x = np.arange(len(names))
    fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
    ax.bar(x - 0.19, oo_values, 0.38, label="O/O")
    ax.bar(x + 0.19, pp_values, 0.38, label="P/P")
    ax.plot([-0.5, 1.5], [50.0, 50.0], color="gray", linestyle="--",
            linewidth=1, label="random ASR/AUC")
    ax.plot([1.7, 2.3], [1.0, 1.0], color="#8c6d31", linestyle=":",
            linewidth=1.5, label="random TPR at 1% FPR")
    ax.set_xticks(x, names)
    ax.set_ylabel("Attack performance (%)")
    ax.set_ylim(0, 105)
    ax.set_title("Adaptive membership-inference attack")
    ax.legend()
    fig.savefig(output_dir / "Figure_1.png", dpi=200)
    plt.close(fig)

    effect = report["defense_effect"]
    values = [
        effect["balanced_ASR_absolute_drop_points"],
        effect["AUC_drop_points"],
        effect["TPR_at_1pct_FPR_drop_points"],
    ]
    boot = effect["cluster_bootstrap"]
    lows = [boot["balanced_ASR_percent"]["ci95_low"],
            boot["AUC_points"]["ci95_low"], values[2]]
    highs = [boot["balanced_ASR_percent"]["ci95_high"],
             boot["AUC_points"]["ci95_high"], values[2]]
    errors = np.asarray([
        [max(0.0, value - low) for value, low in zip(values, lows)],
        [max(0.0, high - value) for value, high in zip(values, highs)],
    ])
    fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
    colors = ["#2c7fb8" if value >= 0 else "#d7301f" for value in values]
    ax.bar(np.arange(3), values, color=colors, yerr=errors, capsize=5)
    ax.axhline(0.0, color="black", linewidth=1)
    ax.set_xticks(np.arange(3), ["ASR drop", "AUC drop", "TPR@1%FPR drop"])
    ax.set_ylabel("O/O minus P/P (percentage points)")
    ax.set_title("Membership-inference defense effect")
    fig.savefig(output_dir / "Figure_2.png", dpi=200)
    plt.close(fig)
    print("Figure 1: {}".format(output_dir / "Figure_1.png"))
    print("Figure 2: {}".format(output_dir / "Figure_2.png"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True)
    parser.add_argument("--output-dir")
    args = parser.parse_args()
    report_path = Path(args.report).resolve()
    report = json.loads(report_path.read_text(encoding="utf-8"))
    create_figures(report, args.output_dir or report_path.parent)


if __name__ == "__main__":
    main()

